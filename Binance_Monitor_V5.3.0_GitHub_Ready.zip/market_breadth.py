"""V4.8.0 full-market USDT perpetual breadth engine.

Research-only.  The breadth session starts at 00:00 UTC, which is 08:00 in
Beijing/Singapore (UTC+8).  The engine never gates Model A.  It uses the
all-market miniTicker stream for current prices and daily kline opens for a
fixed session reference.  Session-open warmup is isolated from the main market
client so a breadth timeout/rate-limit cannot stop Model A scanning.
"""
from __future__ import annotations

import asyncio
import logging
import statistics
import time
from collections import deque

import aiohttp

from config import config

logger = logging.getLogger(__name__)

BREADTH_ENGINE_VERSION = "4.8.0"


def _session_start_utc(ts: float | None = None) -> float:
    """Latest 00:00 UTC <= ts (08:00 UTC+8)."""
    ts = float(ts or time.time())
    return float(int(ts // 86400) * 86400)


def _classify(up_pct: float, down_pct: float, median_ret: float, score: float) -> tuple[str, str]:
    # Descriptive research labels only; not a trading filter.
    if down_pct >= 0.75 or score <= -50:
        return "BROAD_STRONG_BEAR", "广泛强偏空"
    if up_pct >= 0.75 or score >= 50:
        return "BROAD_STRONG_BULL", "广泛强偏多"
    if down_pct >= 0.60 or (score <= -20 and median_ret < 0):
        return "BROAD_BEAR", "广泛偏空"
    if up_pct >= 0.60 or (score >= 20 and median_ret > 0):
        return "BROAD_BULL", "广泛偏多"
    return "BROAD_NEUTRAL", "广度中性"


class MarketBreadthEngine:
    def __init__(self):
        self.latest = self._unknown("等待首次采样")
        self._session = None
        self._running = False
        self._warm_task = None
        self._session_open: dict[str, float] = {}
        self._symbols: frozenset[str] = frozenset()
        self._quote_volume_24h: dict[str, float] = {}
        self._session_start = 0.0
        self._history = deque(maxlen=120)
        self._lock = asyncio.Lock()

    @staticmethod
    def _unknown(reason: str):
        return {
            "status": "UNKNOWN", "status_cn": "数据不足", "breadth_score": 0.0,
            "session_up_pct": 0.0, "session_down_pct": 0.0, "session_flat_pct": 0.0,
            "median_session_return_pct": 0.0, "pct_up_1": 0.0, "pct_up_3": 0.0,
            "pct_down_1": 0.0, "pct_down_3": 0.0, "breadth_score_delta_15m": None,
            "breadth_score_delta_30m": None, "sample_size": 0, "eligible_symbol_count": 0,
            "coverage": 0.0, "session_start_utc": _session_start_utc(), "updated_at": 0.0,
            "data_quality": "UNKNOWN", "reason": reason, "engine_version": BREADTH_ENGINE_VERSION,
            "liquid": {},
        }

    async def _session_obj(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()),
                timeout=aiohttp.ClientTimeout(total=float(config.breadth_rest_timeout_seconds)),
            )
        return self._session

    async def start(self):
        self._running = True

    async def close(self):
        self._running = False
        if self._warm_task:
            self._warm_task.cancel()
            await asyncio.gather(self._warm_task, return_exceptions=True)
        if self._session and not self._session.closed:
            await self._session.close()

    def set_universe(self, symbols, quote_volume_24h, data_engine=None):
        """Publish all public USDT perpetual symbols, not only alert-eligible ones."""
        clean = frozenset(str(s) for s in symbols if s)
        self._symbols = clean
        self._quote_volume_24h = {str(k): float(v or 0) for k, v in (quote_volume_24h or {}).items()}
        start = _session_start_utc()
        if start != self._session_start:
            self._session_start = start
            self._session_open.clear()
            self._history.clear()
        if data_engine is not None:
            for symbol in clean:
                try:
                    px = data_engine.session_open_price(symbol, start)
                except Exception:
                    px = None
                if px and px > 0:
                    self._session_open[symbol] = float(px)
        self._ensure_warm_task()

    def _ensure_warm_task(self):
        if not self._running or not self._symbols:
            return
        if self._warm_task is None or self._warm_task.done():
            self._warm_task = asyncio.create_task(self._warm_missing_opens(), name="breadth-session-open-warmup")

    async def _fetch_daily_open(self, symbol: str, session_start: float):
        session = await self._session_obj()
        async with session.get(
            "https://fapi.binance.com/fapi/v1/klines",
            params={"symbol": symbol, "interval": "1d", "startTime": int(session_start * 1000), "limit": 1},
            proxy=config.proxy_url if config.use_proxy else None,
        ) as resp:
            if resp.status in (418, 429):
                raise RuntimeError(f"breadth rate limited: HTTP {resp.status}")
            resp.raise_for_status()
            rows = await resp.json()
        if not rows:
            return None
        row = rows[0]
        if abs(float(row[0]) / 1000.0 - session_start) > 60:
            return None
        px = float(row[1])
        return px if px > 0 else None

    async def _warm_missing_opens(self):
        # Keep this isolated and deliberately conservative.  Eligible symbols are
        # usually prefilled from 5m warmup; REST is mainly for low-volume symbols
        # that are part of full-market breadth but not the alert universe.
        sem = asyncio.Semaphore(int(config.breadth_open_warm_concurrency))
        start = self._session_start or _session_start_utc()
        missing = [s for s in sorted(self._symbols) if s not in self._session_open]
        if not missing:
            return

        async def one(symbol):
            async with sem:
                if not self._running or start != self._session_start:
                    return
                try:
                    px = await self._fetch_daily_open(symbol, start)
                    if px:
                        self._session_open[symbol] = px
                except asyncio.CancelledError:
                    raise
                except Exception:
                    # Missing individual opens are reflected by coverage; do not
                    # turn one symbol failure into a system failure.
                    return
                await asyncio.sleep(float(config.breadth_open_warm_delay_seconds))

        await asyncio.gather(*(one(s) for s in missing))
        logger.info("Breadth session-open warmup | session=%s | opens=%s/%s",
                    time.strftime("%Y-%m-%d %H:%M", time.gmtime(start)), len(self._session_open), len(self._symbols))

    @staticmethod
    def _metrics(rows, dead_band_pct: float):
        if not rows:
            return None
        vals = [float(x) for x in rows]
        n = len(vals)
        up = sum(x > dead_band_pct for x in vals)
        down = sum(x < -dead_band_pct for x in vals)
        flat = n - up - down
        up_pct, down_pct, flat_pct = up / n, down / n, flat / n
        med = statistics.median(vals)
        score = (up_pct - down_pct) * 100.0
        status, cn = _classify(up_pct, down_pct, med, score)
        return {
            "status": status, "status_cn": cn, "breadth_score": score,
            "session_up_pct": up_pct, "session_down_pct": down_pct, "session_flat_pct": flat_pct,
            "median_session_return_pct": med,
            "pct_up_1": sum(x >= 1.0 for x in vals) / n,
            "pct_up_3": sum(x >= 3.0 for x in vals) / n,
            "pct_down_1": sum(x <= -1.0 for x in vals) / n,
            "pct_down_3": sum(x <= -3.0 for x in vals) / n,
            "sample_size": n,
        }

    def _history_delta(self, now: float, minutes: int):
        if not self._history:
            return None
        target = now - minutes * 60
        candidates = [x for x in self._history if x[0] <= now - 30]
        if not candidates:
            return None
        ts, score = min(candidates, key=lambda x: abs(x[0] - target))
        if abs(ts - target) > 150:
            return None
        return float(self.latest.get("breadth_score") or 0) - float(score)

    async def sample(self, quotes: dict[str, dict]):
        if not config.market_breadth_enabled:
            self.latest = self._unknown("全市场广度研究已关闭")
            return self.latest
        now = time.time()
        start = _session_start_utc(now)
        if start != self._session_start:
            self._session_start = start
            self._session_open.clear()
            self._history.clear()
            self._ensure_warm_task()
        self._ensure_warm_task()

        returns: dict[str, float] = {}
        for symbol in self._symbols:
            op = self._session_open.get(symbol)
            q = quotes.get(symbol) or {}
            px = float(q.get("price") or 0)
            if not op or op <= 0 or px <= 0:
                continue
            returns[symbol] = (px / op - 1.0) * 100.0

        total = len(self._symbols)
        coverage = len(returns) / total if total else 0.0
        metrics = self._metrics(list(returns.values()), float(config.breadth_flat_band_pct))
        if not metrics:
            self.latest = self._unknown("缺少全市场 session open / 最新价")
            self.latest.update({"eligible_symbol_count": total, "coverage": coverage, "session_start_utc": start,
                                "updated_at": now})
            return self.latest

        top_n = max(1, int(config.breadth_liquid_top_n))
        ranked = sorted(
            (s for s in returns),
            key=lambda s: float(self._quote_volume_24h.get(s, 0)),
            reverse=True,
        )[:top_n]
        liquid = self._metrics([returns[s] for s in ranked], float(config.breadth_flat_band_pct)) or {}

        quality = "OK" if coverage >= float(config.breadth_min_coverage) else "DEGRADED"
        latest = {
            **metrics,
            "eligible_symbol_count": total,
            "coverage": coverage,
            "session_start_utc": start,
            "updated_at": now,
            "data_quality": quality,
            "reason": "" if quality == "OK" else f"广度覆盖不足 {coverage:.1%}",
            "engine_version": BREADTH_ENGINE_VERSION,
            "liquid": liquid,
        }
        self.latest = latest
        if quality != "OK":
            latest["observed_status"] = latest.get("status")
            latest["status"] = "UNKNOWN"
            latest["status_cn"] = "覆盖不足"
        latest["breadth_score_delta_15m"] = self._history_delta(now, 15)
        latest["breadth_score_delta_30m"] = self._history_delta(now, 30)
        self._history.append((now, float(latest["breadth_score"])))
        return latest


market_breadth_engine = MarketBreadthEngine()
