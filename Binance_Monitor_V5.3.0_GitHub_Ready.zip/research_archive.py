"""Compact immutable-friendly Model-A research archive for V4.8.0.

The runtime DB remains operational storage.  Each completed 240-minute Model-A
signal is upserted into a separate one-row-per-signal research_archive.db.
Analysis snapshots can then be generated without uploading the large runtime DB.
"""
from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
import statistics
import time
from pathlib import Path

from config import ROOT

ARCHIVE_PATH = ROOT / "research_archive.db"
ARCHIVE_VERSION = "5.3.0-fusion"

ARCHIVE_SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS model_a_research (
  source_dataset TEXT NOT NULL DEFAULT 'legacy',
  source_version TEXT NOT NULL,
  source_id INTEGER NOT NULL,
  symbol TEXT NOT NULL,
  direction TEXT NOT NULL,
  signal_at REAL NOT NULL,
  trigger_price REAL NOT NULL,
  actual_vr REAL, atr_pct REAL, atr_percentile_200 REAL, atr_percentile_500 REAL,
  trigger_move_atr_ratio REAL, directional_close_location REAL,
  fixed_a_plus INTEGER NOT NULL DEFAULT 0, a_plus_plus_trend INTEGER NOT NULL DEFAULT 0,
  a_plus_plus_persistence INTEGER NOT NULL DEFAULT 0,
  market_spike_risk TEXT, market_direction_score REAL, market_stress_score REAL,
  breadth_status TEXT, breadth_score REAL, session_up_pct REAL, session_down_pct REAL,
  session_flat_pct REAL, median_session_return_pct REAL, pct_up_1 REAL, pct_up_3 REAL,
  pct_down_1 REAL, pct_down_3 REAL, breadth_score_delta_15m REAL, breadth_score_delta_30m REAL,
  breadth_coverage REAL, breadth_sample_size INTEGER,
  liquid_breadth_score REAL, liquid_session_up_pct REAL, liquid_session_down_pct REAL,
  liquid_median_session_return_pct REAL,
  bb_1h_mid REAL, bb_1h_position TEXT, bb_1h_distance_pct REAL,
  bb_4h_mid REAL, bb_4h_position TEXT, bb_4h_distance_pct REAL,
  bb_trend_context TEXT, trend_alignment TEXT,
  return_1m REAL, mfe_1m REAL, mae_1m REAL, return_3m REAL, mfe_3m REAL, mae_3m REAL,
  return_5m REAL, mfe_5m REAL, mae_5m REAL, return_10m REAL, mfe_10m REAL, mae_10m REAL,
  return_15m REAL, mfe_15m REAL, mae_15m REAL, return_20m REAL, mfe_20m REAL, mae_20m REAL,
  return_30m REAL, mfe_30m REAL, mae_30m REAL, return_45m REAL, mfe_45m REAL, mae_45m REAL,
  return_60m REAL, mfe_60m REAL, mae_60m REAL, return_90m REAL, mfe_90m REAL, mae_90m REAL,
  return_120m REAL, mfe_120m REAL, mae_120m REAL, return_240m REAL, mfe_240m REAL, mae_240m REAL,
  running_mfe_pct REAL, running_mae_pct REAL, time_to_mfe_minutes REAL,
  first_plus_1_min REAL, first_plus_2_min REAL, first_plus_3_min REAL, first_plus_5_min REAL,
  first_minus_1_min REAL, first_minus_1_5_min REAL, first_minus_2_min REAL,
  giveback_pct REAL, giveback_ratio REAL,
  confirmation_entry_price REAL, confirmation_entry_at REAL,
  execution_results_json TEXT, signal_payload_json TEXT,
  archived_at REAL NOT NULL,
  PRIMARY KEY(source_dataset, source_version, source_id)
);
CREATE INDEX IF NOT EXISTS idx_archive_v49_signal_at ON model_a_research(signal_at DESC);
CREATE INDEX IF NOT EXISTS idx_archive_v49_context ON model_a_research(direction,breadth_status,bb_trend_context);
CREATE TABLE IF NOT EXISTS archive_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


def _research_identity(source_version, symbol, signal_at, trigger_price, direction):
    """Economic-event fingerprint for cross-dataset de-duplication audits; DB PK stays dataset+version+id."""
    key=f'{source_version}|{symbol}|{float(signal_at):.6f}|{float(trigger_price):.12g}|{direction}'
    return hashlib.sha256(key.encode()).hexdigest()


class _ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc, tb):
        try:
            return super().__exit__(exc_type,exc,tb)
        finally:
            self.close()


def _connect(path: Path | None = None):
    path = path or ARCHIVE_PATH
    db = sqlite3.connect(path, timeout=30, factory=_ClosingConnection)
    db.row_factory = sqlite3.Row
    old_cols={row[1] for row in db.execute('PRAGMA table_info(model_a_research)')}
    if old_cols and 'source_dataset' not in old_cols:
        # V4.8 used (version,id), V5.2 used source_uuid. Retain original table
        # byte-for-byte as a named backup rather than dropping any research data.
        existing={r[0] for r in db.execute('SELECT name FROM sqlite_master WHERE type="table"')}
        backup='model_a_research_v52_backup' if 'source_uuid' in old_cols else 'model_a_research_v48_backup'
        if backup in existing:
            raise RuntimeError(f'Archive migration backup already exists: {backup}; manual reconciliation required')
        db.execute(f'ALTER TABLE model_a_research RENAME TO {backup}')
        db.commit()
    db.executescript(ARCHIVE_SCHEMA)
    live_cols={r[1] for r in db.execute('PRAGMA table_info(model_a_research)')}
    for backup in ('model_a_research_v48_backup','model_a_research_v52_backup'):
        backup_cols=[r[1] for r in db.execute(f'PRAGMA table_info({backup})')]
        if not backup_cols:
            continue
        meta_key=f'backup_import_done:{backup}'
        if db.execute('SELECT 1 FROM archive_meta WHERE key=?',(meta_key,)).fetchone():
            continue
        keep=[name for name in backup_cols if name in live_cols]
        for row in db.execute(f'SELECT * FROM {backup}').fetchall():
            values={k:row[k] for k in keep}
            if 'source_dataset' not in values:
                values['source_dataset']=('v52uuid:'+str(row['source_uuid'])) if 'source_uuid' in backup_cols else 'legacy'
            names=list(values)
            db.execute(f"INSERT OR IGNORE INTO model_a_research({','.join(names)}) VALUES({','.join('?' for _ in names)})",
                       list(values.values()))
        db.execute('INSERT OR REPLACE INTO archive_meta(key,value) VALUES(?,?)',(meta_key,'1'))
        if backup=='model_a_research_v48_backup':
            # Compatibility with V4.9's original migration marker.
            db.execute("INSERT OR REPLACE INTO archive_meta(key,value) VALUES('legacy_rows_migrated','1')")
    db.execute("INSERT OR REPLACE INTO archive_meta(key,value) VALUES('archive_version',?)", (ARCHIVE_VERSION,))
    db.commit()
    return db


def _truth_before(row, pos, neg):
    p, n = row[pos], row[neg]
    return p is not None and (n is None or float(p) < float(n))


def archive_completed_signal(runtime_db, source_id: int):
    """Archive one completed Model-A signal using an existing runtime connection."""
    row = runtime_db.execute("""SELECT va.*, l.*,
      c.market_direction_score AS ctx_direction_score,c.market_stress_score AS ctx_stress_score,
      c.breadth_status,c.breadth_score,c.session_up_pct,c.session_down_pct,c.session_flat_pct,
      c.median_session_return_pct,c.pct_up_1,c.pct_up_3,c.pct_down_1,c.pct_down_3,
      c.breadth_score_delta_15m,c.breadth_score_delta_30m,c.breadth_coverage,c.breadth_sample_size,
      c.liquid_breadth_score,c.liquid_session_up_pct,c.liquid_session_down_pct,c.liquid_median_session_return_pct,
      c.bb_1h_mid,c.bb_1h_position,c.bb_1h_distance_pct,c.bb_4h_mid,c.bb_4h_position,c.bb_4h_distance_pct,
      c.bb_trend_context,c.trend_alignment
      FROM volume_alerts va
      JOIN signal_lifecycle l ON l.source_type='MODEL_A' AND l.source_id=va.id
      LEFT JOIN signal_market_context c ON c.source_type='MODEL_A' AND c.source_id=va.id
      WHERE va.id=? AND l.completed=1""", (int(source_id),)).fetchone()
    if not row:
        return False
    d = dict(row)
    dataset=runtime_db.execute("SELECT value FROM runtime_meta WHERE key='dataset_id'").fetchone()
    executions=[dict(r) for r in runtime_db.execute("SELECT * FROM signal_execution_results WHERE source_type='MODEL_A' AND source_id=?",(source_id,))]
    record = {
        "source_dataset":dataset[0] if dataset else 'legacy',
        "source_version": d.get("source_signal_engine_version") or d.get("signal_engine_version") or "legacy",
        "source_id": int(source_id), "symbol": d["symbol"], "direction": d["direction"],
        "signal_at": float(d.get("observation_at") or d.get("trigger_at")), "trigger_price": float(d["trigger_price"]),
        "actual_vr": d.get("actual_vr_at_trigger"), "atr_pct": d.get("atr_pct"),
        "atr_percentile_200": d.get("atr_percentile_200"), "atr_percentile_500": d.get("atr_percentile_500"),
        "trigger_move_atr_ratio": d.get("trigger_move_atr_ratio"), "directional_close_location": d.get("directional_close_location"),
        "fixed_a_plus": int(d.get("high_quality_confirmed") or 0), "a_plus_plus_trend": int(d.get("a_plus_plus_trend") or 0),
        "a_plus_plus_persistence": int(d.get("a_plus_plus_persistence") or 0), "market_spike_risk": d.get("market_spike_risk"),
        "market_direction_score": d.get("ctx_direction_score"), "market_stress_score": d.get("ctx_stress_score"),
        "breadth_status": d.get("breadth_status"), "breadth_score": d.get("breadth_score"),
        "session_up_pct": d.get("session_up_pct"), "session_down_pct": d.get("session_down_pct"),
        "session_flat_pct": d.get("session_flat_pct"), "median_session_return_pct": d.get("median_session_return_pct"),
        "pct_up_1": d.get("pct_up_1"), "pct_up_3": d.get("pct_up_3"), "pct_down_1": d.get("pct_down_1"), "pct_down_3": d.get("pct_down_3"),
        "breadth_score_delta_15m": d.get("breadth_score_delta_15m"), "breadth_score_delta_30m": d.get("breadth_score_delta_30m"),
        "breadth_coverage": d.get("breadth_coverage"), "breadth_sample_size": d.get("breadth_sample_size"),
        "liquid_breadth_score": d.get("liquid_breadth_score"), "liquid_session_up_pct": d.get("liquid_session_up_pct"),
        "liquid_session_down_pct": d.get("liquid_session_down_pct"), "liquid_median_session_return_pct": d.get("liquid_median_session_return_pct"),
        "bb_1h_mid": d.get("bb_1h_mid"), "bb_1h_position": d.get("bb_1h_position"), "bb_1h_distance_pct": d.get("bb_1h_distance_pct"),
        "bb_4h_mid": d.get("bb_4h_mid"), "bb_4h_position": d.get("bb_4h_position"), "bb_4h_distance_pct": d.get("bb_4h_distance_pct"),
        "bb_trend_context": d.get("bb_trend_context"), "trend_alignment": d.get("trend_alignment"),
        "running_mfe_pct": d.get("running_mfe_pct"), "running_mae_pct": d.get("running_mae_pct"),
        "time_to_mfe_minutes": d.get("time_to_mfe_minutes"), "first_plus_1_min": d.get("first_plus_1_min"),
        "first_plus_2_min": d.get("first_plus_2_min"), "first_plus_3_min": d.get("first_plus_3_min"),
        "first_plus_5_min": d.get("first_plus_5_min"), "first_minus_1_min": d.get("first_minus_1_min"),
        "first_minus_1_5_min": d.get("first_minus_1_5_min"), "first_minus_2_min": d.get("first_minus_2_min"),
        "giveback_pct": d.get("giveback_pct"), "giveback_ratio": d.get("giveback_ratio"), "archived_at": time.time(),
        "confirmation_entry_price":d.get("a_plus_confirm_price"), "confirmation_entry_at":d.get("a_plus_confirm_at"),
        "execution_results_json":json.dumps(executions,ensure_ascii=False,allow_nan=False),
        "signal_payload_json":d.get("payload"),
    }
    for m in (1,3,5,10,15,20,30,45,60,90,120,240):
        for prefix in ("return","mfe","mae"):
            record[f"{prefix}_{m}m"] = d.get(f"{prefix}_{m}m")
    cols = list(record)
    with _connect() as adb:
        sql = f"INSERT INTO model_a_research ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)}) " \
              f"ON CONFLICT(source_dataset,source_version,source_id) DO UPDATE SET " + ",".join(f"{c}=excluded.{c}" for c in cols if c not in {"source_dataset","source_version","source_id"})
        adb.execute(sql, [record[c] for c in cols])
        adb.commit()
    return True


def archive_summary(path: Path | None = None):
    path = path or ARCHIVE_PATH
    if not path.exists():
        return {"n": 0, "latest_signal_at": None, "path": str(path)}
    with _connect(path) as db:
        r = db.execute("SELECT COUNT(*) n,MIN(signal_at) first_signal_at,MAX(signal_at) latest_signal_at FROM model_a_research").fetchone()
    return {**dict(r), "path": str(path)}


def _median(values):
    values=sorted(float(x) for x in values if x is not None)
    return statistics.median(values) if values else None


def _extension_bucket(v):
    if v is None: return "UNKNOWN"
    v=float(v)
    if v < 1: return "<1 ATR"
    if v < 2: return "1~2 ATR"
    if v < 3: return "2~3 ATR"
    return ">=3 ATR"


def _breadth_up_bucket(v):
    if v is None: return "UNKNOWN"
    v=float(v)*100
    if v < 25: return "UP<25%"
    if v < 40: return "UP25~40%"
    if v < 60: return "UP40~60%"
    if v < 75: return "UP60~75%"
    return "UP>=75%"


def _stress_bucket(v):
    if v is None: return "UNKNOWN"
    v=float(v)
    if v < 20: return "<20"
    if v < 40: return "20~40"
    if v < 60: return "40~60"
    return ">=60"


def _trend_stage(row):
    align=str(row.get("trend_alignment") or "UNKNOWN")
    ext=row.get("trigger_move_atr_ratio")
    if align == "ALIGNED":
        if ext is None: return "ALIGNED_UNKNOWN_EXTENSION"
        ext=float(ext)
        if ext < 1: return "顺势_低延伸"
        if ext < 2: return "顺势_中等延伸"
        if ext < 3: return "顺势_高延伸"
        return "顺势_过度延伸"
    if align == "OPPOSED": return "逆势"
    if align == "MIXED": return "周期混合"
    return "UNKNOWN"


def _metric(rows):
    rows = list(rows)
    if not rows:
        return {}
    def vals(k): return [float(r[k]) for r in rows if r.get(k) is not None]
    ret60=vals("return_60m"); ret120=vals("return_120m"); ret240=vals("return_240m")
    mfe=vals("running_mfe_pct"); mae=vals("running_mae_pct")
    return {
        "n": len(rows),
        "first2_before_minus1_rate": sum(_truth_before(r,"first_plus_2_min","first_minus_1_min") for r in rows)/len(rows),
        "avg_return_60m": sum(ret60)/len(ret60) if ret60 else None,
        "median_return_60m": _median(ret60),
        "avg_return_120m": sum(ret120)/len(ret120) if ret120 else None,
        "median_return_120m": _median(ret120),
        "avg_return_240m": sum(ret240)/len(ret240) if ret240 else None,
        "median_return_240m": _median(ret240),
        "positive_240m_rate": sum(x>0 for x in ret240)/len(ret240) if ret240 else None,
        "median_mfe": _median(mfe),
        "median_mae": _median(mae),
    }


def create_analysis_snapshot(path: Path | None = None, output_root: Path | None = None, source_version="4.9.0"):
    """Persist a self-contained review snapshot so the large runtime DB is disposable."""
    path = path or ARCHIVE_PATH
    output_root = output_root or (ROOT / "analysis_reports")
    stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    out = output_root / stamp
    with _connect(path) as db:
        rows = [dict(r) for r in db.execute("SELECT * FROM model_a_research WHERE source_version=? ORDER BY signal_at",(source_version,)).fetchall()]
    if not rows:
        raise RuntimeError(f"research_archive.db 暂无成熟 {source_version} Model A 样本")
    if out.exists(): out=output_root/(stamp+'_'+str(time.time_ns()))
    out.mkdir(parents=True, exist_ok=False)

    for r in rows:
        r["extension_bucket"]=_extension_bucket(r.get("trigger_move_atr_ratio"))
        r["breadth_up_bucket"]=_breadth_up_bucket(r.get("session_up_pct"))
        r["stress_bucket"]=_stress_bucket(r.get("market_stress_score"))
        r["trend_stage"]=_trend_stage(r)

    factor_rows=[]
    dimensions=["direction","breadth_status","breadth_up_bucket","stress_bucket","bb_trend_context",
                "trend_alignment","trend_stage","extension_bucket","market_spike_risk"]
    for dim in dimensions:
        values=sorted({str(r.get(dim) or "UNKNOWN") for r in rows})
        for value in values:
            group=[r for r in rows if str(r.get(dim) or "UNKNOWN")==value]
            factor_rows.append({"dimension":dim,"value":value,**_metric(group)})

    cohort_rows=[]
    keys=sorted({(str(r.get("direction") or "UNKNOWN"),str(r.get("breadth_status") or "UNKNOWN"),
                 str(r.get("trend_stage") or "UNKNOWN")) for r in rows})
    for direction,breadth,trend_stage in keys:
        group=[r for r in rows if str(r.get("direction") or "UNKNOWN")==direction
               and str(r.get("breadth_status") or "UNKNOWN")==breadth
               and str(r.get("trend_stage") or "UNKNOWN")==trend_stage]
        cohort_rows.append({"direction":direction,"breadth_status":breadth,"trend_stage":trend_stage,**_metric(group)})

    trend_context_rows=[]
    keys2=sorted({(str(r.get("direction") or "UNKNOWN"),str(r.get("bb_trend_context") or "UNKNOWN"),
                  str(r.get("extension_bucket") or "UNKNOWN")) for r in rows})
    for direction,trend,extension in keys2:
        group=[r for r in rows if str(r.get("direction") or "UNKNOWN")==direction
               and str(r.get("bb_trend_context") or "UNKNOWN")==trend
               and str(r.get("extension_bucket") or "UNKNOWN")==extension]
        trend_context_rows.append({"direction":direction,"bb_trend_context":trend,"extension_bucket":extension,**_metric(group)})

    def write_csv(name,data):
        if not data: return
        with (out/name).open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=list(data[0])); w.writeheader(); w.writerows(data)

    write_csv("factor_summary.csv",factor_rows)
    write_csv("market_trend_matrix.csv",cohort_rows)
    write_csv("trend_extension_matrix.csv",trend_context_rows)
    write_csv("signals.csv",rows)
    # One cluster per 15m market window, with direction kept separate.
    clusters=[]
    for direction,window in sorted({(r['direction'],int(r['signal_at']//900)*900) for r in rows}):
        group=[r for r in rows if r['direction']==direction and int(r['signal_at']//900)*900==window]
        clusters.append({'direction':direction,'window_open':window,**_metric(group)})
    write_csv("window_clusters.csv",clusters)
    execution_rows=[]
    for r in rows:
        for ex in json.loads(r.get('execution_results_json') or '[]'):
            execution_rows.append({**ex,'source_dataset':r['source_dataset']})
    write_csv("execution_results.csv",execution_rows)

    manifest={
        "generated_at":time.time(),"archive_version":ARCHIVE_VERSION,
        "source_versions":sorted({str(r.get("source_version") or "") for r in rows}),
        "signal_count":len(rows),"time_range":[rows[0]["signal_at"],rows[-1]["signal_at"]],
        "mature_definition":"240-minute Model-A lifecycle completed",
        "truth_metric":"First +2% before -1%",
        "breadth_session":"00:00 UTC = 08:00 UTC+8",
        "bb_definition":"SMA20 of 20 completed 1H / 4H bars before trigger; no upper/lower bands",
        "trend_stage_definition":"1H/4H middle-line alignment combined with trigger extension; research-only",
        "files":["factor_summary.csv","market_trend_matrix.csv","trend_extension_matrix.csv","signals.csv","window_clusters.csv","manifest.json","report.md"]+(["execution_results.csv"] if execution_rows else []),
    }
    (out/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")

    overall=_metric(rows)
    eligible=sorted((r for r in cohort_rows if int(r.get("n") or 0)>=30),
                    key=lambda r:(float(r.get("first2_before_minus1_rate") or -1),float(r.get("median_return_120m") or -999)),reverse=True)
    report=["# Model A Research Snapshot","",f"生成时间：{stamp}",f"成熟样本：{len(rows)}","",
            "## 总体",""]
    report.extend(f"- {k}: {v}" for k,v in overall.items())
    report += ["","## 市场环境 × 标的趋势阶段（N>=30，按真实性排序）",""]
    if eligible:
        for r in eligible[:12]:
            report.append(f"- {r['direction']} | {r['breadth_status']} | {r['trend_stage']} | N={r['n']} | First+2 before -1={r['first2_before_minus1_rate']:.1%} | Median120={r.get('median_return_120m')}")
    else:
        report.append("- 暂无达到 N>=30 的组合，继续前向积累。")
    report += ["","说明：Breadth、布林中轨趋势、Extension均为研究变量；本快照不自动生成交易过滤规则。",
               "同一15分钟窗口内信号具有相关性；请同时检查 window_clusters.csv，不能把信号数当成独立样本数。",
               "A++ 是事后持续性质量标记，不代表从触发价开始可交易的胜率；确认价执行结果单独保存在 execution_results.csv。",
               "运行数据库可以按保留策略滚动，长期历史由 research_archive.db + analysis_reports 保存。"]
    (out/"report.md").write_text("\n".join(report),encoding="utf-8")
    return {"directory":str(out),"signal_count":len(rows),"manifest":manifest}

