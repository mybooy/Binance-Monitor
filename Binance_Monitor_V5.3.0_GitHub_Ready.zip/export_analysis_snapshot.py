from research_archive import create_analysis_snapshot

if __name__ == "__main__":
    result = create_analysis_snapshot()
    print("分析快照已生成:", result["directory"])
    print("成熟 Model A 样本:", result["signal_count"])
