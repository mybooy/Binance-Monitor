"""Strict Binance USD-M perpetual symbol normalization helpers."""
import re
from collections.abc import Iterable

# Current project universe is USDT-margined perpetual futures only.  Binance
# symbols used by this service are ASCII upper-case letters/digits and end in
# USDT (for example BTCUSDT, 1000PEPEUSDT).
_USDT_SYMBOL_RE = re.compile(r"^[A-Z0-9]{1,32}USDT$")


def normalize_usdt_symbol(value):
    """Return a canonical symbol or None when *value* is not a valid project symbol."""
    if not isinstance(value, str):
        return None
    symbol = value.strip().upper()
    if not _USDT_SYMBOL_RE.fullmatch(symbol):
        return None
    return symbol


def sanitize_usdt_symbols(values: Iterable):
    """Deduplicate valid symbols while preserving order; also return rejected raw values."""
    clean = []
    rejected = []
    seen = set()
    for raw in values or ():
        symbol = normalize_usdt_symbol(raw)
        if symbol is None:
            rejected.append(raw)
            continue
        if symbol not in seen:
            clean.append(symbol)
            seen.add(symbol)
    return clean, rejected
