"""V4.8.0 BTC/ETH public-market context engine.

Research-only. It consumes Binance public Spot/USDT-M data and never gates
Model A. The latest state lives in memory so a signal can freeze one
trigger-time context snapshot. Any upstream failure degrades to UNKNOWN instead
of blocking the scanner.
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import statistics
import time
from collections import defaultdict, deque

import aiohttp

from config import config

logger = logging.getLogger("v4.market_state")


def _clip(x, lo, hi):
    return max(lo, min(hi, float(x)))


def _pct(a, b):
    return (float(a) / float(b) - 1.0) * 100.0 if float(b) else 0.0




def _classify_state(direction, stress):
    direction=float(direction); stress=float(stress)
    if stress >= 70 and direction <= -25:
        return "PANIC", "恐慌"
    if stress >= 70 and direction >= 25:
        return "EUPHORIA", "狂热"
    if direction >= 20:
        return "BULL", "偏多"
    if direction <= -20:
        return "BEAR", "偏空"
    return "NEUTRAL", "中性"

def _zscore(x, history):
    xs = [float(v) for v in history if v is not None and math.isfinite(float(v))]
    if len(xs) < 10:
        return 0.0
    mu = statistics.mean(xs)
    sd = statistics.pstdev(xs)
    return (float(x) - mu) / sd if sd > 1e-12 else 0.0


def _kline_metrics(rows):
    now_ms = time.time() * 1000
    rows = [r for r in (rows or []) if len(r) > 10 and float(r[6]) < now_ms]
    if len(rows) < 6:
        return None
    rows = rows[-61:]
    closes = [float(r[4]) for r in rows]
    quote = [float(r[7]) for r in rows]
    taker_buy_quote = [float(r[10]) for r in rows]
    delta = [2.0*b-q for b, q in zip(taker_buy_quote, quote)]
    last = len(rows)-1
    def vel(n):
        j = max(0, last-n)
        return _pct(closes[last], closes[j])
    def imb(n):
        q = sum(quote[-n:]); d = sum(delta[-n:])
        return d/q if q > 0 else 0.0
    return {
        "price": closes[-1],
        "velocity_1m": vel(1), "velocity_3m": vel(3), "velocity_5m": vel(5),
        "taker_imbalance_1m": imb(1), "taker_imbalance_3m": imb(3), "taker_imbalance_5m": imb(5),
        "cvd_1m": sum(delta[-1:]), "cvd_3m": sum(delta[-3:]), "cvd_5m": sum(delta[-5:]),
        "volume_z_30": _zscore(quote[-1], quote[-31:-1]),
        "volume_z_60": _zscore(quote[-1], quote[-61:-1]),
        "quote_volume_1m": quote[-1],
    }


MARKET_STATE_ENGINE_VERSION = "4.8.0"

class MarketStateEngine:
    SYMBOLS = ("BTCUSDT", "ETHUSDT")

    def __init__(self):
        self.latest = {"status":"UNKNOWN", "status_cn":"数据不足", "direction_score":0.0, "stress_score":0.0,
                       "updated_at":0.0, "engine_version":MARKET_STATE_ENGINE_VERSION, "reason":"等待首次采样", "assets":{}}
        self._oi = defaultdict(lambda: deque(maxlen=10))
        self._liquidations = defaultdict(lambda: deque(maxlen=5000))
        self._session = None
        self._liq_task = None
        self._running = False

    async def _session_obj(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()),
                                                  timeout=aiohttp.ClientTimeout(total=30))
        return self._session

    async def start(self):
        self._running = True
        if self._liq_task is None or self._liq_task.done():
            self._liq_task = asyncio.create_task(self._liquidation_loop(), name="market-state-liquidation")

    async def close(self):
        self._running = False
        if self._liq_task:
            self._liq_task.cancel()
            await asyncio.gather(self._liq_task, return_exceptions=True)
        if self._session and not self._session.closed:
            await self._session.close()

    async def _liquidation_loop(self):
        url = "wss://fstream.binance.com/stream?streams=btcusdt@forceOrder/ethusdt@forceOrder"
        while self._running:
            try:
                session = await self._session_obj()
                async with session.ws_connect(url, heartbeat=20, proxy=config.proxy_url if config.use_proxy else None) as ws:
                    async for msg in ws:
                        if msg.type != aiohttp.WSMsgType.TEXT:
                            continue
                        payload = json.loads(msg.data)
                        data = payload.get("data", payload)
                        if data.get("e") != "forceOrder":
                            continue
                        o = data.get("o") or {}; symbol = o.get("s")
                        if symbol not in self.SYMBOLS:
                            continue
                        side = str(o.get("S") or "").upper()
                        price = float(o.get("ap") or o.get("p") or 0); qty = float(o.get("z") or o.get("q") or 0)
                        notional = max(0.0, price*qty); ts = float(data.get("E") or o.get("T") or time.time()*1000)/1000.0
                        # Forced SELL closes longs; forced BUY closes shorts.
                        kind = "LONG_LIQ" if side == "SELL" else "SHORT_LIQ" if side == "BUY" else "UNKNOWN"
                        self._liquidations[symbol].append((ts, kind, notional))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("Liquidation stream degraded | %s", type(exc).__name__)
                await asyncio.sleep(5)

    def _liq_metrics(self, symbol):
        now = time.time(); cutoff = now - 5*60
        dq = self._liquidations[symbol]
        while dq and dq[0][0] < now-config.liquidation_retention_minutes*60:
            dq.popleft()
        long_liq = sum(n for ts,k,n in dq if ts >= cutoff and k == "LONG_LIQ")
        short_liq = sum(n for ts,k,n in dq if ts >= cutoff and k == "SHORT_LIQ")
        total = long_liq + short_liq
        imbalance = (short_liq-long_liq)/total if total > 0 else 0.0
        return {"long_liquidation_5m":long_liq, "short_liquidation_5m":short_liq,
                "liquidation_imbalance":imbalance, "liquidation_total_5m":total}

    async def _rest_json(self, base_url, path, **params):
        # Deliberately isolated from the scanner's MarketClient. A 429/timeout here must never
        # put Model A/B into the main REST client's shared cooldown state.
        session = await self._session_obj()
        async with session.get(base_url + path, params=params,
                               proxy=config.proxy_url if config.use_proxy else None) as resp:
            if resp.status in (418, 429):
                raise RuntimeError(f"market-state rate limited: HTTP {resp.status}")
            resp.raise_for_status()
            return await resp.json()

    async def _fetch_symbol(self, symbol):
        lim = int(config.market_state_history_minutes)
        spot_kl, fut_kl, oi = await asyncio.wait_for(asyncio.gather(
            self._rest_json("https://api.binance.com", "/api/v3/klines", symbol=symbol, interval="1m", limit=lim),
            self._rest_json("https://fapi.binance.com", "/fapi/v1/klines", symbol=symbol, interval="1m", limit=lim),
            self._rest_json("https://fapi.binance.com", "/fapi/v1/openInterest", symbol=symbol),
        ), timeout=float(config.market_state_rest_timeout_seconds))
        spot = _kline_metrics(spot_kl); fut = _kline_metrics(fut_kl)
        if not spot or not fut:
            raise RuntimeError("insufficient kline history")
        now = time.time(); oi_val = float((oi or {}).get("openInterest") or 0)
        q = self._oi[symbol]; q.append((now,oi_val))
        def oi_delta(minutes):
            if len(q) < 2 or oi_val <= 0: return None
            target = now-minutes*60
            prior = min(q, key=lambda x: abs(x[0]-target))
            return (oi_val/prior[1]-1)*100 if prior[1] > 0 and abs(prior[0]-target) <= 30 else None
        return {"spot":spot, "futures":fut, "open_interest":oi_val,
                "oi_delta_1m":oi_delta(1), "oi_delta_5m":oi_delta(5), **self._liq_metrics(symbol)}

    @staticmethod
    def _asset_direction(m):
        s=m["spot"]; f=m["futures"]
        vel = (_clip(s["velocity_1m"]/0.20,-1,1)*8 + _clip(s["velocity_3m"]/0.45,-1,1)*8 +
               _clip(s["velocity_5m"]/0.75,-1,1)*9 + _clip(f["velocity_1m"]/0.20,-1,1)*8 +
               _clip(f["velocity_3m"]/0.45,-1,1)*8 + _clip(f["velocity_5m"]/0.75,-1,1)*9)
        flow = _clip(s["taker_imbalance_3m"],-.5,.5)*20 + _clip(f["taker_imbalance_3m"],-.5,.5)*24
        trend_sign = 1 if f["velocity_5m"]>0 else -1 if f["velocity_5m"]<0 else 0
        oi_confirm = trend_sign * _clip(max(0,m["oi_delta_5m"] or 0)/1.0,0,1)*6
        liq = _clip(m["liquidation_imbalance"],-1,1)*5
        return vel+flow+oi_confirm+liq

    @staticmethod
    def _asset_stress(m):
        s=m["spot"]; f=m["futures"]
        vol = min(25, abs(s["velocity_1m"])/0.35*8 + abs(f["velocity_1m"])/0.35*8 + abs(f["velocity_5m"])/1.2*9)
        z = min(25, max(0,abs(s["volume_z_30"])-1)*6 + max(0,abs(f["volume_z_30"])-1)*7)
        oi = min(20, abs(m["oi_delta_5m"] or 0)/1.5*20)
        liq = min(30, math.log10(1+m["liquidation_total_5m"]/1_000_000)*10 if m["liquidation_total_5m"]>0 else 0)
        return min(100,vol+z+oi+liq)

    async def sample(self):
        if not config.market_state_enabled:
            self.latest={"status":"UNKNOWN","status_cn":"数据不足","direction_score":0.0,"stress_score":0.0,
                         "updated_at":time.time(),"engine_version":MARKET_STATE_ENGINE_VERSION,"reason":"市场状态研究已关闭","assets":{}}
            return self.latest
        try:
            results = await asyncio.gather(*(self._fetch_symbol(s) for s in self.SYMBOLS), return_exceptions=True)
            assets={}; errors=[]
            for symbol, r in zip(self.SYMBOLS, results):
                if isinstance(r, Exception): errors.append(f"{symbol}:{type(r).__name__}")
                else: assets[symbol]=r
            if len(assets) < 2:
                raise RuntimeError(";".join(errors) or "market state data insufficient")
            dvals=[self._asset_direction(assets[s]) for s in self.SYMBOLS]
            svals=[self._asset_stress(assets[s]) for s in self.SYMBOLS]
            for symbol,dscore,sscore in zip(self.SYMBOLS,dvals,svals):
                ast,acn=_classify_state(dscore,sscore)
                assets[symbol]["direction_score"]=round(float(dscore),2)
                assets[symbol]["stress_score"]=round(float(sscore),2)
                assets[symbol]["state"]=ast
                assets[symbol]["state_cn"]=acn
            sync = 1.0 if assets["BTCUSDT"]["futures"]["velocity_5m"]*assets["ETHUSDT"]["futures"]["velocity_5m"]>0 else -1.0
            avg_direction=sum(dvals)/len(dvals)
            direction=_clip(avg_direction+(6*sync*(1 if avg_direction>0 else -1) if abs(avg_direction)>5 else 0),-100,100)
            stress=_clip(sum(svals)/len(svals)+(8 if sync<0 else 0),0,100)
            status,cn=_classify_state(direction,stress)
            # Internal squeeze label retained for research only.
            internal="SHORT_SQUEEZE" if direction>25 and sum(a["liquidation_imbalance"] for a in assets.values())>0.8 else \
                     "LONG_SQUEEZE" if direction<-25 and sum(a["liquidation_imbalance"] for a in assets.values())<-0.8 else "NONE"
            self.latest={"status":status,"status_cn":cn,"internal_state":internal,"direction_score":round(direction,2),
                         "stress_score":round(stress,2),"btc_eth_sync":sync,"updated_at":time.time(),"engine_version":MARKET_STATE_ENGINE_VERSION,"reason":"",
                         "data_quality":"OK" if not errors else "DEGRADED","assets":assets}
        except Exception as exc:
            logger.warning("Market state sample degraded | %s", type(exc).__name__)
            self.latest={"status":"UNKNOWN","status_cn":"数据不足","direction_score":0.0,"stress_score":0.0,
                         "updated_at":time.time(),"engine_version":MARKET_STATE_ENGINE_VERSION,"reason":str(exc)[:180],"data_quality":"UNKNOWN","assets":{}}
        return self.latest


market_state_engine = MarketStateEngine()
