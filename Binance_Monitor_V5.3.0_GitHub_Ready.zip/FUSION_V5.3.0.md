# V5.3.0 Fusion 交付说明（由 V4.9.0 + V5.2.0 融合）

## 子系统边界

- **Model A**：采集与信号沿用 V4.9.0；过去20根完整15m剔除一个最高量，取其余19根均值。保持源信号版本 `4.9.0`，**不可与 V4.8.0 普通均值样本直接混合回测**。
- **Model B / Binance Leverage Radar**：保留 V4.9.0 的 OI 分位、费率/基差、杠杆拥挤结构、清算采样和持久观察池；该模型只使用 Binance 数据，绝非旧 V4.7 模型或独立交易信号。
- **Radar R1 / Three-venue**：保留 V5.2.0 的 Binance/OKX/Bybit USDT 线性永续+USDT 现货标的并集发现、统一数值、异动分类、跨所共振、240m粗采样路径、影子研究、数据质量和异步独立写库；研究源版本为 `RADAR_R1_5.2.0`。
- **独立研究**：Model A 数据在 `monitor_v4.db` / `research_archive.db`；Model B 数据在同运行库独立 `model_b_*` 表；Radar R1 数据在 `radar_v52.db`。不得统计性合并为独立样本。

## 主要融合与修复

1. 保留 V4.9.0 的迟到分钟不覆盖完整K线、前向确认价、缺口修复、缺少原始数据不删除研究路径、归档来源 dataset UUID。
2. 扩展 V5.2.0 的 worker 看门狗、历史持久性修复（仅补历史标签、不重发提醒），集中触发按“同一分钟+相同信号版本+标的去重”恢复。
3. 保留两种雷达且有各自独立 API 和前端面板；恢复 V4.8 的标准研究 API 兼容性。
4. Radar 异步 SQLite writer 具备有界队列、显式失败、写入重试与监控；研究持久文件中仅在事件成熟后删除过期的详细路径。
5. 测试两种源版本的归档及 schema，防止不同运行库 signal_id 碰撞。保留 Model B 出站通知队列，但融合包中默认**关闭 Model B Telegram**；Radar R1 默认 `shadow`。

## 限制（不是已完成生产验收）

- 三所行情采用受限 REST 轮询，不是三所所有合约的毫秒级逐笔/订单簿流；实时清算样本属于 Binance Model B，不可宣称三所完整清算覆盖。
- 跨交易所特殊合约、不同面额、现货主动成交采样与报价数据缺失都必须如实标记，**不能用 0 代替缺失**。
- 融合代码自动测试不等于 Windows 长时运行、真实交易所完整联通或任何收益策略验证。
- 对原代码路径做保守最小融合，前向事件阈值仍为研究默认值，未做历史择优调参。

## Windows 使用

在新目录解压，不要覆盖旧版。将旧 `.env` 配置与必要的 `.db` 在备份后复制到新目录。
`pip install -r requirements.txt`，运行 `start_monitor.bat`。原 Binance 雷达和 Radar R1 可以分别在 `config.json` 或 `/api/config` 中开关。
默认 Radar R1 开启影子记录，Model B 正式 Telegram 关闭；原 Model A Telegram 配置保持原流程。
本地页面 `http://127.0.0.1:8000`，参看 `/api/radar/status` 和 `/api/crowding/top`。

离线验收：`python -B run_offline_tests.py`；前端：`node tests/test_frontend.cjs`。
雷达成熟事件导出：`python export_v52_research.py`。

**安全注意**：上传的 V4.9.0 原包含 `.env`、历史 SQLite 和完整 `venv`，本交付 ZIP 刻意不包含这些隐私配置、历史运行库、Python 环境或 `__pycache__`。
