"""Runtime configuration for V4.8.0: Market Breadth + Model-A + Leverage Crowding."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from threading import RLock
from typing import Any

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config.json"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", env_file_encoding="utf-8", extra="ignore")

    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    admin_token: str = ""
    bind_host: str = "127.0.0.1"
    port: int = Field(8000, ge=1024, le=65535)
    use_proxy: bool = True
    proxy_url: str = "http://127.0.0.1:7897"

    new_symbol_min_age_hours: int = Field(72, ge=0, le=87600)
    min_24h_quote_volume: float = Field(5_000_000, ge=0)
    max_24h_quote_volume: float = Field(0, ge=0)
    model_a_min_24h_quote_volume: float = Field(5_000_000, ge=0)
    universe_refresh_minutes: int = Field(30, ge=5, le=240)
    history_bars_5m: int = Field(150, ge=100, le=1200)
    stream_shard_size: int = Field(40, ge=20, le=80)
    tradfi_blacklist: list[str] = Field(default_factory=lambda: ["SONYUSDT"])

    stream_silence_timeout_seconds: int = Field(20, ge=5, le=120)
    stream_probe_timeout_seconds: int = Field(5, ge=2, le=30)
    stream_handover_ready_timeout_seconds: int = Field(18, ge=5, le=60)
    bar_close_grace_seconds: int = Field(10, ge=3, le=60)
    min_market_completeness: float = Field(0.90, ge=0.50, le=1.0)
    request_concurrency: int = Field(6, ge=1, le=12)

    universe_rest_timeout_seconds: int = Field(25, ge=5, le=120)
    universe_warmup_timeout_seconds: int = Field(120, ge=20, le=600)
    stream_update_timeout_seconds: int = Field(30, ge=5, le=120)
    scan_cycle_timeout_seconds: int = Field(120, ge=30, le=600)
    scanner_watchdog_seconds: int = Field(45, ge=15, le=300)
    no_cycle_watchdog_seconds: int = Field(720, ge=300, le=3600)
    universe_safe_window_start_seconds: int = Field(12, ge=5, le=60)
    universe_safe_window_end_seconds: int = Field(55, ge=10, le=120)

    # Model A Core Settings
    volume_ratio_lookback_15m: int = Field(20, ge=20, le=20)
    model_a_vr_trigger: float = Field(3.00, ge=0.5, le=50)
    model_a_scan_start_minute: int = Field(5, ge=5, le=10)
    model_a_hq_atr_pct: float = Field(0.85, ge=0.0, le=20.0)
    model_a_hq_persistence_1m_pct: float = Field(0.11, ge=-10.0, le=10.0)
    vr_state_tolerance_pct: float = Field(10.0, ge=0, le=50)
    model_a_enabled: bool = True
    volume_episode_reset_vr: float = Field(2.0, ge=0.1, le=20)
    volume_episode_reset_windows: int = Field(2, ge=1, le=6)
    live_vr_scan_grace_seconds: int = Field(8, ge=3, le=30)

    atr_period_5m: int = Field(14, ge=5, le=60)
    persistence_minutes: int = Field(5, ge=3, le=5)
    model_a_dynamic_quantile: float = Field(0.75, ge=0.50, le=0.95)
    model_a_dynamic_q80_quantile: float = Field(0.80, ge=0.50, le=0.95)
    model_a_dynamic_window: int = Field(200, ge=50, le=1000)
    model_a_dynamic_min_samples: int = Field(100, ge=30, le=500)

    # Market Breadth
    market_breadth_enabled: bool = True
    breadth_poll_seconds: int = Field(60, ge=30, le=300)
    breadth_flat_band_pct: float = Field(0.10, ge=0.0, le=1.0)
    breadth_min_coverage: float = Field(0.80, ge=0.50, le=1.0)
    breadth_liquid_top_n: int = Field(100, ge=20, le=300)
    breadth_rest_timeout_seconds: int = Field(10, ge=3, le=30)
    breadth_open_warm_concurrency: int = Field(4, ge=1, le=8)
    breadth_open_warm_delay_seconds: float = Field(0.03, ge=0.0, le=1.0)

    # Trend Context
    trend_context_enabled: bool = True
    trend_context_timeout_seconds: int = Field(8, ge=3, le=30)
    trend_context_concurrency: int = Field(6, ge=1, le=12)
    bb_mid_at_tolerance_pct: float = Field(0.01, ge=0.0, le=0.5)

    telegram_repeat_resend_enabled: bool = True
    telegram_repeat_window_minutes: int = Field(30, ge=1, le=240)
    notification_max_attempts: int = Field(5, ge=1, le=10)
    notification_expiry_seconds: int = Field(1800, ge=60, le=86400)
    tracking_hours: int = Field(4, ge=1, le=4)
    tracking_reconcile_seconds: int = Field(60, ge=15, le=600)

    lifecycle_horizon_minutes: int = Field(240, ge=120, le=240)
    execution_fee_bps_per_side: float = Field(5.0, ge=0.0, le=100.0)
    execution_slippage_bps_per_side: float = Field(2.0, ge=0.0, le=100.0)
    execution_funding_cost_pct: float = Field(0.0, ge=-5.0, le=5.0)
    execution_trail_activate_pct: float = Field(2.0, ge=0.1, le=20.0)
    execution_trail_distance_pct: float = Field(1.0, ge=0.1, le=10.0)
    execution_initial_stop_pct: float = Field(1.5, ge=0.1, le=20.0)

    market_state_enabled: bool = True
    market_state_poll_seconds: int = Field(60, ge=30, le=300)
    market_state_rest_timeout_seconds: int = Field(12, ge=3, le=60)
    market_state_history_minutes: int = Field(61, ge=35, le=120)
    liquidation_retention_minutes: int = Field(10, ge=5, le=60)

    signal_path_retention_days: int = Field(7, ge=1, le=90)
    volume_observation_retention_hours: int = Field(72, ge=12, le=720)
    runtime_prune_interval_hours: int = Field(6, ge=1, le=24)

    # === 新增：杠杆拥挤预警引擎配置 (Leverage Crowding Engine) ===
    crowding_enabled: bool = True
    crowding_poll_interval_seconds: int = Field(180, ge=30, le=600)
    crowding_vr_top_n: int = Field(15, ge=5, le=30)
    crowding_cost_top_n: int = Field(10, ge=5, le=30)
    crowding_min_quote_volume: float = Field(5_000_000, ge=0)
    crowding_alert_cooldown_seconds: int = Field(1800, ge=300, le=7200)
    crowding_telegram_enabled: bool = False
    model_b_poll_seconds: int = Field(60, ge=30, le=120)
    model_b_oi_batch_size: int = Field(80, ge=10, le=120)
    model_b_max_deep_symbols: int = Field(30, ge=2, le=100)
    model_b_min_history_samples: int = Field(96, ge=48, le=288)
    model_b_watch_ttl_seconds: int = Field(1800, ge=300, le=7200)
    model_b_request_budget_seconds: int = Field(40, ge=10, le=60)
    model_b_oi_percentile_trigger: float = Field(95, ge=80, le=100)
    model_b_vr_trigger: float = Field(2, ge=1.5, le=10)

    # Radar R1 cross-venue shadow-first extension, separate from Binance Model B.
    radar_enabled: bool = True
    radar_notification_mode: str = Field('shadow', pattern='^(shadow|live)$')
    radar_poll_seconds: int = Field(75, ge=30, le=600)
    radar_discovery_minutes: int = Field(30, ge=5, le=240)
    radar_binance_oi_budget: int = Field(10, ge=0, le=35)
    radar_spot_tape_budget: int = Field(6, ge=0, le=25)
    radar_stale_seconds: int = Field(180, ge=60, le=900)
    radar_writer_max_queue: int = Field(25000, ge=1000, le=200000)
    radar_path_retention_days: int = Field(7, ge=1, le=90)
    # Keep real-time Binance model B separate, and suppress unattended new alerts by default.
    # 外部全网宏观与公共接口
    cmc_enabled: bool = True
    cmc_api_key: str = ""

    @model_validator(mode="after")
    def validate_consistency(self):
        if self.max_24h_quote_volume and self.max_24h_quote_volume < self.min_24h_quote_volume:
            raise ValueError("max_24h_quote_volume must be 0 or >= min_24h_quote_volume")
        if self.universe_safe_window_end_seconds <= self.universe_safe_window_start_seconds:
            raise ValueError("universe_safe_window_end_seconds must be greater than start")
        if self.bind_host not in {"127.0.0.1", "localhost", "::1"} and len(self.admin_token) < 24:
            raise ValueError("Non-local bind requires ADMIN_TOKEN with at least 24 characters")
        return self


SECRET_FIELDS = {"telegram_bot_token", "telegram_chat_id", "admin_token", "proxy_url", "cmc_api_key"}
PUBLIC_FIELDS = set(Settings.model_fields) - SECRET_FIELDS


class ConfigManager:
    def __init__(self):
        self._lock = RLock()
        self._settings = self._load()

    def _load(self) -> Settings:
        payload: dict[str, Any] = {}
        if CONFIG_PATH.exists():
            try:
                payload = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                payload = {}
        payload = {k: v for k, v in payload.items() if k in PUBLIC_FIELDS}
        if "tracking_hours" in payload:
            payload["tracking_hours"] = min(4, max(1, int(payload["tracking_hours"])))
        payload["volume_ratio_lookback_15m"] = 20
        if "lifecycle_horizon_minutes" in payload:
            payload["lifecycle_horizon_minutes"] = min(240, max(120, int(payload["lifecycle_horizon_minutes"])))
        return Settings(**payload)

    def __getattr__(self, name: str):
        return getattr(self._settings, name)

    def public_dict(self) -> dict[str, Any]:
        data = self._settings.model_dump()
        return {k: data[k] for k in sorted(PUBLIC_FIELDS)}

    def update_public(self, patch: dict[str, Any]) -> dict[str, Any]:
        bad = set(patch) - PUBLIC_FIELDS
        if bad:
            raise ValueError(f"不可修改字段: {', '.join(sorted(bad))}")
        with self._lock:
            current = self._settings.model_dump()
            current.update(patch)
            new_settings = Settings(**current)
            public = {k: new_settings.model_dump()[k] for k in sorted(PUBLIC_FIELDS)}
            fd, tmp = tempfile.mkstemp(prefix="config-", suffix=".json", dir=ROOT)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(public, f, ensure_ascii=False, indent=2)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp, CONFIG_PATH)
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            self._settings = new_settings
        return public


config = ConfigManager()
