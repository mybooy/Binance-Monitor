"""Model B: anomaly discovery -> correlated evidence -> warnings.

OI percentiles use previous 24h / 5m quantities; scores are not probabilities.
Legacy class supplies sector metadata and session lifecycle only.
"""
import asyncio
import json
import math
import statistics
import time

import aiohttp
from config import config
from database import load_model_b_state, persist_model_b_evaluation
from leverage_crowding import RadarResources, logger
from market_client import market_client

BENCHMARKS = ("BTCUSDT", "ETHUSDT")


def number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (ValueError, TypeError):
        return None


def percentile(value, history):
    if value is None or not history:
        return None
    # Constant history is neutral, not P100.
    return 100 * (sum(x < value for x in history) + .5 * sum(x == value for x in history)) / len(history)


class ModelBEngine(RadarResources):
    def __init__(self, data_engine):
        super().__init__(data_engine)
        self._watch = {}
        self._oi = {}
        self._oi_samples = {}
        self._oi_attempt = {}
        self._history_at = {}
        self._funding_intervals = {}
        self._funding_info_at = 0
        self._liq_connected = False
        self.updated_at = 0
        self.health = {}
        self._spot_sem = asyncio.Semaphore(4)
        self._spot_retry_at = 0

    async def start(self):
        self.symbol_state_machine = await load_model_b_state()
        for key,state in self.symbol_state_machine.items():
            watch=state.get('watch')
            if watch and watch.get('expires_at',0)>time.time():
                self._watch[key.rsplit(':',1)[0]]=watch
        await super().start()

    async def _all_market_liquidation_loop(self):
        while self._running:
            try:
                session = await self._get_session()
                async with session.ws_connect("wss://fstream.binance.com/market/ws/!forceOrder@arr",
                        heartbeat=20, proxy=config.proxy_url if config.use_proxy else None) as ws:
                    self._liq_connected = True
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            self._ingest_liquidation(json.loads(msg.data))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("Model B liquidation stream unavailable: %s", type(exc).__name__)
            finally:
                self._liq_connected = False
            if self._running:
                await asyncio.sleep(5)

    def _ingest_liquidation(self, payload):
        payload = payload.get("data", payload)
        o = payload.get("o") or {}
        symbol = str(o.get("s", ""))
        if not symbol.endswith("USDT") or o.get("S") not in ("BUY", "SELL"):
            return
        price, qty, stamp = number(o.get("ap") or o.get("p")), number(o.get("z")), number(o.get("T") or payload.get("E"))
        if price is None or qty is None or stamp is None or min(price, qty) <= 0:
            return
        kind = "LONG_LIQ" if o["S"] == "SELL" else "SHORT_LIQ"
        self._liquidations[symbol].append((stamp / 1000, kind, price * qty))

    def _get_liquidation_metrics(self, symbol):
        now = time.time()
        dq = self._liquidations[symbol]
        while dq and dq[0][0] < now - 900:
            dq.popleft()
        long = sum(v for t, side, v in dq if now-300 <= t <= now and side == "LONG_LIQ")
        short = sum(v for t, side, v in dq if now-300 <= t <= now and side == "SHORT_LIQ")
        total = long + short
        return {"liq_long_5m":long, "liq_short_5m":short, "liq_total_5m":total,
                "liq_imbalance_5m":(short-long)/total if total else 0,
                "liquidation_quality":"SAMPLED_STREAM" if self._liq_connected else "DISCONNECTED"}

    def _hour_bars(self, symbol, now):
        end = int(now // 300) * 300 - 300
        store = self.data_engine.five_klines.get(symbol, {})
        bars = [store.get(float(end-i*300)) for i in range(11, -1, -1)]
        return bars if all(b and b.get("closed") for b in bars) else []

    def _volume_ratio(self, symbol, now):
        # Same 20-minus-one rule on full 1h quote-volume blocks.
        bars = self._hour_bars(symbol, now)
        if not bars:
            return None
        start, store = bars[0]["open_at"], self.data_engine.five_klines.get(symbol, {})
        history = []
        for i in range(1, 21):
            rows = [store.get(start-i*3600+j*300) for j in range(12)]
            if not all(r and r.get("closed") for r in rows):
                return None
            history.append(sum(r["quote_volume"] for r in rows))
        baseline = self.data_engine._volume_mean(history)
        return sum(r["quote_volume"] for r in bars) / baseline if baseline > 0 else None

    async def _premiums(self):
        now = time.time()
        if now - self._funding_info_at >= 3600:
            try:
                info = await market_client.get("/fapi/v1/fundingInfo")
                if not isinstance(info, list):
                    raise ValueError("fundingInfo not a list")
                self._funding_intervals = {r["symbol"]:float(r["fundingIntervalHours"]) for r in info}
                self._funding_info_at = now
            except Exception as exc:
                logger.warning("Funding intervals unavailable: %s", type(exc).__name__)
        raw = await market_client.get("/fapi/v1/premiumIndex")
        now = time.time()
        result = {}
        for r in raw:
            symbol = r.get("symbol")
            mark, index, rate, stamp = (number(r.get(k)) for k in ("markPrice", "indexPrice", "lastFundingRate", "time"))
            if None in (mark,index,rate,stamp) or index <= 0 or mark <= 0 or not -5 <= now-stamp/1000 <= 180:
                continue
            # fundingInfo lists adjustments; unlisted contracts use the standard 8h.
            hours = self._funding_intervals.get(symbol,8) if now-self._funding_info_at < 7200 else None
            result[symbol] = {"basis_pct":(mark/index-1)*100, "funding_rate":rate,
                "funding_interval_hours":hours, "funding_apr":rate*24/hours*365*100 if hours and hours>0 else None,
                "sampled_at":stamp/1000}
        return result

    async def _sample_oi(self, symbol):
        now = time.time()
        self._oi_attempt[symbol] = now
        try:
            raw = await market_client.get("/fapi/v1/openInterest", symbol=symbol)
            now = time.time()
            value, ts = number(raw.get("openInterest")), number(raw.get("time"))
            if value is None or value <= 0 or ts is None or not -5 <= now-ts/1000 <= 180:
                raise ValueError("invalid OI")
            self._oi[symbol] = (ts/1000,value)
            if now-self._history_at.get(symbol,0) >= 300:
                rows = await market_client.get("/futures/data/openInterestHist", symbol=symbol, period="5m", limit=289)
                history = {}
                for r in rows:
                    t,v = number(r.get("timestamp")),number(r.get("sumOpenInterest"))
                    if t is not None and v is not None and v>0 and now-86400 <= t/1000 <= now-300:
                        history[t/1000] = v
                self._oi_samples[symbol] = sorted(history.items())
                self._history_at[symbol] = now
        except Exception as exc:
            logger.debug("Model B OI unavailable | %s | %s",symbol,type(exc).__name__)

    def _oi_evidence(self, symbol, now):
        ts,value = self._oi.get(symbol,(0,None))
        hist = [(t,v) for t,v in self._oi_samples.get(symbol,[]) if now-86400 <= t <= now-300]
        ready = bool(hist and len(hist)>=config.model_b_min_history_samples and hist[-1][0]>=now-900)
        fresh = value is not None and -5 <= now-ts <= 180
        values = [v for _,v in hist]
        sd = statistics.pstdev(values) if ready else 0
        return {"oi":value if fresh else None, "oi_sampled_at":ts,
            "oi_history_samples":len(hist), "oi_history_ready":ready and fresh,
            "oi_percentile":percentile(value,values) if ready and fresh else None,
            "oi_zscore":((value-statistics.mean(values))/sd if sd>1e-9 else 0) if ready and fresh else None,
            "oi_change_pct":(value/values[-1]-1)*100 if ready and fresh else None}

    def _discovery(self, symbols, qv, premiums, now):
        for s in sorted(symbols):
            if s in BENCHMARKS or qv.get(s,0)<config.crowding_min_quote_volume:
                continue
            reasons = []
            oi = self._oi_evidence(s,now)
            if oi["oi_percentile"] is not None and oi["oi_percentile"]>=config.model_b_oi_percentile_trigger:
                reasons.append("OI_HIGH_PERCENTILE")
            vr = self._volume_ratio(s,now)
            if vr is not None and vr>=config.model_b_vr_trigger:
                reasons.append("VOLUME_SURGE")
            prem = premiums.get(s,{})
            apr,basis = prem.get("funding_apr"),prem.get("basis_pct")
            if apr is not None and abs(apr)>=25: reasons.append("FUNDING_EXTREME")
            if basis is not None and abs(basis)>=.15: reasons.append("BASIS_EXTREME")
            if reasons:
                old = self._watch.get(s,{})
                self._watch[s] = {"reasons":reasons, "first_seen_at":old.get("first_seen_at",now),
                                  "expires_at":now+config.model_b_watch_ttl_seconds}
        self._watch = {s:v for s,v in self._watch.items() if s in symbols and v["expires_at"]>now}
        queued = sorted(self._watch,key=lambda s:(self.monitored_snapshots.get(s,{}).get("sampled_at",0),s))
        return list(BENCHMARKS)+queued[:config.model_b_max_deep_symbols]

    async def _spot_hour(self, symbol, bars):
        if not bars or time.time()<self._spot_retry_at:
            return None
        async with self._spot_sem:
            try:
                if time.time()<self._spot_retry_at: return None
                session = await self._get_session()
                async with session.get("https://api.binance.com/api/v3/klines",params={"symbol":symbol,
                    "interval":"5m", "startTime":int(bars[0]["open_at"]*1000),
                    "endTime":int((bars[-1]["open_at"]+300)*1000)-1,"limit":12},
                    proxy=config.proxy_url if config.use_proxy else None) as resp:
                    if resp.status in (418,429):
                        self._spot_retry_at = time.time()+max(60,float(resp.headers.get("Retry-After",60)))
                        return None
                    resp.raise_for_status()
                    raw = await resp.json()
                if len(raw)!=12 or [float(r[0])/1000 for r in raw]!=[b["open_at"] for b in bars]: return None
                volumes = [number(r[7]) for r in raw]
                return sum(volumes) if all(v is not None and v>=0 for v in volumes) else None
            except Exception:
                return None

    def _evaluate(self, symbol, prem, spot, market_state, now):
        oi = self._oi_evidence(symbol,now)
        bars,vr = self._hour_bars(symbol,now),self._volume_ratio(symbol,now)
        apr,basis = prem.get("funding_apr"),prem.get("basis_pct")
        if not -5 <= now-prem.get("sampled_at",0) <= 180:
            apr = basis = None
        direction = "UNKNOWN"
        if apr is not None and basis is not None:
            if apr>0 and basis>=0: direction="LONG"
            elif apr<0 and basis<=0: direction="SHORT"
        clv = ret = ratio = None
        if bars:
            hi,lo,close = max(b["high"] for b in bars),min(b["low"] for b in bars),bars[-1]["close"]
            clv = (close-lo)/(hi-lo) if hi>lo else .5
            ret = (close/bars[0]["open"]-1)*100
            ratio = sum(b["quote_volume"] for b in bars)/spot if spot is not None and spot>0 else None
        pct = oi["oi_percentile"]
        crowded = pct is not None and pct>=90 and apr is not None and abs(apr)>=12 and direction!="UNKNOWN"
        previous=self.symbol_state_machine.get(symbol+":"+direction,{})
        crowded_at=now if crowded else previous.get("crowding_evidence_at",0)
        recently_crowded=bool(crowded_at and 0<=now-crowded_at<=config.model_b_watch_ttl_seconds)
        structure = bool(bars and ((direction=="LONG" and clv<=.35) or (direction=="SHORT" and clv>=.65)))
        components = {"oi":30 if pct is not None and pct>=90 else 15 if pct is not None and pct>=75 else 0,
            "cost":(15 if apr is not None and abs(apr)>=25 else 10 if apr is not None and abs(apr)>=12 else 0)
                   +(10 if basis is not None and abs(basis)>=.15 else 6 if basis is not None and abs(basis)>=.08 else 0),
            "spot_divergence":20 if ratio is not None and ratio>=6 else 10 if ratio is not None and ratio>=3 else 0,
            "price_structure":15 if structure else 0}
        score = sum(components.values())
        liq = self._get_liquidation_metrics(symbol)
        # OI often drops during an unwind; retain earlier crowding evidence for the watch TTL.
        unwind = (crowded or recently_crowded) and structure and self._liq_connected and liq["liq_total_5m"]>=100000 and (
            (direction=="LONG" and liq["liq_long_5m"]>2*liq["liq_short_5m"]) or
            (direction=="SHORT" and liq["liq_short_5m"]>2*liq["liq_long_5m"]))
        missing=[]
        if not oi["oi_history_ready"]: missing.append("OI_HISTORY_OR_CURRENT")
        if apr is None or basis is None: missing.append("FUNDING_OR_BASIS")
        if not bars: missing.append("PRICE_BARS")
        if ratio is None: missing.append("MATCHED_SPOT_VOLUME")
        if vr is None: missing.append("VOLUME_HISTORY")
        level = 4 if unwind and not missing else 3 if crowded and structure and score>=60 and not missing else 2 if crowded else 1 if symbol in self._watch else 0
        names=("NORMAL","WATCH","CROWDED","FRAGILE","UNWINDING")
        labels=("常态","异常观察","持仓拥挤","结构脆弱","清算风险已出现")
        return {"model":"MODEL_B","engine_version":"4.9.0","symbol":symbol,"is_benchmark":symbol in BENCHMARKS,
            "direction":direction,"score":score,"level":level,"level_name":names[level],"level_cn":labels[level],
            "sector":self.symbol_to_sector.get(symbol,"OTHER"),"vr_1h":vr,**oi,
            "funding_apr":apr,"funding_interval_hours":prem.get("funding_interval_hours"),"basis_pct":basis,
            "fs_ratio":ratio,"clv":clv,"return_1h_pct":ret,"funding_percentile":None,"basis_percentile":None,
            "sub_scores":components,"trigger_reasons":self._watch.get(symbol,{}).get("reasons",["MARKET_BENCHMARK"] if symbol in BENCHMARKS else []),
            "data_quality":"OK" if not missing else "INCOMPLETE","missing_data":missing,
            "oi_history_window":"24h / 5m / quantity","sampled_at":now,"market_context":market_state,
            "structural_weakness":structure,"crowding_evidence_at":crowded_at,**liq}

    @staticmethod
    def _alert_text(data):
        title=f"模型B｜{data['symbol']}｜{data['level_cn']}"
        body=(f"拥挤侧：{data['direction']}｜证据分：{data['score']}\n"
            f"触发因素：{', '.join(data['trigger_reasons'])}\n"
            f"OI 过去24小时分位：P{data['oi_percentile']:.1f}｜样本：{data['oi_history_samples']}\n"
            f"资金费率 APR：{data['funding_apr']:+.2f}%（周期 {data['funding_interval_hours']}h）\n"
            f"同一小时合约/现货成交额：{data['fs_ratio']:.2f}倍\n"
            f"采样清算额：${data['liq_total_5m']:,.0f}｜非全量统计\n"
            "分数不是概率；该提示描述拥挤侧风险，不是开仓指令。")
        return title,body

    async def scan_and_evaluate(self, symbols, quote_volume_24h, market_state):
        self.reload_sector_map()
        now=time.time()
        universe={s for s in symbols if quote_volume_24h.get(s,0)>=config.crowding_min_quote_volume}|set(BENCHMARKS)
        try: premiums=await self._premiums()
        except Exception as exc:
            logger.warning("Model B premium batch unavailable: %s",type(exc).__name__)
            premiums={}
        batch=sorted(universe-set(BENCHMARKS),key=lambda s:(self._oi_attempt.get(s,0),s))[:config.model_b_oi_batch_size]
        try:
            await asyncio.wait_for(asyncio.gather(*(self._sample_oi(s) for s in [*BENCHMARKS,*batch])),
                                   timeout=config.model_b_request_budget_seconds)
        except asyncio.TimeoutError:
            logger.warning("Model B OI sweep budget exhausted; partial coverage retained")
        targets=self._discovery(universe,quote_volume_24h,premiums,time.time())
        try:
            await asyncio.wait_for(asyncio.gather(*(self._sample_oi(s) for s in targets if s not in batch and s not in BENCHMARKS)),
                                   timeout=config.model_b_request_budget_seconds)
        except asyncio.TimeoutError:
            logger.warning("Model B verification budget exhausted")
        async def evaluate(s):
            spot=await self._spot_hour(s,self._hour_bars(s,time.time()))
            return self._evaluate(s,premiums.get(s,{}),spot,dict(market_state),time.time())
        results=await asyncio.gather(*(evaluate(s) for s in targets))
        for res in results:
            s,stamp=res["symbol"],res["sampled_at"]
            key=s+":"+res["direction"]
            prev=self.symbol_state_machine.get(key,{})
            streak=prev.get("streak",0)+1 if res["level"]>=3 and stamp-prev.get("sampled_at",0)<=config.model_b_poll_seconds*3 else int(res["level"]>=3)
            alert=res["data_quality"]=="OK" and res["level"]>=3 and (streak>=2 or res["level"]==4) and (
                stamp-prev.get("last_alert_at",0)>=config.crowding_alert_cooldown_seconds or res["level"]>prev.get("last_alert_level",0))
            state={"level":res["level"],"streak":streak,"sampled_at":stamp,
                "watch":self._watch.get(s),
                "crowding_evidence_at":res["crowding_evidence_at"],
                "last_alert_at":stamp if alert else prev.get("last_alert_at",0),
                "last_alert_level":res["level"] if alert else prev.get("last_alert_level",0)}
            title,body=self._alert_text(res) if alert else (None,None)
            await persist_model_b_evaluation(key,state,res,title,body)
            self.symbol_state_machine[key]=state
            self.monitored_snapshots[s]=res
        self.monitored_snapshots={s:r for s,r in self.monitored_snapshots.items() if s in self._watch or s in BENCHMARKS}
        self.top_monitored_symbols=sorted(self.monitored_snapshots,key=lambda s:(s not in BENCHMARKS,-self.monitored_snapshots[s]["level"],s))
        self.updated_at=time.time()
        fresh=sum(self.updated_at-self._oi.get(s,(0,None))[0]<=180 for s in universe)
        self.health={"universe":len(universe),"oi_fresh_symbols":fresh,"oi_batch_size":len(batch),
            "estimated_oi_sweep_seconds":math.ceil(max(0,len(universe)-2)/config.model_b_oi_batch_size)*config.model_b_poll_seconds,
            "watch_count":len(self._watch),"deep_count":len(targets),"queued_count":max(0,len(self._watch)-(len(targets)-2)),
            "scan_duration_seconds":round(self.updated_at-now,1),"liquidation_connected":self._liq_connected}
        return results
