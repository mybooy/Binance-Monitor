"""V4.8.0 Market Breadth & Model-A Research Core + Leverage Crowding Warning Radar."""
from __future__ import annotations

import asyncio
import hmac
import logging
import statistics
import sys
import time
from collections import deque
from contextlib import asynccontextmanager

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import uvicorn
from config import ROOT, config
from data_engine import DataEngine, classify_volume_state
from database import (
    backfill_due_alerts,
    close_volume_episode,
    confirm_high_quality_and_enqueue,
    context_research_matrix,
    create_research_analysis_snapshot,
    direction_comparison_stats,
    enqueue_a_plus_plus_notification,
    enqueue_volume_notification,
    execution_research_stats,
    expire_stale_volume_episodes,
    finalize_trigger_actual,
    init_db,
    initial_context_research_stats,
    load_active_volume_episodes,
    mark_dynamic_q75,
    mark_dynamic_q80,
    mark_pending_confirmations_incomplete,
    pending_close_persistence_alerts,
    pending_persistence_alerts,
    prune_runtime_research_data,
    recent_crowding_alerts,
    recent_model_b_alerts,
    recent_signal_lifecycle,
    recent_volume_alerts,
    recent_volume_episodes,
    record_volume_observation,
    research_dashboard_summary,
    return_curve_stats,
    rolling_a_plus_thresholds,
    set_market_spike_count,
    signal_path,
    start_volume_episode,
    update_close_persistence,
    update_lifecycle_live,
    update_live_tracking,
    update_persistence,
    update_volume_episode,
    volume_alert_stats,
)
from external_adapters import external_aggregator
from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from model_b import ModelBEngine, BENCHMARKS
from radar_v52 import RadarEngine
from reliability_v52 import backfill_persistence, recompute_spike_counts
from market_breadth import market_breadth_engine
from market_client import market_client
from market_state import market_state_engine
from notifier import notifier
from pydantic import ValidationError
from stream_hub import StreamHub
from symbol_utils import normalize_usdt_symbol
from trend_context import trend_context_engine

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("v4")

engine = DataEngine()
streams = StreamHub(engine)
crowding_engine = ModelBEngine(engine)
radar = RadarEngine()

eligible_symbols = frozenset()
all_perpetual_symbols = frozenset()
quote_volume_24h: dict[str, float] = {}
last_processed_bucket = None
last_live_observation = None
processed_live_minutes = {}
context_history = {"market_state":deque(maxlen=10),"market_breadth":deque(maxlen=10)}
repair_attempts = {}
volume_episode_cache: dict[str, dict] = {}
runtime_tasks = {}
universe_lock = asyncio.Lock()
LOCAL = {"127.0.0.1", "localhost", "::1"}

state = {
    "model_a": [],
    "volume_alerts": [],
    "last_vr10_observation": 0.0,
    "active_volume_episodes": 0,
    "live_volume_coverage": 0.0,
    "last_cycle": 0.0,
    "last_volume_alerts": 0,
    "last_scan_decision": 0.0,
    "scanner_heartbeat": 0.0,
    "scanner_restarts": 0,
    "warmup": "等待启动",
    "universe_status": "WAITING",
    "universe_last_success": 0.0,
    "universe_last_attempt": 0.0,
    "universe_last_error": "",
    "market_state_samples": 0,
    "breadth_samples": 0,
    "last_prune": 0.0,
    "last_prune_result": {},
    "last_recovery": 0.0, "recovery_result": {}, "task_restarts": {},
}


def authorized(request: Request):
    if config.admin_token:
        supplied = request.headers.get("authorization", "").removeprefix("Bearer ") or request.cookies.get("monitor_session", "")
        return hmac.compare_digest(supplied, config.admin_token)
    return request.client is not None and request.client.host in LOCAL


def _public_symbol(item, now_ms):
    symbol = normalize_usdt_symbol(item.get("symbol"))
    return bool(
        symbol
        and item.get("contractType") == "PERPETUAL"
        and item.get("quoteAsset") == "USDT"
        and item.get("status") == "TRADING"
        and now_ms - int(item.get("onboardDate", now_ms)) >= config.new_symbol_min_age_hours * 3600000
    )


async def warmup_symbols(symbols):
    if not symbols:
        return set()
    bars = engine.required_history_5m()
    state["warmup"] = f"预热 {len(symbols)} 个标的 / {bars} 根5m"
    sem = asyncio.Semaphore(config.request_concurrency)
    warmed = set()

    async def one(symbol):
        async with sem:
            try:
                raw = await market_client.get("/fapi/v1/klines", symbol=symbol, interval="5m", limit=bars)
                engine.ingest_history_5m(symbol, raw)
                warmed.add(symbol)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("Warmup failed | %s | %s", symbol, type(exc).__name__)

    await asyncio.gather(*(one(s) for s in symbols))
    state["warmup"] = f"完成 {len(warmed)}/{len(symbols)}"
    return warmed


async def _fetch_24h_quote_volumes():
    tickers = await market_client.get("/fapi/v1/ticker/24hr")
    return {
        normalize_usdt_symbol(x.get("symbol")): float(x.get("quoteVolume", 0) or 0)
        for x in tickers
        if isinstance(x, dict) and normalize_usdt_symbol(x.get("symbol"))
    }


async def _build_universe_candidate():
    global all_perpetual_symbols, quote_volume_24h
    info, qv = await asyncio.wait_for(
        asyncio.gather(market_client.get("/fapi/v1/exchangeInfo"), _fetch_24h_quote_volumes()),
        timeout=config.universe_rest_timeout_seconds,
    )
    quote_volume_24h = qv
    now_ms = time.time() * 1000
    base = {normalize_usdt_symbol(x.get("symbol")) for x in info.get("symbols", []) if _public_symbol(x, now_ms)}
    base.discard(None)
    base -= set(config.tradfi_blacklist)
    all_perpetual_symbols = frozenset(base)
    floor = min(config.min_24h_quote_volume, config.model_a_min_24h_quote_volume, config.crowding_min_quote_volume)
    selected = {
        s for s in base
        if qv.get(s, 0) >= floor and (config.max_24h_quote_volume <= 0 or qv.get(s, 0) <= config.max_24h_quote_volume)
    }
    return selected | (set(BENCHMARKS) & base)


async def refresh_universe(force=False):
    global eligible_symbols
    now = time.time()
    if not force and state["universe_last_success"] and now - state["universe_last_success"] < config.universe_refresh_minutes * 60:
        return False
    if universe_lock.locked():
        return False
    async with universe_lock:
        state["universe_last_attempt"] = time.time()
        state["universe_status"] = "REFRESHING"
        old = eligible_symbols
        try:
            selected = frozenset(await _build_universe_candidate())
            if not selected:
                raise RuntimeError("candidate universe is empty")
            new = sorted(selected - old)
            warmed = set()
            if new:
                warmed = await asyncio.wait_for(warmup_symbols(new), timeout=config.universe_warmup_timeout_seconds)
            effective = frozenset((selected & old) | warmed | (set(BENCHMARKS) & selected))
            if not effective:
                raise RuntimeError("no symbols passed warmup")
            await asyncio.wait_for(streams.start(effective), timeout=config.stream_update_timeout_seconds)
            eligible_symbols = effective
            market_breadth_engine.set_universe(all_perpetual_symbols, quote_volume_24h, engine)
            state["universe_last_success"] = time.time()
            state["universe_last_error"] = ""
            state["universe_status"] = "OK"
            logger.info("Universe refresh OK | ModelA=%s | breadth=%s", len(effective), len(all_perpetual_symbols))
            return True
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            state["universe_status"] = "FAILED_KEEP_LAST"
            state["universe_last_error"] = f"{type(exc).__name__}: {exc}"
            logger.exception("Universe refresh FAILED")
            return False


def _scanner_target_bucket(now):
    return float(int((now - config.bar_close_grace_seconds) // 300) * 300 - 300)


def _universe_refresh_safe(now):
    if last_processed_bucket is None or not state["last_scan_decision"]:
        return False
    phase = now % 300
    if not (config.universe_safe_window_start_seconds <= phase <= config.universe_safe_window_end_seconds):
        return False
    expected = _scanner_target_bucket(now)
    return float(last_processed_bucket) == expected and now - state["last_scan_decision"] <= max(60, config.universe_safe_window_end_seconds)


async def universe_loop():
    while True:
        try:
            now = time.time()
            due = (
                not eligible_symbols
                or not state["universe_last_success"]
                or now - state["universe_last_success"] >= config.universe_refresh_minutes * 60
            )
            if due and now - state["universe_last_attempt"] >= 30 and (not eligible_symbols or _universe_refresh_safe(now)):
                await refresh_universe(force=True)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("universe loop failed")
        await asyncio.sleep(2)


def _direction_from_live(f):
    r = float(f.get("return_live_pct", f.get("return_10m_pct", 0)) or 0)
    if r > 0:
        return "LONG", "LIVE_PRICE"
    if r < 0:
        return "SHORT", "LIVE_PRICE"
    m = float(f.get("last_minute_return_pct", 0) or 0)
    if m > 0:
        return "LONG", "LAST_1M_TIEBREAK"
    if m < 0:
        return "SHORT", "LAST_1M_TIEBREAK"
    return ("LONG", "CLOSE_LOCATION_TIEBREAK") if float(f.get("close_location", 0.5)) >= 0.5 else ("SHORT", "CLOSE_LOCATION_TIEBREAK")


def build_model_a_event(f, qv):
    if not config.model_a_enabled:
        return None
    qv = float(qv or 0)
    if qv <= config.model_a_min_24h_quote_volume or f["vr_live_actual"] < config.model_a_vr_trigger:
        return None
    direction, basis = _direction_from_live(f)
    directional_clv = f.get("close_location", 0.5) if direction == "LONG" else 1.0 - f.get("close_location", 0.5)
    return {
        **f,
        "model": "MODEL_A",
        "model_name": "早期实际放量突破",
        "direction": direction,
        "direction_basis": basis,
        "volume_state": "FIRST_BREAKOUT",
        "directional_close_location": directional_clv,
        "quote_volume_24h": qv,
    }


def _telegram_model_a(event):
    direction = "做多" if event["direction"] == "LONG" else "做空"
    start = time.strftime("%m-%d %H:%M", time.localtime(event["bar_15m_open_at"]))
    obs = time.strftime("%H:%M", time.localtime(event["observation_at"]))
    ms = event.get("market_state") or {}
    br = event.get("market_breadth") or {}
    tr = event.get("trend_context") or {}
    positions = {"ABOVE":"上", "BELOW":"下", "AT":"附近", "UNKNOWN":"未知"}
    title = f"⚡ 模型A {direction}｜{event['symbol']}"
    body = (
        f"15分钟窗口：{start}–{time.strftime('%H:%M', time.localtime(event['bar_15m_open_at'] + 900))}｜触发：{obs}\n"
        f"实际量比：{event['vr_live_actual']:.2f}倍｜窗口涨跌：{event['return_live_pct']:+.2f}%\n"
        f"全市场广度：{br.get('status', 'UNKNOWN')}｜下跌{float(br.get('session_down_pct') or 0)*100:.0f}%｜BTC状态：{ms.get('status', 'UNKNOWN')}\n"
        f"1小时中轨{positions.get(tr.get('bb_1h_position'), '未知')} / 4小时中轨{positions.get(tr.get('bb_4h_position'), '未知')}\n"
        f"触发价：{event['price']}"
    )
    return title, body


async def process_bucket(bucket, symbols):
    global last_processed_bucket
    state["last_cycle"] = time.time()
    state["last_scan_decision"] = time.time()
    last_processed_bucket = bucket


async def cycle_loop():
    global last_processed_bucket
    state["scanner_heartbeat"] = time.time()
    state["last_scan_decision"] = time.time()
    while True:
        try:
            state["scanner_heartbeat"] = time.time()
            symbols = eligible_symbols
            if symbols:
                now = time.time()
                bucket = _scanner_target_bucket(now)
                if bucket > 0 and bucket != last_processed_bucket:
                    ratio = engine.completion_ratio(symbols, bucket)
                    if ratio >= config.min_market_completeness:
                        await process_bucket(bucket, symbols)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("cycle failed")
        await asyncio.sleep(5)


def _target_closed_minute(now):
    observation = float(int((now - config.live_vr_scan_grace_seconds) // 60) * 60)
    return observation - 60


async def _process_live_volume_observation(closed_minute_open, symbols):
    global quote_volume_24h, volume_episode_cache
    observation_at = float(closed_minute_open) + 60
    feats = [f for sym in sorted(symbols) if (f := engine.live_vr_snapshot(sym, closed_minute_open))]
    state["live_volume_coverage"] = len(feats) / max(len(symbols), 1)
    for symbol,ep in list(volume_episode_cache.items()):
        if observation_at-float(ep.get("last_observation_at",observation_at)) > 3600:
            await close_volume_episode(ep["id"],"OBSERVATION_GAP")
            volume_episode_cache.pop(symbol,None)

    candidates = []
    for f in feats:
        symbol = f["symbol"]
        ep = volume_episode_cache.get(symbol)
        if ep:
            if observation_at <= float(ep.get("last_observation_at",0)):
                continue
            volume_state = classify_volume_state(f["vr_live_actual"], ep.get("last_actual_vr",0))
            below = int(ep.get("below_reset_windows",0))
            if f["elapsed_minutes"] == 15:
                below = below+1 if f["vr_live_actual"] < config.volume_episode_reset_vr else 0
                await finalize_trigger_actual(ep["id"],f["bar_15m_open_at"],f["vr_live_actual"],config.model_a_vr_trigger)
            await update_volume_episode(ep["id"],f,volume_state,below)
            await record_volume_observation(f,ep["id"],volume_state)
            ep.update(last_observation_at=observation_at,last_actual_vr=f["vr_live_actual"],below_reset_windows=below)
            if below >= config.volume_episode_reset_windows:
                await close_volume_episode(ep["id"],"VOLUME_RESET")
                volume_episode_cache.pop(symbol,None)
            continue
        c = build_model_a_event(f, quote_volume_24h.get(f["symbol"], 0.0))
        if c:
            c["market_state"] = _asof_context(market_state_engine.latest, observation_at, "market_state")
            c["market_breadth"] = _asof_context(market_breadth_engine.latest, observation_at, "market_breadth")
            candidates.append(c)

    async def attach_trend(c):
        c["trend_context"] = await trend_context_engine.snapshot(c["symbol"],c["observation_at"],c["price"])
        c["trend_context"]["trend_alignment"] = trend_context_engine.alignment(c["direction"],c["trend_context"])
    await asyncio.gather(*(attach_trend(c) for c in candidates))
    new_a = []
    for c in candidates:
        ep_id, a_id = await start_volume_episode(c,notification=_telegram_model_a(c))
        if a_id:
            volume_episode_cache[c["symbol"]] = {"id":ep_id,"symbol":c["symbol"],
                "last_observation_at":observation_at,"last_actual_vr":c["vr_live_actual"],"below_reset_windows":0}
            c["alert_id"] = a_id
            new_a.append(c)
            await record_volume_observation(c,ep_id,"FIRST_BREAKOUT")

    if new_a:
        state["model_a"] = new_a
    await set_market_spike_count([c["alert_id"] for c in new_a],len(new_a))
    state["active_volume_episodes"] = len(volume_episode_cache)


def _asof_context(context, observation_at, kind=None):
    if kind:
        choices=[x for x in [*context_history[kind],context] if 0 <= observation_at-float(x.get("sampled_at") or x.get("updated_at") or 0) <= 180]
        if choices:
            context=max(choices,key=lambda x:float(x.get("sampled_at") or x.get("updated_at") or 0))
    stamp = float(context.get("sampled_at") or context.get("updated_at") or 0)
    if not 0 <= observation_at-stamp <= 180:
        return {"status":"UNKNOWN","data_quality":"UNKNOWN","reason":"NO_FRESH_ASOF_CONTEXT"}
    return dict(context)


async def _update_signal_confirmations(observation_at, bars):
    for row in await pending_persistence_alerts(observation_at):
        bar = bars.get(row["symbol"])
        minute = int(round((observation_at-row["observation_at"])/60))
        if not bar or minute not in (1,2,3,5):
            continue
        direction = 1 if row["direction"] == "LONG" else -1
        ret = (bar["close"]/row["trigger_price"]-1)*100*direction
        if minute == 1 and row["atr_pct"] >= config.model_a_hq_atr_pct and ret >= config.model_a_hq_persistence_1m_pct:
            await confirm_high_quality_and_enqueue(row["id"],f"模型A+ 确认｜{row['symbol']}",
                f"确认价：{bar['close']}｜P1：{ret:+.3f}%｜后续收益按确认价另行计算。",
                confirm_price=bar["close"],confirm_at=observation_at)
        result = await update_persistence(row["id"],minute,ret)
        if result:
            for field,level in (("new_trend","TREND"),("new_persistence","PERSISTENCE")):
                if result[field]:
                    await enqueue_a_plus_plus_notification(row["id"],level,f"模型A++ 质量标记｜{row['symbol']}",
                        f"P1={result['p1']} / P3={result['p3']} / P5={result['p5']}。这是持续性标记，不是新的追单信号。")
    for row in await pending_close_persistence_alerts(observation_at):
        bar=bars.get(row["symbol"])
        if bar:
            ret=(bar["close"]/row["trigger_price"]-1)*100*(1 if row["direction"]=="LONG" else -1)
            which="CURRENT" if observation_at==row["window_open"]+900 else "NEXT"
            await update_close_persistence(row["id"],which,ret)


async def live_volume_loop():
    global last_live_observation
    while True:
        try:
            symbols = eligible_symbols
            if symbols:
                closed_minute = _target_closed_minute(time.time())
                observation_at = closed_minute + 60
                window_open = float(int(closed_minute // 900) * 900)
                elapsed = int((observation_at - window_open) / 60)
                # Retry late arrivals per symbol for 3 minutes; never let one missing bar consume a global checkpoint.
                for minute in (closed_minute-120,closed_minute-60,closed_minute):
                    seen=processed_live_minutes.setdefault(minute,set())
                    bars={s:b for s in symbols if s not in seen and (b:=engine.minute_klines.get(s,{}).get(float(minute))) and b.get("closed")}
                    if not bars: continue
                    await update_lifecycle_live(minute+60,bars)
                    await _update_signal_confirmations(minute+60,bars)
                    if config.model_a_scan_start_minute <= int((minute+60-int(minute//900)*900)/60) <= 15:
                        await _process_live_volume_observation(minute,set(bars))
                    seen.update(s for s in bars if int((minute+60-int(minute//900)*900)/60)<config.model_a_scan_start_minute or engine.live_vr_snapshot(s,minute))
                for minute in list(processed_live_minutes):
                    if minute < closed_minute-180: processed_live_minutes.pop(minute)
                await mark_pending_confirmations_incomplete(window_open-900)
                last_live_observation=observation_at
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("live volume loop failed")
        await asyncio.sleep(2)


async def repair_market_gaps_once():
    """Bounded REST repair; late data is research data, never a bulk stale-alert replay."""
    now=time.time()
    minute=_target_closed_minute(now)
    five=int(minute//300)*300-300
    missing=[]
    for s in eligible_symbols:
        minutes=engine.minute_klines.get(s,{})
        rows=engine.five_klines.get(s,{})
        if any(not minutes.get(minute-i*60,{}).get('closed') for i in range(15)) or any(not rows.get(five-i*300,{}).get('closed') for i in range(252)):
            missing.append(s)
    selected=sorted(missing,key=lambda s:(s not in BENCHMARKS,repair_attempts.get(s,0),s))[:12]
    async def repair(s):
        repair_attempts[s]=now
        try:
            one,five_rows=await asyncio.gather(
                market_client.get('/fapi/v1/klines',symbol=s,interval='1m',limit=30,endTime=int((minute+60)*1000)-1),
                market_client.get('/fapi/v1/klines',symbol=s,interval='5m',limit=300,endTime=int((five+300)*1000)-1))
            engine.ingest_history_5m(s,five_rows)
            for r in sorted(one,key=lambda x:x[0]):
                if float(r[6])/1000 >= time.time(): continue
                engine.ingest_1m(s,{'i':'1m','t':r[0],'o':r[1],'h':r[2],'l':r[3],'c':r[4],
                    'v':r[5],'q':r[7],'n':r[8],'V':r[9],'x':True})
        except Exception as exc:
            logger.debug('Market gap repair pending | %s | %s',s,type(exc).__name__)
    await asyncio.gather(*(repair(s) for s in selected))
    state['gap_repair_pending']=len(missing)


async def market_gap_repair_loop():
    while True:
        try:
            await asyncio.wait_for(repair_market_gaps_once(),timeout=30)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning('Market gap repair incomplete: %s',type(exc).__name__)
        await asyncio.sleep(30)


# === 独立并发任务：杠杆拥挤雷达与外部全网数据循环 ===
async def crowding_loop():
    await crowding_engine.start()
    while True:
        cycle_started = time.monotonic()
        try:
            if config.crowding_enabled and eligible_symbols:
                await crowding_engine.scan_and_evaluate(
                    all_perpetual_symbols, quote_volume_24h, market_state_engine.latest
                )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Crowding radar loop degraded")
        await asyncio.sleep(max(1,config.model_b_poll_seconds-(time.monotonic()-cycle_started)))


async def external_macro_loop():
    while True:
        try:
            if config.cmc_enabled:
                await external_aggregator.fetch_global_metrics()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("External macro loop degraded")
        await asyncio.sleep(120)


async def market_state_loop():
    await market_state_engine.start()
    while True:
        try:
            await market_state_engine.sample()
            context_history["market_state"].append(dict(market_state_engine.latest))
            state["market_state_samples"] += 1
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("market state degraded")
        await asyncio.sleep(config.market_state_poll_seconds)


async def market_breadth_loop():
    await market_breadth_engine.start()
    market_breadth_engine.set_universe(all_perpetual_symbols, quote_volume_24h, engine)
    while True:
        try:
            await market_breadth_engine.sample(streams.latest_quotes())
            context_history["market_breadth"].append(dict(market_breadth_engine.latest))
            state["breadth_samples"] += 1
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("breadth degraded")
        await asyncio.sleep(config.breadth_poll_seconds)


async def tracking_loop():
    while True:
        try:
            await update_live_tracking(streams.latest_quotes())
            await backfill_due_alerts(market_client)
            now = time.time()
            if not state["last_prune"] or now - state["last_prune"] >= config.runtime_prune_interval_hours * 3600:
                state["last_prune_result"] = await prune_runtime_research_data()
                state["last_prune"] = now
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("tracking degraded")
        await asyncio.sleep(config.tracking_reconcile_seconds)


async def recovery_loop():
    """Historical label repair only; never retroactively creates a real-time Telegram alert."""
    while True:
        try:
            status=await backfill_persistence(market_client,limit=40)
            status['minute_groups_reconciled']=await asyncio.to_thread(recompute_spike_counts)
            state['recovery_result']=status
            state['last_recovery']=time.time()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception('Historical recovery failed; no retrospective notifications')
        await asyncio.sleep(300)


async def watchdog_loop():
    """Protect workers; keep Model A scanner restart bounded and distinguish RADAR stale polls."""
    restarted={}
    while True:
        await asyncio.sleep(15)
        now=time.time()
        tasks={
            'scanner':cycle_loop,'live_volume':live_volume_loop,
            'gap_repair':market_gap_repair_loop,'universe':universe_loop,
            'tracking':tracking_loop,'market_state':market_state_loop,
            'market_breadth':market_breadth_loop,'notify':notify_loop,
            'crowding':crowding_loop,'external_macro':external_macro_loop,
            'recovery':recovery_loop,
        }
        if config.radar_enabled:tasks['radar']=radar.loop
        for name,factory in tasks.items():
            task=runtime_tasks.get(name)
            dead=task is None or task.done()
            stalled=False
            if name=='scanner' and not dead:
                h=state['scanner_heartbeat'];d=state['last_scan_decision']
                stalled=bool(h and now-h>config.scanner_watchdog_seconds) or bool(eligible_symbols and d and now-d>config.no_cycle_watchdog_seconds)
            if name=='radar' and not dead and radar.last_cycle:
                stalled=now-radar.last_cycle>max(300,config.radar_poll_seconds*5)
            if not (dead or stalled) or now-restarted.get(name,0)<120:continue
            logger.error('Watchdog restarting %s (dead=%s, stalled=%s)',name,dead,stalled)
            if task and not task.done():
                task.cancel();await asyncio.gather(task,return_exceptions=True)
            runtime_tasks[name]=asyncio.create_task(factory(),name=name)
            restarted[name]=now
            state['task_restarts'][name]=state['task_restarts'].get(name,0)+1
            if name=='scanner':
                state['scanner_restarts']+=1
                state['scanner_heartbeat']=now
                state['last_scan_decision']=now


async def notify_loop():
    while True:
        try:
            await notifier.deliver_pending()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("notify degraded")
        await asyncio.sleep(2)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global volume_episode_cache
    await init_db()
    await expire_stale_volume_episodes()
    volume_episode_cache = await load_active_volume_episodes()
    await market_breadth_engine.start()
    await refresh_universe(force=True)

    runtime_tasks["scanner"] = asyncio.create_task(cycle_loop(), name="scanner")
    runtime_tasks["live_volume"] = asyncio.create_task(live_volume_loop(), name="live-volume")
    runtime_tasks["gap_repair"] = asyncio.create_task(market_gap_repair_loop(), name="market-gap-repair")
    runtime_tasks["universe"] = asyncio.create_task(universe_loop(), name="universe")
    runtime_tasks["tracking"] = asyncio.create_task(tracking_loop(), name="tracking")
    runtime_tasks["market_state"] = asyncio.create_task(market_state_loop(), name="market-state")
    runtime_tasks["market_breadth"] = asyncio.create_task(market_breadth_loop(), name="market-breadth")
    runtime_tasks["crowding"] = asyncio.create_task(crowding_loop(), name="crowding")
    runtime_tasks["external_macro"] = asyncio.create_task(external_macro_loop(), name="external-macro")
    runtime_tasks["notify"] = asyncio.create_task(notify_loop(), name="notify")
    runtime_tasks['recovery']=asyncio.create_task(recovery_loop(),name='recovery')
    if config.radar_enabled:
        runtime_tasks['radar']=asyncio.create_task(radar.loop(),name='cross-exchange-radar')
    runtime_tasks['watchdog']=asyncio.create_task(watchdog_loop(),name='watchdog')

    try:
        yield
    finally:
        for t in list(runtime_tasks.values()):
            t.cancel()
        await asyncio.gather(*runtime_tasks.values(), return_exceptions=True)
        await streams.close()
        if config.radar_enabled:
            await radar.close()
        await crowding_engine.close()
        await external_aggregator.close()
        await market_state_engine.close()
        await market_breadth_engine.close()
        await trend_context_engine.close()
        await notifier.close()
        await market_client.close()


app = FastAPI(lifespan=lifespan, title="Fusion V5.3 | Binance Model A + Model B + Three-venue Radar R1")


@app.middleware("http")
async def security(request: Request, call_next):
    if request.url.path.startswith("/api/") and request.url.path != "/api/login" and not authorized(request):
        return JSONResponse({"detail": "未授权"}, status_code=401)
    return await call_next(request)


@app.get("/")
async def index():
    return FileResponse(ROOT / "web_ui" / "index.html")


@app.post("/api/login")
async def login(request: Request, body: dict = Body(...)):
    token = str(body.get("token", ""))
    if config.admin_token and hmac.compare_digest(token, config.admin_token):
        resp = JSONResponse({"ok": True})
        resp.set_cookie("monitor_session", token, max_age=28800, httponly=True, samesite="strict")
        return resp
    if not config.admin_token and request.client and request.client.host in LOCAL:
        return {"ok": True}
    raise HTTPException(401, "凭证无效")


@app.get("/api/state")
async def api_state():
    alerts = await recent_volume_alerts(100)
    lifecycle = {r["source_id"]:r for r in await recent_signal_lifecycle(100)}
    items = [{**r.get("details",{}),**r,**lifecycle.get(r["id"],{}),"alert_id":r["id"]} for r in alerts]
    return {
        "version": "5.3.0-fusion",
        "model_a_signal_version": "4.9.0",
        "radar": radar.status(),
        "last_recovery":state["last_recovery"],
        "recovery_result":state["recovery_result"],
        "task_restarts":state["task_restarts"],
        "market_state": market_state_engine.latest,
        "market_breadth": market_breadth_engine.latest,
        "health": streams.health(),
        "universe": len(eligible_symbols),
        "breadth_universe": len(all_perpetual_symbols),
        "model_a": items,
        "crowding_monitored": len(crowding_engine.top_monitored_symbols),
    }


# === Independent three-venue RADAR_R1: distinct from Binance Model B. ===
@app.get('/api/radar/status')
async def api_radar_status():
    return radar.status()

@app.get('/api/radar/events')
async def api_radar_events(limit: int = 100):
    if not config.radar_enabled:return []
    return await radar.storage.recent(min(max(limit,1),500))

@app.get('/api/radar/study')
async def api_radar_study():
    if not config.radar_enabled:return {'groups':[],'disabled':True}
    return await radar.storage.study()


# === 杠杆拥挤预警系统专属 API 路由 ===
@app.get("/api/crowding/top")
async def api_crowding_top():
    return {
        "model": "MODEL_B",
        "updated_at": crowding_engine.updated_at,
        "health": crowding_engine.health,
        "benchmarks": [{**crowding_engine.monitored_snapshots.get(s,{"symbol":s,"data_quality":"WARMING"}),
                         "live_quote":streams.latest_quotes().get(s)} for s in BENCHMARKS],
        "top_symbols": crowding_engine.top_monitored_symbols,
        "items": [{**r,"stale":time.time()-r["sampled_at"]>config.model_b_poll_seconds*3} for r in crowding_engine.monitored_snapshots.values()],
    }


@app.get("/api/crowding/alerts")
async def api_crowding_alerts(limit: int = 50):
    return await recent_model_b_alerts(limit)


@app.post("/api/research-snapshot")
async def api_research_snapshot():
    try:
        return {"ok":True,"result":await create_research_analysis_snapshot()}
    except RuntimeError as exc:
        raise HTTPException(409,str(exc)) from exc


@app.get("/api/crowding/sectors")
async def api_crowding_sectors():
    sectors = {}
    for sec, syms in crowding_engine.sector_map.items():
        active = [crowding_engine.monitored_snapshots[s] for s in syms if s in crowding_engine.monitored_snapshots]
        sectors[sec] = {
            "total_symbols": len(syms),
            "monitored_count": len(active),
            "avg_score": round(statistics.mean([x["score"] for x in active]), 1) if active else 0.0,
            "max_level": max([x["level"] for x in active]) if active else 0,
            "items": active,
        }
    return sectors


@app.get("/api/crowding/macro")
async def api_crowding_macro():
    return external_aggregator.latest_macro


@app.post("/api/crowding/sectors/reload")
async def api_reload_sectors():
    crowding_engine.reload_sector_map()
    return {"ok": True, "sectors": list(crowding_engine.sector_map.keys())}


# 保留原有 Model A 所有分析接口
@app.get("/api/volume-alerts")
async def api_volume_alerts(limit: int = 100):
    return await recent_volume_alerts(limit)


@app.get('/api/market-state')
async def api_market_state():
    return market_state_engine.latest

@app.get('/api/market-breadth')
async def api_market_breadth():
    return market_breadth_engine.latest

@app.get('/api/volume-stats')
async def api_volume_stats():
    return await volume_alert_stats()

@app.get('/api/volume-episodes')
async def api_volume_episodes(limit:int=100):
    return await recent_volume_episodes(limit)

@app.get('/api/dashboard-summary')
async def api_dashboard_summary():
    return await research_dashboard_summary()

@app.get('/api/execution-stats')
async def api_execution_stats():
    return await execution_research_stats()

@app.get('/api/context-matrix')
async def api_context_matrix():
    return await context_research_matrix()

@app.get('/api/initial-context-stats')
async def api_initial_context_stats():
    return await initial_context_research_stats()

@app.get('/api/return-curves')
async def api_return_curves():
    return await return_curve_stats()

@app.get('/api/direction-stats')
async def api_direction_stats():
    return await direction_comparison_stats()


@app.get("/api/lifecycle")
async def api_lifecycle(limit: int = 100):
    return await recent_signal_lifecycle(limit)


@app.get("/api/signal-path")
async def api_signal_path(source_type: str, source_id: int):
    return await signal_path(source_type, source_id)


@app.get("/api/config")
async def api_config():
    return config.public_dict()


@app.post("/api/config")
async def save_config(body: dict = Body(...)):
    try:
        return config.update_public(body)
    except (ValidationError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from exc


if __name__ == "__main__":
    uvicorn.run("main:app", host=config.bind_host, port=config.port, workers=1, access_log=False)
