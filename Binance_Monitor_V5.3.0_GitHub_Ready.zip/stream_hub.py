"""Binance public WebSocket hub: miniTicker + sharded 1m klines.

V4.1.1 keeps the V4.0.3 stability architecture and hardens generation retirement:
- remember/promote the endpoint that actually delivers frames;
- probe an unproven endpoint quickly instead of waiting the full silence timeout;
- use make-before-break handover when additions require a kline-plan rebuild;
- do not rebuild the entire kline plan for removal-only universe changes;
- once a generation is retired, every shard is forbidden from reconnecting.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time

import aiohttp

from config import config
from symbol_utils import sanitize_usdt_symbols

logger = logging.getLogger("v4.stream")


class StreamHub:
    def __init__(self, data_engine):
        self.data_engine = data_engine
        self.session = None
        self.symbols = set()
        self.tickers = {}
        self.kline_last_frame = 0.0
        self.mini_last_frame = 0.0
        self.reconnects = 0
        self.kline_frames = 0
        self.mini_frames = 0
        self.total_kline_shards = 0
        self._active_errors = {}
        self.last_historical_error = ""

        self._mini_task = None
        self._active_kline_tasks = []
        self._retired_tasks = set()
        self._active_generation = 0
        self._connected_by_generation = {}
        # V4.1.1 generation lifecycle guard. A generation is allowed to own
        # network connections only while ACTIVE or explicitly STAGING. Once
        # retired it can never reconnect, even if aiohttp cleanup/cancellation
        # is delayed by the OS, proxy, or event loop.
        self._staging_generations = set()
        self._retired_generations = set()

        # A preferred endpoint is promoted only after it actually delivers a
        # valid frame. A mere WebSocket handshake is not enough.
        self._preferred_kline_endpoint = None
        self._preferred_mini_endpoint = None

    def _set_error(self, key, text):
        self._active_errors[key] = text
        self.last_historical_error = text

    def _clear_error(self, key):
        self._active_errors.pop(key, None)

    @staticmethod
    def _alternate_endpoint(current, count):
        return (current + 1) % max(count, 1)

    def _initial_endpoint(self, preferred):
        return preferred if preferred is not None else 0

    def _receive_timeout(self, endpoint, preferred):
        # Unproven/non-preferred routes get a short probation so a proxy that
        # accepts the handshake but never forwards frames cannot cost 20s on
        # every stream rebuild.
        if preferred is None or endpoint != preferred:
            return min(config.stream_silence_timeout_seconds, config.stream_probe_timeout_seconds)
        return config.stream_silence_timeout_seconds

    def _connected_count(self):
        return len(self._connected_by_generation.get(self._active_generation, set()))

    def _generation_is_live(self, generation):
        """Return whether a kline generation may connect/reconnect/ingest.

        During make-before-break the new generation is STAGING while the old
        generation remains ACTIVE. After atomic publication only the new ACTIVE
        generation is live. RETIRED always wins over either state.
        """
        if generation in self._retired_generations:
            return False
        return generation == self._active_generation or generation in self._staging_generations

    async def start(self, symbols):
        if self._mini_task is None or self._mini_task.done():
            self._mini_task = asyncio.create_task(self._listen_mini(), name="miniTicker")
        await self.update_symbols(symbols)

    async def update_symbols(self, symbols):
        """Publish a new kline plan without creating a data gap.

        Removal-only changes do not require a rebuild: old subscriptions may
        continue briefly/indefinitely, while ingest is filtered by the current
        published symbol set. Any future addition performs a clean replan.

        Additions use make-before-break: all staged shards must deliver at
        least one valid kline frame before they replace the old active plan.
        If staging fails, the old plan remains untouched and the caller can
        keep the last good universe.
        """
        clean, _ = sanitize_usdt_symbols(symbols)
        new = set(clean)
        if not new:
            raise RuntimeError("refuse empty kline stream plan")
        if new == self.symbols and self._active_kline_tasks:
            return False

        removed = self.symbols - new
        added = new - self.symbols

        # Pure removals need no network churn and therefore cannot damage the
        # currently forming 5m bucket.
        if self.symbols and not added:
            self.symbols = new
            logger.info("1m stream delta | symbols=%s | removed=%s | added=0 | rebuild=skipped",
                        len(new), len(removed))
            return True

        generation = self._active_generation + 1
        previous_errors = dict(self._active_errors)
        self._staging_generations.add(generation)
        self._retired_generations.discard(generation)
        ordered = sorted(new)
        shards = [frozenset(ordered[i:i + config.stream_shard_size])
                  for i in range(0, len(ordered), config.stream_shard_size)]
        ready_events = [asyncio.Event() for _ in shards]
        staged = []
        self._connected_by_generation[generation] = set()

        for shard_id, shard in enumerate(shards):
            task = asyncio.create_task(
                self._listen_klines(shard, shard_id, generation, ready_events[shard_id]),
                name=f"kline-g{generation}-{shard_id}",
            )
            staged.append(task)

        logger.info("1m stream staging | symbols=%s | added=%s | removed=%s | shard_size=%s | shards=%s | preferred_endpoint=%s",
                    len(new), len(added), len(removed), config.stream_shard_size, len(shards),
                    "auto" if self._preferred_kline_endpoint is None else self._preferred_kline_endpoint)

        try:
            await asyncio.wait_for(
                asyncio.gather(*(event.wait() for event in ready_events)),
                timeout=config.stream_handover_ready_timeout_seconds,
            )
        except (Exception, asyncio.CancelledError):
            # Revoke network authority before cancellation. Even if a task is
            # slow to observe cancellation, its reconnect loop sees RETIRED and
            # exits permanently.
            self._staging_generations.discard(generation)
            self._retired_generations.add(generation)
            for task in staged:
                task.cancel()
            await asyncio.gather(*staged, return_exceptions=True)
            self._connected_by_generation.pop(generation, None)
            self._retired_generations.discard(generation)
            self._active_errors = previous_errors
            logger.warning("1m stream handover FAILED | keep_old=%s | staged_symbols=%s",
                           len(self.symbols), len(new))
            raise

        old_tasks = list(self._active_kline_tasks)
        old_generation = self._active_generation

        # Atomic publish: new plan is already receiving frames before the old
        # one is retired.
        self.symbols = new
        self._active_generation = generation
        self._staging_generations.discard(generation)
        self._active_kline_tasks = staged
        self.total_kline_shards = len(shards)
        self._active_errors = {k: v for k, v in self._active_errors.items() if k == "mini"}
        logger.info("1m stream handover OK | symbols=%s | shards=%s | endpoint=%s",
                    len(new), len(shards), self._preferred_kline_endpoint)

        if old_tasks:
            self._retire_tasks(old_tasks, old_generation)
        return True

    def _retire_tasks(self, tasks, generation):
        # IMPORTANT: revoke the generation first, then cancel tasks. This is the
        # V4.1.1 zombie-stream fix. A late/stubborn shard cannot reconnect once
        # this flag is present.
        self._staging_generations.discard(generation)
        self._retired_generations.add(generation)
        logger.info("1m generation retire START | gen=%s | tasks=%s", generation, len(tasks))
        for task in tasks:
            task.cancel()

        async def reap():
            try:
                await asyncio.gather(*tasks, return_exceptions=True)
            finally:
                self._connected_by_generation.pop(generation, None)
                # Safe to forget the tombstone only after every task in this
                # generation has terminated. No coroutine remains that could
                # reconnect using this generation id.
                self._retired_generations.discard(generation)
                logger.info("1m generation retire DONE | gen=%s", generation)

        reaper = asyncio.create_task(reap(), name=f"kline-retire-g{generation}")
        self._retired_tasks.add(reaper)
        reaper.add_done_callback(self._retired_tasks.discard)

    async def _session(self):
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()),
                timeout=aiohttp.ClientTimeout(total=30),
            )
        return self.session

    async def _listen_mini(self):
        urls = [
            "wss://fstream.binance.com/stream?streams=!miniTicker@arr",
            "wss://fstream.binance.com/market/stream?streams=!miniTicker@arr",
        ]
        endpoint = self._initial_endpoint(self._preferred_mini_endpoint)
        while True:
            received = False
            current = endpoint % len(urls)
            try:
                session = await self._session()
                async with session.ws_connect(urls[current], heartbeat=20,
                                              proxy=config.proxy_url if config.use_proxy else None) as ws:
                    while True:
                        timeout = self._receive_timeout(current, self._preferred_mini_endpoint)
                        try:
                            msg = await asyncio.wait_for(ws.receive(), timeout=timeout)
                        except asyncio.TimeoutError:
                            raise TimeoutError("miniTicker stream silent")
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            payload = json.loads(msg.data)
                            data = payload.get("data", payload)
                            if isinstance(data, list):
                                now = time.time()
                                for x in data:
                                    s = x.get("s")
                                    if s:
                                        self.tickers[s] = {
                                            "price": float(x.get("c", 0) or 0),
                                            "quote_volume": float(x.get("q", 0) or 0),
                                            "timestamp": now,
                                        }
                                self.mini_last_frame = now
                                self.mini_frames += 1
                                received = True
                                if self._preferred_mini_endpoint != current:
                                    self._preferred_mini_endpoint = current
                                    logger.info("miniTicker endpoint promoted | endpoint=%s", current)
                                self._clear_error("mini")
                        elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                            break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                text = f"mini:{type(exc).__name__}"
                self._set_error("mini", text)
                self.reconnects += 1
                if not received:
                    logger.warning("miniTicker stream failed | endpoint=%s | error=%s", current, type(exc).__name__)

            if not received:
                preferred = self._preferred_mini_endpoint
                endpoint = preferred if preferred is not None and preferred != current else self._alternate_endpoint(current, len(urls))
            await asyncio.sleep(1 if received else 2)

    async def _listen_klines(self, symbols, shard_id, generation, ready_event):
        streams = "/".join(s.lower() + "@kline_1m" for s in sorted(symbols))
        urls = [
            "wss://fstream.binance.com/stream?streams=" + streams,
            "wss://fstream.binance.com/market/stream?streams=" + streams,
        ]
        endpoint = self._initial_endpoint(self._preferred_kline_endpoint)
        key = f"kline[g{generation}:{shard_id}]"
        connected = False

        while True:
            # Hard lifecycle gate before every network attempt. This makes a
            # retired generation unable to become a zombie reconnect loop.
            if not self._generation_is_live(generation):
                logger.info("1m shard exit retired | gen=%s | shard=%s", generation, shard_id)
                return

            received = False
            current = endpoint % len(urls)
            try:
                session = await self._session()
                if not self._generation_is_live(generation):
                    return
                async with session.ws_connect(urls[current], heartbeat=20,
                                              proxy=config.proxy_url if config.use_proxy else None) as ws:
                    if not self._generation_is_live(generation):
                        return
                    self._connected_by_generation.setdefault(generation, set()).add(shard_id)
                    connected = True
                    logger.info("1m shard connected | gen=%s | shard=%s | symbols=%s | endpoint=%s | url_chars=%s",
                                generation, shard_id, len(symbols), current, len(urls[current]))
                    while True:
                        if not self._generation_is_live(generation):
                            logger.info("1m shard close retired | gen=%s | shard=%s", generation, shard_id)
                            return
                        timeout = self._receive_timeout(current, self._preferred_kline_endpoint)
                        try:
                            msg = await asyncio.wait_for(ws.receive(), timeout=timeout)
                        except asyncio.TimeoutError:
                            raise TimeoutError("1m stream silent")
                        if not self._generation_is_live(generation):
                            return
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            payload = json.loads(msg.data)
                            data = payload.get("data", payload)
                            if isinstance(data, dict) and data.get("e") == "kline":
                                s = data.get("s")
                                k = data.get("k", {})
                                # A STAGING generation may ingest before atomic
                                # publication to avoid a handover gap. A retired
                                # generation is never allowed to ingest.
                                allowed = (self._generation_is_live(generation) and s in symbols and
                                           (generation != self._active_generation or s in self.symbols))
                                if allowed and self.data_engine.ingest_1m(s, k):
                                    self.kline_last_frame = time.time()
                                    self.kline_frames += 1
                                    received = True
                                    if self._preferred_kline_endpoint != current:
                                        self._preferred_kline_endpoint = current
                                        logger.info("1m endpoint promoted | endpoint=%s", current)
                                    ready_event.set()
                                    self._clear_error(key)
                        elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                            break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                # A retirement race is normal shutdown, not a stream error.
                if not self._generation_is_live(generation):
                    return
                text = f"{key}:{type(exc).__name__}"
                self._set_error(key, text)
                self.reconnects += 1
                if not received:
                    logger.warning("1m shard failed | gen=%s | shard=%s | symbols=%s | endpoint=%s | url_chars=%s | error=%s",
                                   generation, shard_id, len(symbols), current, len(urls[current]), type(exc).__name__)
            finally:
                if connected:
                    self._connected_by_generation.setdefault(generation, set()).discard(shard_id)
                    connected = False

            # Lifecycle gate again after disconnect/error and before choosing
            # another endpoint or sleeping. This is the decisive no-reconnect
            # guard for retired generations.
            if not self._generation_is_live(generation):
                return
            if not received:
                preferred = self._preferred_kline_endpoint
                endpoint = preferred if preferred is not None and preferred != current else self._alternate_endpoint(current, len(urls))
            await asyncio.sleep(1 if received else 2)

    def latest_quotes(self):
        now = time.time()
        return {s: q for s, q in self.tickers.items() if q["price"] > 0 and now - q["timestamp"] < 60}

    def health(self):
        now = time.time()
        return {
            "kline_age_seconds": now - self.kline_last_frame if self.kline_last_frame else None,
            "mini_age_seconds": now - self.mini_last_frame if self.mini_last_frame else None,
            "reconnects": self.reconnects,
            "last_error": "; ".join(sorted(self._active_errors.values())),
            "last_historical_error": self.last_historical_error,
            "symbols": len(self.symbols),
            "kline_frames": self.kline_frames,
            "mini_frames": self.mini_frames,
            "connected_kline_shards": self._connected_count(),
            "total_kline_shards": self.total_kline_shards,
            "preferred_kline_endpoint": self._preferred_kline_endpoint,
            "preferred_mini_endpoint": self._preferred_mini_endpoint,
            "stream_generation": self._active_generation,
            "staging_generations": sorted(self._staging_generations),
            "retiring_generations": sorted(self._retired_generations),
            "retire_reapers": len(self._retired_tasks),
        }

    async def close(self):
        tasks = []
        if self._mini_task:
            tasks.append(self._mini_task)
        tasks.extend(self._active_kline_tasks)
        tasks.extend(self._retired_tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        if self.session and not self.session.closed:
            await self.session.close()
