"""Lean kline store for V4.8.0 Model-A research core."""
from __future__ import annotations

import math
import time
from collections import defaultdict
from statistics import mean

from config import config
from symbol_utils import normalize_usdt_symbol


class DataEngine:
    def __init__(self):
        self.minute_klines = defaultdict(dict)
        self.five_klines = defaultdict(dict)

    @staticmethod
    def _volume_mean(values):
        """Previous 20 complete periods, remove exactly ONE maximum, mean of 19."""
        xs = [float(x) for x in values]
        if len(xs) != 20 or any(not math.isfinite(x) or x < 0 for x in xs):
            return 0.0
        return (sum(xs) - max(xs)) / 19

    @staticmethod
    def _atr(rows, index, period):
        if index < period:
            return None
        trs = []
        start = index - period + 1
        for j in range(start, index + 1):
            r = rows[j]
            prev_close = rows[j - 1]["close"]
            tr = max(r["high"] - r["low"], abs(r["high"] - prev_close), abs(r["low"] - prev_close))
            trs.append(tr)
        return mean(trs) if trs else None

    @staticmethod
    def required_history_5m():
        # Current + previous VR10 windows plus 20 historical full 15m groups.
        return max(
            config.history_bars_5m,
            (config.volume_ratio_lookback_15m + 2) * 3 + 12,
            config.atr_period_5m + 10,
            300,  # >=25h so UTC-00:00 / UTC+8-08:00 session open can be recovered after restart
        )

    def ingest_history_5m(self, symbol, raw):
        symbol = normalize_usdt_symbol(symbol)
        if not symbol:
            return
        store = self.five_klines[symbol]
        now = time.time()
        for row in raw:
            opened = float(row[0]) / 1000
            store[opened] = {
                "open_at": opened,
                "open": float(row[1]),
                "high": float(row[2]),
                "low": float(row[3]),
                "close": float(row[4]),
                "base_volume": float(row[5]),
                "quote_volume": float(row[7]),
                "trade_count": int(row[8]),
                "taker_buy_base": float(row[9]),
                "closed": float(row[6]) / 1000 < now,
            }
        self._trim_store(store, self.required_history_5m() + 90)

    def ingest_1m(self, symbol, kline):
        symbol = normalize_usdt_symbol(symbol)
        if not symbol or kline.get("i") != "1m":
            return False
        try:
            opened = float(kline["t"]) / 1000
            row = {
                "open_at": opened,
                "open": float(kline["o"]),
                "high": float(kline["h"]),
                "low": float(kline["l"]),
                "close": float(kline["c"]),
                "base_volume": float(kline["v"]),
                "quote_volume": float(kline["q"]),
                "trade_count": int(kline.get("n", 0)),
                "taker_buy_base": float(kline.get("V", 0)),
                "closed": bool(kline.get("x")),
            }
        except (KeyError, TypeError, ValueError):
            return False
        minutes = self.minute_klines[symbol]
        if minutes.get(opened, {}).get("closed") and not row["closed"]:
            return False
        minutes[opened] = row
        self._trim_store(minutes, 45)
        bucket = float(int(opened // 300) * 300)
        parts = sorted(
            (r for t, r in minutes.items() if int(t // 300) * 300 == int(bucket)),
            key=lambda r: r["open_at"],
        )
        if not parts:
            return False
        if self.five_klines[symbol].get(bucket, {}).get("closed") and len(parts) != 5:
            return True
        self.five_klines[symbol][bucket] = {
            "open_at": bucket,
            "open": parts[0]["open"],
            "high": max(r["high"] for r in parts),
            "low": min(r["low"] for r in parts),
            "close": parts[-1]["close"],
            "base_volume": sum(r["base_volume"] for r in parts),
            "quote_volume": sum(r["quote_volume"] for r in parts),
            "trade_count": sum(r["trade_count"] for r in parts),
            "taker_buy_base": sum(r["taker_buy_base"] for r in parts),
            "closed": len(parts) == 5 and all(r["closed"] for r in parts),
        }
        self._trim_store(self.five_klines[symbol], self.required_history_5m() + 90)
        return True


    def session_open_price(self, symbol, session_start_utc):
        """Return the 5m session opening price at 00:00 UTC when present.

        This is used only by the breadth research layer. The bar may be historical
        and does not need to be marked closed because its *open* is immutable once
        the session begins.
        """
        symbol = normalize_usdt_symbol(symbol)
        if not symbol:
            return None
        store = self.five_klines.get(symbol, {})
        target = float(session_start_utc)
        row = store.get(target)
        if row and float(row.get("open", 0) or 0) > 0:
            return float(row["open"])
        # Tolerate one missing exact key caused by exchange/history edge cases,
        # but never drift beyond the first 10 minutes of the session.
        candidates = [(abs(float(k)-target), r) for k,r in store.items() if 0 <= float(k)-target <= 600]
        if candidates:
            _, r = min(candidates, key=lambda x:x[0])
            px = float(r.get("open", 0) or 0)
            return px if px > 0 else None
        return None

    @staticmethod
    def _trim_store(store, keep):
        for key in sorted(store)[:-keep]:
            store.pop(key, None)

    def has_closed_bucket(self, symbol, bucket):
        row = self.five_klines.get(symbol, {}).get(float(bucket))
        return bool(row and row.get("closed"))

    def completion_ratio(self, symbols, bucket):
        symbols = list(symbols)
        if not symbols:
            return 0.0
        return sum(self.has_closed_bucket(s, bucket) for s in symbols) / len(symbols)

    def rows_through(self, symbol, bucket, limit=None):
        store = self.five_klines.get(symbol, {})
        rows = [store[k] for k in sorted(store) if k <= bucket and store[k].get("closed")]
        return rows[-limit:] if limit else rows

    @staticmethod
    def _aggregate_15m(rows):
        groups = []
        current_key = None
        parts = []
        for r in rows:
            key = float(int(r["open_at"] // 900) * 900)
            if current_key is None or key == current_key:
                current_key = key
                parts.append(r)
            else:
                if len(parts) == 3:
                    groups.append(DataEngine._merge_group(current_key, parts))
                current_key, parts = key, [r]
        if current_key is not None and len(parts) == 3:
            groups.append(DataEngine._merge_group(current_key, parts))
        return groups

    @staticmethod
    def _merge_group(open_at, parts):
        return {
            "open_at": open_at,
            "open": parts[0]["open"],
            "high": max(r["high"] for r in parts),
            "low": min(r["low"] for r in parts),
            "close": parts[-1]["close"],
            "base_volume": sum(r["base_volume"] for r in parts),
            "quote_volume": sum(r["quote_volume"] for r in parts),
            "parts": 3,
        }

    @staticmethod
    def is_vr10_checkpoint(bucket):
        """True after the second 5m bar of a 15m window has closed.

        Example: 10:00-10:05 + 10:05-10:10 are complete; scanner bucket is
        10:05 (open time of the second 5m bar), so bucket % 900 == 300.
        """
        return int(float(bucket)) % 900 == 300

    def _research_indicators(self, rows):
        i = len(rows) - 1
        atr = self._atr(rows, i, config.atr_period_5m) or 0.0
        price = rows[-1]["close"]
        atr_pct = atr / price * 100 if price > 0 else 0.0
        return atr, atr_pct

    def feature_snapshot(self, symbol, bucket):
        """Completed-15m snapshot retained for broad-market Regime only."""
        rows = self.rows_through(symbol, bucket)
        need = max(80, config.volume_ratio_lookback_15m * 3 + 6)
        if len(rows) < need or rows[-1]["open_at"] != float(bucket):
            return None
        completed = self._aggregate_15m(rows)
        if len(completed) < 2:
            return None
        g = completed[-1]
        row = rows[-1]
        ret15 = (g["close"] / g["open"] - 1) * 100 if g["open"] > 0 else 0.0
        last12 = rows[-12:]
        ret1h = (row["close"] / last12[0]["open"] - 1) * 100 if last12[0]["open"] > 0 else 0.0
        return {
            "symbol": symbol,
            "bucket": float(bucket),
            "price": row["close"],
            "bar_15m_open_at": g["open_at"],
            "return_15m_pct": ret15,
            "return_1h_pct": ret1h,
        }

    def _baseline_before_window(self, symbol, window_open):
        rows = self.rows_through(symbol, window_open - 300)
        completed = self._aggregate_15m([r for r in rows if r["open_at"] < window_open])
        lookback = 20
        if len(completed) < lookback:
            return 0.0
        if [x["open_at"] for x in completed[-20:]] != [window_open - i * 900 for i in range(20, 0, -1)]:
            return 0.0
        return self._volume_mean(x["base_volume"] for x in completed[-lookback:])

    def live_vr_snapshot(self, symbol, closed_minute_open):
        """Actual cumulative VR from configurable minute 5 through minute 15.

        No extrapolation is used in V4.4.1. At each observation:
          live_vr = cumulative Base Volume already traded in current 15m window
                    / mean Base Volume of prior complete 15m windows.
        """
        symbol = normalize_usdt_symbol(symbol)
        if not symbol:
            return None
        closed_minute_open = float(closed_minute_open)
        window_open = float(int(closed_minute_open // 900) * 900)
        observation_at = closed_minute_open + 60
        elapsed = int(round((observation_at - window_open) / 60))
        if elapsed < config.model_a_scan_start_minute or elapsed > 15:
            return None

        minutes = self.minute_klines.get(symbol, {})
        expected = [window_open + i * 60 for i in range(elapsed)]
        parts = [minutes.get(t) for t in expected]
        if any(not r or not r.get("closed") for r in parts):
            return None

        baseline = self._baseline_before_window(symbol, window_open)
        if baseline <= 0:
            return None

        cumulative = sum(float(r["base_volume"]) for r in parts)
        actual_ratio = cumulative / baseline
        prev_cumulative = cumulative - float(parts[-1]["base_volume"])
        prev_live_ratio = max(0.0, prev_cumulative / baseline)
        delta_vr_live = actual_ratio - prev_live_ratio

        first = parts[0]
        last = parts[-1]
        price = last["close"]
        ret_live = (price / first["open"] - 1) * 100 if first["open"] > 0 else 0.0
        last_minute_ret = (last["close"] / last["open"] - 1) * 100 if last["open"] > 0 else 0.0
        live_high = max(r["high"] for r in parts)
        live_low = min(r["low"] for r in parts)
        close_location = (price - live_low) / (live_high - live_low) if live_high > live_low else 0.5

        five_rows = [r for r in self.rows_through(symbol, closed_minute_open) if r["open_at"]+300 <= observation_at]
        if not five_rows:
            return None
        atr, atr_pct = self._research_indicators(five_rows)

        # Research: price displacement per unit of abnormal volume, normalized by ATR.
        excess_vr = max(actual_ratio - 1.0, 0.10)
        atr_units = abs(ret_live) / max(atr_pct, 0.05)
        vpe_atr = atr_units / excess_vr
        vpe_raw = abs(ret_live) / max(actual_ratio, 0.10)

        return {
            "symbol": symbol, "bucket": observation_at, "scan_bucket": closed_minute_open, "price": price,
            "bar_15m_open_at": window_open, "observation_at": observation_at, "elapsed_minutes": elapsed,
            "remaining_minutes": max(0, 15-elapsed), "return_live_pct": ret_live, "return_10m_pct": ret_live, "last_minute_return_pct": last_minute_ret,
            "base_volume_live": cumulative, "base_volume_10m": cumulative,
            "baseline_base_volume_15m": baseline, "vr_live_actual": actual_ratio, "vr10_now": actual_ratio,
            "prev_live_vr": prev_live_ratio, "delta_vr_live": delta_vr_live,
            "atr_14_5m": atr, "atr_14_5m_pct": atr_pct,
            "close_location": max(0.0,min(1.0,close_location)),
            "live_high": live_high, "live_low": live_low,
            "vpe_atr": vpe_atr, "vpe_raw": vpe_raw,
            "baseline_method": "BASE_VOLUME_20_DROP_ONE_MAX_MEAN_19_V4_9",
            "minute_base_volumes": [float(r["base_volume"]) for r in parts],
        }

    def vr10_snapshot(self, symbol, bucket):
        if not self.is_vr10_checkpoint(bucket):
            return None
        window_open = float(int(float(bucket) // 900) * 900)
        return self.live_vr_snapshot(symbol, window_open + 9 * 60)

def classify_volume_state(current_actual, previous_actual, threshold=None, tolerance_pct=None, episode_active=True):
    """Classify actual-VR evolution inside one continuous volume episode."""
    threshold = config.model_a_vr_trigger if threshold is None else float(threshold)
    tolerance = (config.vr_state_tolerance_pct if tolerance_pct is None else float(tolerance_pct)) / 100.0
    cur = float(current_actual or 0.0); prev = float(previous_actual or 0.0)
    if not episode_active:
        return "FIRST_BREAKOUT" if cur >= threshold else "BELOW_THRESHOLD"
    if prev <= 0:
        return "CONTINUING" if cur >= threshold else "DECAY"
    change = cur / prev - 1.0
    if change > tolerance:
        return "REACCELERATING"
    if change < -tolerance or cur < threshold:
        return "DECAY"
    return "CONTINUING"
