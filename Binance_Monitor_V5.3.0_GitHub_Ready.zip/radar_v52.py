"""V5.2 cross-venue public-market RADAR_R1, deliberately independent of Model-A.
No trading endpoints. Poll-time observations are not fabricated into exchange-time trades.
All events remain shadow-only by default until forward validation.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import statistics
import time
from collections import defaultdict,deque
from dataclasses import asdict,dataclass

from multi_exchange import ThreeExchangeClient, Quote
from radar_storage import RadarStorage
from config import config

log=logging.getLogger('v52.radar')
ENGINE_VERSION='RADAR_R1_5.2.0'


def change_pct(current, previous):
    if current is None or previous is None or previous<=0:return None
    return (current/previous-1)*100


def directional(direction, change):
    return change if direction=='LONG' else -change


def fresh(q:Quote,now,max_age_seconds=180):
    # Received-at is separate from exchange timestamp; no false precision when API omits event time.
    if q.received_at > now+10 or now-q.received_at>max_age_seconds:return False
    if q.event_time_ms is not None:
        age=now-q.event_time_ms/1000
        if age>max_age_seconds or age < -30:return False
    return True


def identify_asset(quote:Quote):
    # Do not collapse 1000SHIB and SHIB without explicit contract multiplier validation.
    return quote.asset


@dataclass
class Detection:
    asset: str
    event_type: str
    exchange: str
    direction: str
    risk: int
    confidence: str
    evidence: dict
    reference_price: float
    reference_exchange: str
    event_time_ms: int | None
    received_at: float
    decided_at: float
    coverage: dict


class RadarEngine:
    def __init__(self,client=None,storage=None):
        self.client=client or ThreeExchangeClient()
        self.storage=storage or RadarStorage(max_queue=int(getattr(config,'radar_writer_max_queue',25000)))
        self.prev={}
        self.prev_seen={}
        self.latest_quotes={}
        self.active={}  # event_id -> independent 240-minute research path
        self.open_episodes={}  # asset/type/exchange/direction -> latest event_id
        self.last_cycle=0.0
        self.last_success=0.0
        self.last_error=''
        self.cycles=0
        self.discovered={}
        self.latest_events=[]
        self.latest_market={}
        self.focus_assets={'BTC','ETH'}
        self._lock=asyncio.Lock()
        self.next_discovery=0.0
        self.last_compaction=0.0
        self.candidate_seen=deque(maxlen=500)
        self._closed=False

    def make_aggregate(self,quotes,now):
        by_asset=defaultdict(list)
        for q in quotes:
            if fresh(q,now):by_asset[identify_asset(q)].append(q)
        features={}
        for asset,rows in by_asset.items():
            perps=[q for q in rows if q.market=='PERP']
            spots=[q for q in rows if q.market=='SPOT']
            valid_changes={}
            oi_delta={}
            funding={}
            spot_tape={}
            for q in rows:
                if q.market=='SPOT' and q.sampled_taker_buy_share is not None:
                    spot_tape[q.exchange]={'buy_share':q.sampled_taker_buy_share,
                      'sample_count':q.sampled_trade_count,
                      'span_seconds':q.sampled_trade_span_seconds,'sample_notional':q.sampled_quote_notional}
                key=f'{q.exchange}:{q.market}:{q.symbol}'
                old=self.prev.get(key)
                old_at=self.prev_seen.get(key)
                if old and old_at and 15<=q.received_at-old_at<=max(300,float(getattr(config,'radar_poll_seconds',75))*3):
                    valid_changes[key]=change_pct(q.price,old.price)
                    # Use base-denominated OI, never USD nominal OI as evidence of position growth.
                    if q.market=='PERP' and q.oi_base is not None and old.oi_base is not None:
                        oi_delta[q.exchange]=change_pct(q.oi_base,old.oi_base)
                if q.market=='PERP' and q.funding_rate is not None and q.funding_interval_hours:
                    funding[q.exchange]={'raw':q.funding_rate,'hours':q.funding_interval_hours,
                                         'per_hour':q.funding_rate/q.funding_interval_hours,'kind':q.funding_kind}
                elif q.market=='PERP' and q.funding_rate is not None:
                    funding[q.exchange]={'raw':q.funding_rate,'hours':None,'per_hour':None,'kind':q.funding_kind}
            perps.sort(key=lambda q:(q.exchange!='binance',-(q.volume_24h_quote or 0)))
            ref=perps[0] if perps else (spots[0] if spots else None)
            perps_by_ex={q.exchange:q for q in perps}
            spot_by_ex={q.exchange:q for q in spots}
            pp={ex:valid_changes.get(f'{ex}:PERP:{q.symbol}') for ex,q in perps_by_ex.items()}
            sp={ex:valid_changes.get(f'{ex}:SPOT:{q.symbol}') for ex,q in spot_by_ex.items()}
            basis={ex:(perps_by_ex[ex].price/spot_by_ex[ex].price-1)*100 for ex in perps_by_ex if ex in spot_by_ex and spot_by_ex[ex].price>0}
            features[asset]={'asset':asset,'perps':perps_by_ex,'spots':spot_by_ex,
              'perp_move':pp,'spot_move':sp,'oi_delta_base':oi_delta,'funding':funding,
              'basis_pct':basis,'spot_tape':spot_tape,'price_ref':ref.price if ref else None,'reference_exchange':ref.exchange if ref else None,
              'ref_quote':ref,'coverage':{'perp_sources':len(perps),'spot_sources':len(spots),
                'price_delta_sources':sum(v is not None for v in pp.values()),'oi_delta_sources':len(oi_delta),
                'funding_sources':len(funding),'sampled_spot_tape_sources':len(spot_tape),'spot_delta_sources':sum(v is not None for v in sp.values())}}
        return features

    def cross_market_snapshot(self,features,now):
        """Asset-deduplicated poll-to-poll momentum breadth (NOT 08:00 session breadth)."""
        moves=[]
        for asset,f in features.items():
            one=[x for x in f['perp_move'].values() if x is not None]
            if one:moves.append(statistics.median(one))
        n=len(moves)
        if n:
            up=sum(v>.2 for v in moves);down=sum(v<-.2 for v in moves);flat=n-up-down
            score=(up-down)/n*100
            label=('BROAD_STRONG_BULL' if score>=60 else 'BROAD_BULL' if score>=20 else
                   'BROAD_STRONG_BEAR' if score<=-60 else 'BROAD_BEAR' if score<=-20 else 'NEUTRAL')
            median=statistics.median(moves)
        else:
            up=down=flat=0;score=None;label='INSUFFICIENT';median=None
        majors={a:statistics.median([x for x in features[a]['perp_move'].values() if x is not None])
                for a in ('BTC','ETH') if a in features and any(x is not None for x in features[a]['perp_move'].values())}
        return {'status':label,'breadth_score':score,'asset_sample_count':n,
          'up_assets':up,'down_assets':down,'flat_assets':flat,
          'median_poll_return_pct':median,'majors':majors,'observed_at':now,
          'definition':'cross-venue median perpetual price delta since each venue prior REST poll',
          'not_session_breadth':True}

    def detect(self, f,now):
        """Independent risk hypotheses; source-tagged and missing-aware, no black-box sum."""
        asset=f['asset']; perps=f['perps']; cover=f['coverage']
        p_moves={k:v for k,v in f['perp_move'].items() if v is not None}
        oi={k:v for k,v in f['oi_delta_base'].items() if v is not None}
        p_spots={k:v for k,v in f['spot_move'].items() if v is not None}
        if not perps or not p_moves:return []
        out=[]
        ref=f['ref_quote']; refs=f['reference_exchange']
        def add(typ,exchange,direction,risk,evidence,required):
            q=perps.get(exchange,ref)
            # Requirements vary by event type; missing spot data does not suppress a deleveraging candidate.
            missing=[x for x in required if x not in evidence or evidence[x] is None]
            quality='PARTIAL' if missing else 'OK'
            if missing:evidence={**evidence,'missing_required':missing}
            confidence='LOW' if missing or cover['perp_sources']<2 else 'MEDIUM'
            out.append(Detection(asset,typ,exchange,direction,risk,confidence,evidence,
                      q.price,q.exchange,q.event_time_ms,q.received_at,now,cover.copy()))
        for ex,p in p_moves.items():
            o=oi.get(ex); s=p_spots.get(ex)
            fn=f['funding'].get(ex)
            tape=f['spot_tape'].get(ex)
            basis=f['basis_pct'].get(ex)
            if o is not None and o>=2.0 and abs(p)>=0.4:
                add('LEVERAGE_BUILD',ex,'LONG' if p>=0 else 'SHORT',55,
                    {'oi_base_change_pct':o,'perp_price_change_pct':p,'spot_price_change_pct':s,
                     'funding_per_hour':fn.get('per_hour') if fn else None,
                     'spot_sample_buy_share':tape.get('buy_share') if tape else None,
                     'spot_sample_count':tape.get('sample_count') if tape else None},['oi_base_change_pct','perp_price_change_pct'])
            # Crowd fragility is not the same as price direction or a confirmed liquidation.
            if o is not None and o>1.5 and fn and fn['per_hour'] is not None:
                hourly=fn['per_hour']
                crowded=(hourly>=0.00006 and 0<=p<=0.5) or (hourly<=-0.00006 and -.5<=p<=0)
                if crowded:
                    crowd_dir='LONG' if hourly>=0 else 'SHORT'
                    add('CROWD_FRAGILITY',ex,crowd_dir,60,
                        {'oi_base_change_pct':o,'funding_per_hour':hourly,'basis_pct':basis,
                         'perp_price_change_pct':p,'spot_price_change_pct':s,
                         'spot_sample_buy_share':tape.get('buy_share') if tape else None},['oi_base_change_pct','funding_per_hour'])
            if o is not None and o<=-2.5 and abs(p)>=0.7:
                # OI reduction + price shock are proxies; actual liquidation proof is NOT implied.
                add('DELEVERAGING_PROXY',ex,'LONG' if p>0 else 'SHORT',76,
                    {'oi_base_change_pct':o,'perp_price_change_pct':p,'spot_price_change_pct':s,
                     'liquidation_confirmed':False,
                     'spot_sample_buy_share':tape.get('buy_share') if tape else None},['oi_base_change_pct','perp_price_change_pct'])
        if len(p_moves)>=2:
            same_up={k:v for k,v in p_moves.items() if v>=0.7}
            same_down={k:v for k,v in p_moves.items() if v<=-0.7}
            for direction,group in (('LONG',same_up),('SHORT',same_down)):
                if len(group)>=2:
                    add('CROSS_RESONANCE','MULTI',direction,68,
                        {'confirming_venues':sorted(group),'moves_pct':group,
                         'independent_assets':1,'spot_moves_pct':p_spots},['confirming_venues','moves_pct'])
            # Local distortion: venue move against coherent peers, not merely a slightly different magnitude.
            for ex,p in p_moves.items():
                peers=[v for k,v in p_moves.items() if k!=ex]
                if peers and abs(p-statistics.median(peers))>=1.0 and abs(p)>=.8:
                    add('LOCAL_DISLOCATION',ex,'LONG' if p>0 else 'SHORT',65,
                        {'local_price_change_pct':p,'other_venue_median_pct':statistics.median(peers),
                         'spot_price_change_pct':p_spots.get(ex)},['local_price_change_pct','other_venue_median_pct'])
        return out

    @staticmethod
    def event_key(d:Detection,started_at):
        # Episode starts rounded to 5m for deterministic replay/duplication control.
        rounded=int(started_at//300)*300
        msg=f'{ENGINE_VERSION}|{d.asset}|{d.event_type}|{d.exchange}|{d.direction}|{rounded}'
        return hashlib.sha256(msg.encode()).hexdigest()[:24]

    async def _emit(self,d:Detection,now):
        episode=f'{d.asset}:{d.event_type}:{d.exchange}:{d.direction}'
        old=self.active.get(self.open_episodes.get(episode))
        # A new independent episode only after expiry/cooldown; same poll cannot duplicate.
        if old and now-old['last_at']<900:
            event_id=old['id'];old['last_at']=now
            old['risk']=max(d.risk,old['risk'])
            status='ESCALATED' if d.risk>old.get('notified_risk',0)+12 else 'WATCHING'
            old['detection']=d
        else:
            event_id=self.event_key(d,now)
            self.active[event_id]={'id':event_id,'first_at':now,'last_at':now,'risk':d.risk,
                                   'notified_risk':0,'detection':d,'mfe':0,'mae':0,'horizons':set(),
                                   'price_ref':d.reference_price,'market_at_trigger':self.latest_market.copy(),
                                   'reference_exchange':d.reference_exchange}
            self.open_episodes[episode]=event_id
            status='CONFIRMED'
        e=self.active[event_id]
        data={'event_id':event_id,'asset':d.asset,'event_type':d.event_type,'exchange':d.exchange,'status':status,
          'first_at':e['first_at'],'last_at':now,'exchange_event_ms':d.event_time_ms,'receive_at':d.received_at,
          'decision_at':d.decided_at,'reference_price':e['price_ref'],
          'reference_exchange':d.reference_exchange,'direction':d.direction,'risk':d.risk,
          'confidence':d.confidence,'quality':'OK' if d.confidence!='LOW' else 'PARTIAL',
          'evidence_json':json.dumps(d.evidence,ensure_ascii=False,allow_nan=False),
          'market_context_json':json.dumps(e['market_at_trigger'],ensure_ascii=False),
          'coverage_json':json.dumps(d.coverage,ensure_ascii=False),'notification_status':'SHADOW'}
        await self.storage.write('event',data)
        if getattr(config,'radar_notification_mode','shadow')=='live' and status in ('CONFIRMED','ESCALATED'):
            await self._notify(d,event_id,now,status)
        e['notified_risk']=max(e['notified_risk'],d.risk)
        self.latest_events.insert(0,{**data,'evidence':d.evidence,'coverage':d.coverage})
        self.latest_events=self.latest_events[:100]

    async def _notify(self,d,event_id,now,status):
        from database import enqueue_system_notification
        title=f'📡 Radar R1｜{d.asset}｜{d.event_type}'
        body=(f'交易所：{d.exchange}｜方向：{d.direction}｜风险等级：{d.risk}\n'
              f'证据可信度：{d.confidence}｜现货/永续覆盖：{d.coverage["spot_sources"]}/{d.coverage["perp_sources"]}\n'
              f'证据：{json.dumps(d.evidence,ensure_ascii=False)[:500]}\n'
              '注意：研究预警，不是交易建议；去杠杆指标为代理证据，非全量清算。')
        # negative namespace far from legacy MODEL_A keys.
        stable_key=-1*(2_000_000_000_000_000 + int(event_id[:12],16))
        if status=='ESCALATED':stable_key-=1_000_000_000_000_000
        try:
            inserted=await enqueue_system_notification(stable_key,title,body)
            if inserted:
                await self.storage.write('notify',{'at':now,'status':'QUEUED','event_id':event_id,'outbox_key':stable_key})
                await self.storage.flush()  # map must be durable before Telegram acknowledgement
        except Exception:log.exception('Radar Telegram enqueue failed: %s',event_id)

    async def _track(self,features,now):
        for event_id,record in list(self.active.items()):
            age=now-record['first_at']; asset=record['detection'].asset
            f=features.get(asset)
            if not f or not f['price_ref']:
                if age>=240*60:
                    await self.storage.write('incomplete',{'event_id':event_id,'at':now})
                    self.active.pop(event_id,None)
                continue
            d=record['detection']; direction=d.direction
            # Prefer the venue at trigger, not a changing cross-venue reference.
            source=record.get('reference_exchange') or d.reference_exchange
            q=f['perps'].get(d.exchange) if d.exchange!='MULTI' else f['perps'].get(source)
            if not q:
                if age>=240*60:
                    await self.storage.write('incomplete',{'event_id':event_id,'at':now})
                    self.active.pop(event_id,None)
                continue
            price=q.price
            r=directional(direction,change_pct(price,record['price_ref']))
            record['mfe']=max(record['mfe'],r);record['mae']=min(record['mae'],r)
            bucket=min(240,int(age//60))
            await self.storage.write('path',{'event_id':record['id'],'elapsed_bucket':bucket,
              'observed_at':now,'price':price,'return_pct':r,
              'running_mfe':record['mfe'],'running_mae':record['mae']})
            # Asynchronous polling does not give exact 30/60/120/240 minute outcomes.
            # First observation at/after horizon is labeled observed-after-horizon.
            for horizon in (30,60,120,240):
                if age>=horizon*60 and horizon not in record['horizons']:
                    record['horizons'].add(horizon)
                    await self.storage.write('horizon',{'event_id':record['id'],'minute':horizon,'return_pct':r})
            if age>=240*60:
                await self.storage.write('finish',{'event_id':record['id'],'at':now})
                self.active.pop(event_id,None)

    async def _snapshot_health(self,quotes,now):
        groups=defaultdict(list)
        for q in quotes:groups[(q.exchange,q.market)].append(q)
        for ex in ('binance','okx','bybit'):
            for market in ('PERP','SPOT'):
                items=groups.get((ex,market),[])
                count=sum(v.exchange==ex and v.market==market for v in self.client.instruments.values())
                last=max((q.received_at for q in items),default=0)
                await self.storage.write('health',{'at':now,'exchange':ex,'market':market,
                  'instruments':count,'quotes':len(items),'error':self.client.market_errors.get(f'{ex}:{market}') or self.client.market_errors.get(ex),
                  'staleness_seconds':now-last if last else None})

    async def step(self,quotes=None,now=None,do_enrich=True):
        async with self._lock:
            now=time.time() if now is None else now
            if quotes is None: quotes=await self.client.quotes()
            if not quotes:
                self.last_error='all market snapshots missing; no events emitted';return 0
            if do_enrich:
                quotes=await self.client.enrich(quotes,self.focus_assets,
                    binance_oi_budget=int(getattr(config,'radar_binance_oi_budget',10)))
                quotes=await self.client.sample_spot_tape(quotes,self.focus_assets,
                    budget=int(getattr(config,'radar_spot_tape_budget',6)))
            feats=self.make_aggregate(quotes,now)
            self.latest_market=self.cross_market_snapshot(feats,now)
            await self._track(feats,now)
            detections=[]
            for asset,f in feats.items():
                detections.extend(self.detect(f,now))
                if f['coverage']['perp_sources'] and f['coverage']['price_delta_sources']:
                    # Deterministic 5% sampled no-alert comparison population.
                    minute=int(now//60)
                    if int(hashlib.md5(f'{asset}:{minute//5}'.encode()).hexdigest()[:4],16)%20==0:
                        await self.storage.write('control',{
                            'asset':asset,'observed_minute':minute,'source_count':f['coverage']['perp_sources'],
                            'spot_count':f['coverage']['spot_sources'],'reference_price':f['price_ref'],
                            'market_breadth':self.latest_market.get('breadth_score'),
                            'features_json':json.dumps({'perp_move':f['perp_move'],'spot_move':f['spot_move'],
                                 'oi_base':f['oi_delta_base'],'spot_sample':f['spot_tape']},ensure_ascii=False)})
            for d in detections:await self._emit(d,now)
            # Baseline is updated only after detection and tracking.
            for q in quotes:
                key=f'{q.exchange}:{q.market}:{q.symbol}'
                if fresh(q,now):self.prev[key]=q;self.prev_seen[key]=q.received_at
            active=set(d.asset for d in detections)
            self.focus_assets={'BTC','ETH'}|active
            # Expand OI sampling to liquid top names even before any anomaly.
            liquidity=sorted((q for q in quotes if q.market=='PERP' and q.volume_24h_quote),
                             key=lambda q:q.volume_24h_quote or 0,reverse=True)
            self.focus_assets.update(q.asset for q in liquidity[:30])
            self.last_cycle=now;self.last_success=time.time();self.last_error='';self.cycles+=1
            await self._snapshot_health(quotes,now)
            # Debounce memory after 5h but 240m life is kept for scoring.
            return len(detections)

    async def restore(self):
        '''On restart recover unfinished 240m paths, not retrospective Telegram alerts.'''
        from radar_storage import connect
        def load():
            with connect(self.storage.path) as db:
                rows=[dict(r) for r in db.execute('''SELECT * FROM radar_events
                   WHERE completed_at IS NULL AND first_at>? AND status!='EXPIRED_INCOMPLETE'
                   ORDER BY first_at''',(time.time()-5*3600,))]
                paths={}
                for r in rows:
                    paths[r['event_id']]=[dict(x) for x in db.execute(
                      'SELECT * FROM radar_path WHERE event_id=? ORDER BY elapsed_bucket',(r['event_id'],))]
                return rows,paths
        rows,paths=await asyncio.to_thread(load)
        for r in rows:
            try:
                det=Detection(r['asset'],r['event_type'],r['exchange'],r['direction'],r['risk'],
                              r['confidence'],json.loads(r['evidence_json']),r['reference_price'],
                              r['reference_exchange'],r['exchange_event_ms'],r['receive_at'] or r['first_at'],
                              r['decision_at'],json.loads(r['coverage_json']))
                record={'id':r['event_id'],'first_at':r['first_at'],'last_at':r['last_at'],
                        'risk':r['risk'],'notified_risk':r['risk'],'detection':det,
                        'mfe':r['mfe_pct'],'mae':r['mae_pct'],'price_ref':r['reference_price'],
                        'market_at_trigger':json.loads(r.get('market_context_json') or '{}'),
                        'reference_exchange':r['reference_exchange'],
                        'horizons':{m for m in (30,60,120,240) if r[f'return_{m}m'] is not None}}
                self.active[r['event_id']]=record
                ep=f"{r['asset']}:{r['event_type']}:{r['exchange']}:{r['direction']}"
                self.open_episodes[ep]=r['event_id']
            except (KeyError,TypeError,ValueError):
                log.exception('cannot restore radar event %s',r.get('event_id'))

    async def loop(self):
        await self.storage.start()
        await self.restore()
        while True:
            try:
                now=time.time()
                if now>=self.next_discovery:
                    self.discovered=await self.client.discover()
                    self.next_discovery=now+max(300,int(getattr(config,'radar_discovery_minutes',30))*60)
                await self.step()
                if now-self.last_compaction>21600:
                    await self.storage.compact(days=int(getattr(config,'radar_path_retention_days',7)))
                    self.last_compaction=now
            except asyncio.CancelledError:raise
            except Exception as exc:
                self.last_error=f'{type(exc).__name__}: {str(exc)[:250]}'
                log.exception('Radar cycle failed; no synthetic data substituted')
            await asyncio.sleep(int(getattr(config,'radar_poll_seconds',75)))

    def status(self):
        now=time.time()
        return {'engine_version':ENGINE_VERSION,'enabled':getattr(config,'radar_enabled',False),
            'mode':getattr(config,'radar_notification_mode','shadow'),'last_cycle':self.last_cycle,
            'age_seconds':now-self.last_cycle if self.last_cycle else None,
            'cycles':self.cycles,'last_error':self.last_error,'coverage':self.discovered,
            'market_errors':self.client.market_errors,'http_errors':self.client.http.errors,
            'instruments':len(self.client.instruments),'focus_assets':len(self.focus_assets),
            'cross_market_breadth':self.latest_market,
            'active_episodes':len(self.active),'storage':self.storage.health(),
            'last_events':self.latest_events[:20],
            'last_compaction':self.last_compaction}

    async def close(self):
        await self.storage.close();await self.client.close()
