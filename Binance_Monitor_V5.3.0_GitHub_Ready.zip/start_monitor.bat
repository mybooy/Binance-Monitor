@echo off
setlocal
title Binance Smart Flow Cockpit V5.3.0 Fusion
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

if exist "venv\Scripts\python.exe" goto RUN
where py >nul 2>nul && (py -3.11 -m venv venv) || (python -m venv venv)

:INSTALL
"venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto FAIL

:RUN
"venv\Scripts\python.exe" -c "import aiohttp,fastapi,pydantic,pydantic_settings,uvicorn" >nul 2>nul
if errorlevel 1 goto INSTALL
"venv\Scripts\python.exe" -c "from config import config; print('Dashboard: http://127.0.0.1:' + str(config.port))"
"venv\Scripts\python.exe" main.py
goto END

:FAIL
echo Dependency installation failed.
pause
:END
endlocal
