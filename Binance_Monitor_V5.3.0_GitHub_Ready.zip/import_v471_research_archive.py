"""Import the compact V4.7.1 research archive into V4.8 research_archive.db.

Usage: python import_v471_research_archive.py path/to/V4.7.1_research_archive_20261007.db
Only completed 240-minute Model-A rows are imported. V4.7.1 has no Breadth or
1H/4H middle-line context, so those fields intentionally remain NULL/UNKNOWN.
"""
from __future__ import annotations
import sqlite3, sys, time
from pathlib import Path
import research_archive

src=Path(sys.argv[1]) if len(sys.argv)>1 else Path('V4.7.1_research_archive_20261007.db')
if not src.exists():
    raise SystemExit(f'找不到旧研究归档: {src}')
sdb=sqlite3.connect(src); sdb.row_factory=sqlite3.Row
names={r[0] for r in sdb.execute("select name from sqlite_master where type='table'")}
if 'signal_research_summary' not in names:
    raise SystemExit('不是支持的 V4.7.1 研究归档：缺少 signal_research_summary')
rows=[dict(r) for r in sdb.execute("select * from signal_research_summary where coalesce(completed,0)=1 and return_240m is not null")]
sdb.close()
with research_archive._connect() as adb:
    cols={r[1] for r in adb.execute('pragma table_info(model_a_research)')}
    n=0
    for d in rows:
        rec={
            'source_version':d.get('source_signal_engine_version') or '4.7.1', 'source_id':int(d['source_id']),
            'symbol':d['symbol'],'direction':d['direction'],'signal_at':float(d['observation_at']),'trigger_price':float(d['trigger_price']),
            'actual_vr':d.get('actual_vr_at_trigger'),'atr_pct':d.get('atr_pct'),'atr_percentile_200':d.get('atr_percentile_200'),
            'atr_percentile_500':d.get('atr_percentile_500'),'trigger_move_atr_ratio':d.get('trigger_move_atr_ratio'),
            'directional_close_location':d.get('directional_close_location'),'fixed_a_plus':int(d.get('high_quality_confirmed') or 0),
            'a_plus_plus_trend':int(d.get('a_plus_plus_trend') or 0),'a_plus_plus_persistence':int(d.get('a_plus_plus_persistence') or 0),
            'market_spike_risk':d.get('market_spike_risk'),'market_direction_score':d.get('market_direction_score'),
            'market_stress_score':d.get('market_stress_score'),'breadth_status':None,'bb_1h_position':None,'bb_4h_position':None,
            'bb_trend_context':None,'trend_alignment':None,'running_mfe_pct':d.get('running_mfe_pct'),'running_mae_pct':d.get('running_mae_pct'),
            'time_to_mfe_minutes':d.get('time_to_mfe_minutes'),'first_plus_1_min':d.get('first_plus_1_min'),
            'first_plus_2_min':d.get('first_plus_2_min'),'first_plus_3_min':d.get('first_plus_3_min'),'first_plus_5_min':d.get('first_plus_5_min'),
            'first_minus_1_min':d.get('first_minus_1_min'),'first_minus_1_5_min':d.get('first_minus_1_5_min'),'first_minus_2_min':d.get('first_minus_2_min'),
            'giveback_pct':d.get('giveback_pct'),'giveback_ratio':d.get('giveback_ratio'),'archived_at':time.time(),
        }
        for m in (1,3,5,10,15,20,30,45,60,90,120,240):
            for prefix in ('return','mfe','mae'):
                rec[f'{prefix}_{m}m']=d.get(f'{prefix}_{m}m')
        rec={k:v for k,v in rec.items() if k in cols}
        keys=list(rec)
        sql=f"insert into model_a_research ({','.join(keys)}) values ({','.join('?' for _ in keys)}) on conflict(source_dataset,source_version,source_id) do update set "+','.join(f"{k}=excluded.{k}" for k in keys if k not in {'source_dataset','source_version','source_id'})
        adb.execute(sql,[rec[k] for k in keys]); n+=1
    adb.commit()
print(f'导入完成: {n} 条成熟 V4.7.1 Model A -> {research_archive.ARCHIVE_PATH}')
