"""Shared Model B resources. Scoring and discovery live exclusively in model_b.py."""
from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict, deque

import aiohttp
from config import ROOT

logger = logging.getLogger("v4.model_b")
SECTOR_MAP_PATH = ROOT / "sector_map.json"


class RadarResources:
    def __init__(self, data_engine):
        self.data_engine = data_engine
        self._session = None
        self._running = False
        self._liq_task = None
        self.top_monitored_symbols = []
        self.monitored_snapshots = {}
        self.symbol_state_machine = {}
        self._liquidations = defaultdict(lambda: deque(maxlen=5000))
        self.sector_map = {}
        self.symbol_to_sector = {}
        self._sector_map_mtime = 0
        self.reload_sector_map()

    def reload_sector_map(self):
        try:
            mtime = SECTOR_MAP_PATH.stat().st_mtime
            if mtime != self._sector_map_mtime:
                data = json.loads(SECTOR_MAP_PATH.read_text(encoding="utf-8"))
                self.sector_map = {k:[s.upper() for s in v] for k,v in data.items()}
                self.symbol_to_sector = {s:k for k,v in self.sector_map.items() for s in v}
                self._sector_map_mtime = mtime
        except (OSError, ValueError, TypeError) as exc:
            logger.warning("Sector metadata unavailable: %s",type(exc).__name__)

    async def _get_session(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()),
                timeout=aiohttp.ClientTimeout(total=8))
        return self._session

    async def start(self):
        self._running = True
        if self._liq_task is None or self._liq_task.done():
            self._liq_task = asyncio.create_task(self._all_market_liquidation_loop(),name="model-b-liquidations")

    async def _all_market_liquidation_loop(self):
        raise NotImplementedError("Use ModelBEngine")

    async def close(self):
        self._running = False
        if self._liq_task:
            self._liq_task.cancel()
            await asyncio.gather(self._liq_task,return_exceptions=True)
        if self._session and not self._session.closed:
            await self._session.close()
