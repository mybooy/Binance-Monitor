"""External exchange and aggregate data adapters (OKX, Bybit, CMC, CoinGecko).
Provides standardized cross-exchange metrics to eliminate single-exchange blind spots.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import aiohttp
from config import config

logger = logging.getLogger("v4.external_adapters")


class OKXAdapter:
    """OKX V5 Public REST API Adapter."""
    BASE_URL = "https://www.okx.com"

    def __init__(self, session: aiohttp.ClientSession):
        self.session = session

    @staticmethod
    def to_okx_symbol(usdt_symbol: str) -> str:
        base = usdt_symbol.removesuffix("USDT")
        return f"{base}-USDT-SWAP"

    async def fetch_derivatives_metrics(self, symbol: str) -> dict[str, Any] | None:
        inst_id = self.to_okx_symbol(symbol)
        proxy = config.proxy_url if config.use_proxy else None
        headers = {"Accept": "application/json"}
        try:
            oi_task = self.session.get(
                f"{self.BASE_URL}/api/v5/public/open-interest",
                params={"instType": "SWAP", "instId": inst_id},
                headers=headers,
                proxy=proxy,
            )
            funding_task = self.session.get(
                f"{self.BASE_URL}/api/v5/public/funding-rate",
                params={"instId": inst_id},
                headers=headers,
                proxy=proxy,
            )
            resp_oi, resp_fund = await asyncio.gather(oi_task, funding_task, return_exceptions=True)

            oi_val = 0.0
            if not isinstance(resp_oi, Exception) and resp_oi.status == 200:
                data = await resp_oi.json()
                rows = data.get("data", [])
                if rows:
                    oi_val = float(rows[0].get("oiCcy") or rows[0].get("oi") or 0.0)

            funding_apr = 0.0
            if not isinstance(resp_fund, Exception) and resp_fund.status == 200:
                data = await resp_fund.json()
                rows = data.get("data", [])
                if rows:
                    rate = float(rows[0].get("fundingRate") or 0.0)
                    funding_apr = rate * 3 * 365 * 100.0

            return {
                "exchange": "OKX",
                "symbol": symbol,
                "open_interest": oi_val,
                "funding_apr": round(funding_apr, 2),
                "timestamp": time.time(),
            }
        except Exception as exc:
            logger.debug("OKX fetch degraded | %s | %s", symbol, exc)
            return None


class BybitAdapter:
    """Bybit V5 Public Market API Adapter."""
    BASE_URL = "https://api.bybit.com"

    def __init__(self, session: aiohttp.ClientSession):
        self.session = session

    async def fetch_derivatives_metrics(self, symbol: str) -> dict[str, Any] | None:
        proxy = config.proxy_url if config.use_proxy else None
        try:
            url = f"{self.BASE_URL}/v5/market/tickers"
            params = {"category": "linear", "symbol": symbol}
            async with self.session.get(url, params=params, proxy=proxy) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    rows = data.get("result", {}).get("list", [])
                    if rows:
                        r = rows[0]
                        rate = float(r.get("fundingRate") or 0.0)
                        return {
                            "exchange": "Bybit",
                            "symbol": symbol,
                            "open_interest": float(r.get("openInterestValue") or r.get("openInterest") or 0.0),
                            "funding_apr": round(rate * 3 * 365 * 100.0, 2),
                            "index_price": float(r.get("indexPrice") or 0.0),
                            "mark_price": float(r.get("markPrice") or 0.0),
                            "timestamp": time.time(),
                        }
        except Exception as exc:
            logger.debug("Bybit fetch degraded | %s | %s", symbol, exc)
            return None


class ExternalMarketAggregator:
    """Coordinates Binance, OKX, Bybit and global macro indices."""
    def __init__(self):
        self._session: aiohttp.ClientSession | None = None
        self.okx: OKXAdapter | None = None
        self.bybit: BybitAdapter | None = None
        self.latest_macro = {
            "btc_dominance": 0.0,
            "total_market_cap_usd": 0.0,
            "market_cap_change_24h_pct": 0.0,
            "total_volume_24h_usd": 0.0,
            "source": "UNKNOWN",
            "updated_at": 0.0,
        }

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()),
                timeout=aiohttp.ClientTimeout(total=8),
            )
            self.okx = OKXAdapter(self._session)
            self.bybit = BybitAdapter(self._session)
        return self._session

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()

    async def fetch_global_metrics(self) -> dict[str, Any]:
        """Fetch whole-network market metrics via CMC or CoinGecko fallback."""
        if not config.cmc_enabled:
            return self.latest_macro

        session = await self._ensure_session()
        proxy = config.proxy_url if config.use_proxy else None

        if config.cmc_api_key:
            try:
                headers = {"X-CMC_PRO_API_KEY": config.cmc_api_key, "Accept": "application/json"}
                url = "https://pro-api.coinmarketcap.com/v1/global-metrics/quotes/latest"
                async with session.get(url, headers=headers, proxy=proxy) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        d = data.get("data", {})
                        quote_usd = d.get("quote", {}).get("USD", {})
                        self.latest_macro = {
                            "btc_dominance": float(d.get("btc_dominance") or 0.0),
                            "eth_dominance": float(d.get("eth_dominance") or 0.0),
                            "total_market_cap_usd": float(quote_usd.get("total_market_cap") or 0.0),
                            "market_cap_change_24h_pct": float(quote_usd.get("total_market_cap_yesterday_percentage_change") or 0.0),
                            "total_volume_24h_usd": float(quote_usd.get("total_volume_24h") or 0.0),
                            "source": "CoinMarketCap",
                            "updated_at": time.time(),
                        }
                        return self.latest_macro
            except Exception as exc:
                logger.debug("CMC fetch failed: %s", exc)

        try:
            url = "https://api.coingecko.com/api/v3/global"
            async with session.get(url, proxy=proxy) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    d = data.get("data", {})
                    self.latest_macro = {
                        "btc_dominance": float(d.get("market_cap_percentage", {}).get("btc") or 0.0),
                        "eth_dominance": float(d.get("market_cap_percentage", {}).get("eth") or 0.0),
                        "total_market_cap_usd": float(d.get("total_market_cap", {}).get("usd") or 0.0),
                        "market_cap_change_24h_pct": float(d.get("market_cap_change_percentage_24h_usd") or 0.0),
                        "total_volume_24h_usd": float(d.get("total_volume", {}).get("usd") or 0.0),
                        "source": "CoinGecko_Public",
                        "updated_at": time.time(),
                    }
                    return self.latest_macro
        except Exception as exc:
            logger.debug("CoinGecko public fallback skipped: %s", exc)

        return self.latest_macro

    async def cross_verify_symbol(self, symbol: str, binance_metrics: dict[str, Any]) -> dict[str, Any]:
        """Cross-validate Binance metrics against OKX & Bybit."""
        await self._ensure_session()
        tasks = [
            self.okx.fetch_derivatives_metrics(symbol),
            self.bybit.fetch_derivatives_metrics(symbol),
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        external_data = {}
        for r in results:
            if isinstance(r, dict) and r.get("exchange"):
                external_data[r["exchange"]] = r

        b_apr = float(binance_metrics.get("funding_apr") or 0.0)
        rates = [b_apr]
        for _, d in external_data.items():
            if d.get("funding_apr") is not None:
                rates.append(d["funding_apr"])

        consensus_apr = sum(rates) / len(rates)
        peer_rates = rates[1:]
        divergence = False
        if peer_rates:
            peer_avg = sum(peer_rates) / len(peer_rates)
            if abs(b_apr - peer_avg) >= 15.0:
                divergence = True

        return {
            "symbol": symbol,
            "consensus_funding_apr": round(consensus_apr, 2),
            "binance_funding_apr": b_apr,
            "peer_count": len(external_data),
            "external_snapshots": external_data,
            "is_divergent": divergence,
            "verified_by_peers": len(external_data) > 0 and not divergence,
        }


external_aggregator = ExternalMarketAggregator()