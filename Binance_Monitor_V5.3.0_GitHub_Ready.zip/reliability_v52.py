"""Recovery of missed Model-A persistence bars. Historical repair NEVER emits real-time alerts."""
from __future__ import annotations

import asyncio
import logging
import time

from config import config
from database import DB_PATH, _LOCK, _connect, _persistence_state, update_persistence, update_close_persistence, _spike_risk

log=logging.getLogger('v52.recovery')


def _candidates(limit=80):
    with _LOCK,_connect() as db:
        db.execute("CREATE INDEX IF NOT EXISTS idx_recovery_observation ON volume_alerts(observation_at)")
        rows=db.execute('''SELECT id,symbol,direction,window_open,observation_at,trigger_price,atr_pct,
              persistence_1m_pct,persistence_2m_pct,persistence_3m_pct,persistence_5m_pct,
              persistence_15m_close_pct,persistence_next_15m_close_pct,high_quality_confirmed
              FROM volume_alerts WHERE observation_at BETWEEN ? AND ?
              AND (persistence_1m_pct IS NULL OR persistence_2m_pct IS NULL OR
                   persistence_3m_pct IS NULL OR persistence_5m_pct IS NULL OR
                   (window_open+900<? AND persistence_15m_close_pct IS NULL) OR
                   (window_open+1800<? AND persistence_next_15m_close_pct IS NULL))
              ORDER BY observation_at DESC LIMIT ?''',
             (time.time()-86400,time.time()-300,time.time()-300,time.time()-300,int(limit))).fetchall()
        return [dict(row) for row in rows]


def _mark_recovered_aplus(alert_id,price,confirmed_at):
    with _LOCK,_connect() as db:
        db.execute('''UPDATE volume_alerts SET high_quality_confirmed=1,
           high_quality_confirmed_at=COALESCE(high_quality_confirmed_at,?),
           a_plus_confirm_price=COALESCE(a_plus_confirm_price,?),
           a_plus_confirm_at=COALESCE(a_plus_confirm_at,?) WHERE id=?''',
           (confirmed_at,price,confirmed_at,alert_id))
        db.execute('''UPDATE signal_lifecycle SET confirmation_entry_price=COALESCE(confirmation_entry_price,?),
          confirmation_entry_at=COALESCE(confirmation_entry_at,?) WHERE source_type='MODEL_A' AND source_id=?''',
          (price,confirmed_at,alert_id))
        db.commit()


def _mark_recovery_provenance(alert_id):
    with _LOCK,_connect() as db:
        cols={r[1] for r in db.execute('PRAGMA table_info(volume_alerts)')}
        if 'backfilled_at' not in cols:
            db.execute('ALTER TABLE volume_alerts ADD COLUMN backfilled_at REAL')
        db.execute('UPDATE volume_alerts SET backfilled_at=? WHERE id=?',(time.time(),alert_id))
        db.commit()


def recompute_spike_counts():
    # Aggregate first-trigger counts by exchange observation minute AND immutable signal version.
    # Count distinct symbols at minute granularity, not exact subsecond timestamps.
    # Earlier versions are retained as their own cohorts.
    with _LOCK,_connect() as db:
        rows=db.execute('''SELECT CAST(observation_at/60 AS INTEGER) minute,
            source_signal_engine_version version,COUNT(DISTINCT symbol) n
            FROM volume_alerts WHERE observation_at>? AND source_signal_engine_version!=''
            GROUP BY minute,source_signal_engine_version''',(time.time()-2*86400,)).fetchall()
        affected=0
        for r in rows:
            n=int(r['n']);risk=_spike_risk(n)
            db.execute('''UPDATE volume_alerts SET market_spike_count_1m=?,market_spike_risk=?,
                systemic_market_shock=? WHERE observation_at>=? AND observation_at<?
                AND source_signal_engine_version=?''',
                (n,risk,int(risk=='EXTREME'),int(r['minute'])*60,(int(r['minute'])+1)*60,r['version']))
            affected+=1
        db.commit()
    return affected


async def backfill_persistence(client,limit=80):
    rows=_candidates(limit)
    semaphore=asyncio.Semaphore(4)
    n=0
    async def one(r):
        nonlocal n
        # Each original 1m bar is fetched from Binance; repaired labels are historical only.
        begin=int(float(r['observation_at']))
        end=int(r['window_open'])+1800
        async with semaphore:
            try:
                raw=await client.get('/fapi/v1/klines',symbol=r['symbol'],interval='1m',
                  startTime=begin*1000,endTime=(end+60)*1000,limit=40)
            except Exception as e:
                log.warning('backfill %s: %s',r['symbol'],str(e)[:100]);return
        bars={int(x[0])/1000:x for x in raw if isinstance(x,(list,tuple)) and len(x)>=7}
        d=1 if r['direction']=='LONG' else -1
        trigger=float(r['trigger_price'])
        recovered=False
        for m in (1,2,3,5):
            col=f'persistence_{m}m_pct'
            if r[col] is not None:continue
            start=begin+(m-1)*60
            bar=bars.get(start)
            if bar is None or float(bar[6])/1000>time.time():continue
            pct=(float(bar[4])/trigger-1)*100*d
            await update_persistence(int(r['id']),m,pct)
            recovered=True
            if m==1 and float(r['atr_pct'] or 0)>=config.model_a_hq_atr_pct and pct>=config.model_a_hq_persistence_1m_pct:
                _mark_recovered_aplus(int(r['id']),float(bar[4]),begin+60)
                # Recompute A++ flags after fixed-A+ is recovered (without sending retrospective alerts).
                for j in (3,5):
                    if r[f'persistence_{j}m_pct'] is not None:
                        await update_persistence(int(r['id']),j,r[f'persistence_{j}m_pct'])
        for which,key,target in [('CURRENT','persistence_15m_close_pct',int(r['window_open'])+840),
                                 ('NEXT','persistence_next_15m_close_pct',int(r['window_open'])+1740)]:
            if r[key] is not None:continue
            bar=bars.get(target)
            if bar and float(bar[6])/1000<=time.time():
                await update_close_persistence(int(r['id']),which,(float(bar[4])/trigger-1)*100*d)
                recovered=True
        if recovered:
            _mark_recovery_provenance(int(r['id']))
            n+=1
    await asyncio.gather(*(one(r) for r in rows))
    return {'candidates':len(rows),'repaired_signals':n,'historical_only':True}
