"""V5.2 isolated radar persistence. Single writer with bounded asynchronous backpressure.
Independent SQLite file so V4.8 Model-A schema and historical studies remain untouched.
"""
from __future__ import annotations

import asyncio
import json
import sqlite3
import time
from pathlib import Path
from config import ROOT

SCHEMA='''
PRAGMA journal_mode=WAL;
PRAGMA synchronous=FULL;
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS radar_events (
 event_id TEXT PRIMARY KEY,engine_version TEXT NOT NULL DEFAULT 'RADAR_R1_5.2.0',
 asset TEXT NOT NULL,event_type TEXT NOT NULL,exchange TEXT NOT NULL,
 status TEXT NOT NULL,first_at REAL NOT NULL,last_at REAL NOT NULL,
 exchange_event_ms INTEGER,receive_at REAL,decision_at REAL NOT NULL,notify_at REAL,notify_queued_at REAL,
 reference_price REAL NOT NULL,reference_exchange TEXT NOT NULL,direction TEXT NOT NULL,
 risk INTEGER NOT NULL,confidence TEXT NOT NULL,quality TEXT NOT NULL,
 evidence_json TEXT NOT NULL,coverage_json TEXT NOT NULL,market_context_json TEXT NOT NULL DEFAULT '{}',
 completed_at REAL,first_plus_1_at REAL,first_plus_2_at REAL,first_minus_1_at REAL,
 mfe_pct REAL NOT NULL DEFAULT 0,mae_pct REAL NOT NULL DEFAULT 0,
 return_30m REAL,return_60m REAL,return_120m REAL,return_240m REAL,
 net_120m REAL,net_240m REAL,notification_status TEXT NOT NULL DEFAULT 'SHADOW'
);
CREATE INDEX IF NOT EXISTS ix_radar_event ON radar_events(first_at DESC,asset,event_type);
CREATE TABLE IF NOT EXISTS radar_path (
 event_id TEXT NOT NULL,elapsed_bucket INTEGER NOT NULL,observed_at REAL NOT NULL,
 price REAL NOT NULL,return_pct REAL NOT NULL,running_mfe REAL NOT NULL,running_mae REAL NOT NULL,
 PRIMARY KEY(event_id,elapsed_bucket)
);
CREATE TABLE IF NOT EXISTS radar_controls (
 asset TEXT NOT NULL,observed_minute INTEGER NOT NULL,source_count INTEGER NOT NULL,
 spot_count INTEGER NOT NULL,reference_price REAL,market_breadth REAL,features_json TEXT NOT NULL,
 PRIMARY KEY(asset,observed_minute)
);
CREATE TABLE IF NOT EXISTS radar_notification_map (outbox_key INTEGER PRIMARY KEY, event_id TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS radar_health (
 at REAL NOT NULL,exchange TEXT NOT NULL,market TEXT NOT NULL,
 instruments INTEGER NOT NULL,quotes INTEGER NOT NULL,error TEXT,staleness_seconds REAL,
 PRIMARY KEY(at,exchange,market)
);
'''


def connect(path):
    db=sqlite3.connect(path,timeout=20)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA busy_timeout=20000')
    return db


def bootstrap(path):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with connect(path) as db:
        db.executescript(SCHEMA)
        cols={r[1] for r in db.execute('PRAGMA table_info(radar_events)')}
        if 'notify_queued_at' not in cols:
            db.execute('ALTER TABLE radar_events ADD COLUMN notify_queued_at REAL')
        if 'market_context_json' not in cols:
            db.execute("ALTER TABLE radar_events ADD COLUMN market_context_json TEXT NOT NULL DEFAULT '{}'")


def apply_batch(path,records):
    with connect(path) as db:
        for action, record in records:
            if action=='event':
                db.execute('''INSERT INTO radar_events(event_id,asset,event_type,exchange,status,first_at,last_at,
                    exchange_event_ms,receive_at,decision_at,reference_price,reference_exchange,direction,risk,
                    confidence,quality,evidence_json,coverage_json,notification_status,market_context_json)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(event_id) DO UPDATE SET last_at=excluded.last_at,status=excluded.status,
                    risk=MAX(radar_events.risk,excluded.risk),confidence=excluded.confidence,
                    quality=excluded.quality,evidence_json=excluded.evidence_json,coverage_json=excluded.coverage_json,
                    notification_status=CASE WHEN radar_events.notification_status IN ('SENT','QUEUED') THEN radar_events.notification_status ELSE excluded.notification_status END''',
                    tuple(record[k] for k in ('event_id','asset','event_type','exchange','status','first_at','last_at',
                    'exchange_event_ms','receive_at','decision_at','reference_price','reference_exchange','direction','risk',
                    'confidence','quality','evidence_json','coverage_json','notification_status'))+(record.get('market_context_json','{}'),))
            elif action=='path':
                db.execute('''INSERT OR IGNORE INTO radar_path
                  (event_id,elapsed_bucket,observed_at,price,return_pct,running_mfe,running_mae)
                  VALUES(?,?,?,?,?,?,?)''',tuple(record[k] for k in ('event_id','elapsed_bucket','observed_at',
                  'price','return_pct','running_mfe','running_mae')))
                db.execute('''UPDATE radar_events SET
                   mfe_pct=MAX(mfe_pct,?),mae_pct=MIN(mae_pct,?),
                   first_plus_1_at=CASE WHEN first_plus_1_at IS NULL AND ?>=1 THEN ? ELSE first_plus_1_at END,
                   first_plus_2_at=CASE WHEN first_plus_2_at IS NULL AND ?>=2 THEN ? ELSE first_plus_2_at END,
                   first_minus_1_at=CASE WHEN first_minus_1_at IS NULL AND ?<=-1 THEN ? ELSE first_minus_1_at END
                   WHERE event_id=?''', (record['running_mfe'],record['running_mae'],record['return_pct'],record['observed_at'],
                       record['return_pct'],record['observed_at'],record['return_pct'],record['observed_at'],record['event_id']))
            elif action=='horizon':
                col={30:'return_30m',60:'return_60m',120:'return_120m',240:'return_240m'}[record['minute']]
                db.execute(f'UPDATE radar_events SET {col}=? WHERE event_id=? AND {col} IS NULL',
                           (record['return_pct'],record['event_id']))
            elif action=='finish':
                db.execute("UPDATE radar_events SET completed_at=?,status='RESOLVED' WHERE event_id=? AND completed_at IS NULL",
                           (record['at'],record['event_id']))
            elif action=='incomplete':
                db.execute("UPDATE radar_events SET status='EXPIRED_INCOMPLETE' WHERE event_id=? AND completed_at IS NULL",(record['event_id'],))
            elif action=='notify':
                db.execute('INSERT OR IGNORE INTO radar_notification_map(outbox_key,event_id) VALUES(?,?)',
                           (record['outbox_key'],record['event_id']))
                db.execute('UPDATE radar_events SET notify_queued_at=?,notification_status=? WHERE event_id=?',
                           (record['at'],record['status'],record['event_id']))
            elif action=='control':
                db.execute('''INSERT OR IGNORE INTO radar_controls(asset,observed_minute,source_count,spot_count,
                    reference_price,market_breadth,features_json) VALUES(?,?,?,?,?,?,?)''',
                    tuple(record[k] for k in ('asset','observed_minute','source_count','spot_count',
                                             'reference_price','market_breadth','features_json')))
            elif action=='health':
                db.execute('INSERT OR REPLACE INTO radar_health(at,exchange,market,instruments,quotes,error,staleness_seconds) VALUES(?,?,?,?,?,?,?)',
                           tuple(record[k] for k in ('at','exchange','market','instruments','quotes','error','staleness_seconds')))
            else: raise ValueError(f'unsupported radar write operation {action}')


class RadarStorage:
    def __init__(self,path=None,max_queue=25000):
        self.path=Path(path or ROOT/'radar_v52.db')
        self.queue=asyncio.Queue(maxsize=max_queue)
        self.task=None
        self.written=0
        self.failures=0
        self.last_error=None
        self.last_commit_at=0.0
        self._closing=False
        self._failed_batch=None  # unacknowledged writes retained after a transient DB failure

    async def start(self):
        await asyncio.to_thread(bootstrap,self.path)
        if self.task is None or self.task.done():
            self.task=asyncio.create_task(self._worker(),name='radar-db-writer')

    async def write(self,action,record):
        if self._closing: raise RuntimeError('radar storage is closing')
        if self.task is None:raise RuntimeError('radar storage not started')
        if self.task.done():
            await self.start()  # replay failed batch before new queued records
        await self.queue.put((action,record))

    async def _worker(self):
        while True:
            if self._failed_batch is not None:
                batch=self._failed_batch
            else:
                first=await self.queue.get()
                batch=[first]
                while len(batch)<500:
                    try:batch.append(self.queue.get_nowait())
                    except asyncio.QueueEmpty:break
            try:
                for attempt in range(5):
                    try:
                        await asyncio.to_thread(apply_batch,self.path,batch)
                        self.written+=len(batch);self.last_commit_at=time.time();self.last_error=None
                        break
                    except (sqlite3.Error,OSError) as exc:
                        self.failures+=1;self.last_error=str(exc)
                        if attempt==4:raise
                        await asyncio.sleep(min(5,0.25*2**attempt))
            except BaseException:
                # Never call task_done for writes which were not committed.
                self._failed_batch=batch
                raise
            self._failed_batch=None
            for _ in batch:self.queue.task_done()

    async def flush(self):
        if self.task and self.task.done():
            exc=self.task.exception()
            if exc:raise RuntimeError('radar DB writer failed') from exc
        try:
            await asyncio.wait_for(self.queue.join(), timeout=90)
        except asyncio.TimeoutError as exc:
            raise RuntimeError('radar DB writer backlog did not drain in 90s') from exc
        if self.task and self.task.done():
            exc=self.task.exception()
            if exc:raise RuntimeError('radar DB writer failed') from exc

    async def close(self):
        await self.flush()
        self._closing=True
        if self.task:
            self.task.cancel()
            await asyncio.gather(self.task,return_exceptions=True)
            self.task=None

    def health(self):
        return {'queued':self.queue.qsize()+len(self._failed_batch or []),'failed_batch':len(self._failed_batch or []),'written':self.written,'failures':self.failures,
                'last_error':self.last_error,'last_commit_at':self.last_commit_at,
                'writer_alive':bool(self.task and not self.task.done())}

    async def compact(self,days=7):
        """Prune only old completed detailed paths; permanent event-level rows remain."""
        await self.flush()
        days=max(1,int(days))
        def prune():
            with connect(self.path) as db:
                cutoff=time.time()-days*86400
                path=db.execute("DELETE FROM radar_path WHERE event_id IN (SELECT event_id FROM radar_events WHERE completed_at IS NOT NULL AND completed_at<?)",
                                (cutoff,)).rowcount
                controls=db.execute('DELETE FROM radar_controls WHERE observed_minute<?',
                                    (int((time.time()-14*86400)//60),)).rowcount
                health=db.execute('DELETE FROM radar_health WHERE at<?',(time.time()-7*86400,)).rowcount
                return {'path_points_deleted':path,'controls_deleted':controls,'health_deleted':health}
        return await asyncio.to_thread(prune)

    async def recent(self,limit=100):
        await self.flush()
        def query():
            with connect(self.path) as db:
                return [dict(x) for x in db.execute('SELECT * FROM radar_events ORDER BY first_at DESC LIMIT ?', (max(1,min(500,int(limit))),))]
        return await asyncio.to_thread(query)

    async def study(self):
        await self.flush()
        def query():
            with connect(self.path) as db:
                rows=[dict(r) for r in db.execute('SELECT * FROM radar_events WHERE completed_at IS NOT NULL ORDER BY first_at')]
                controls=db.execute('SELECT COUNT(*) FROM radar_controls').fetchone()[0]
            return rows,controls
        rows,controls=await asyncio.to_thread(query)
        from statistics import median
        grouped={}
        for r in rows:
            group=(r['event_type'],r['direction'])
            grouped.setdefault(group,[]).append(r)
        out=[]
        for (kind,direction),values in sorted(grouped.items()):
            returns=[r['return_240m'] for r in values if r['return_240m'] is not None]
            n=len(returns)
            win=sum(v>0 for v in returns)
            # Wilson 95% CI for positive 240m return; no IID claims for correlated events.
            z=1.96; p=win/n if n else None
            den=1+z*z/n if n else 1
            center=(p+z*z/(2*n))/den if n else None
            rad=z*((p*(1-p)/n+z*z/(4*n*n))**.5)/den if n else None
            out.append({'type':kind,'direction':direction,'events':len(values),'mature':n,
                        'median_240m_pct':median(returns) if returns else None,
                        'positive_240m':p,'wilson_95':(center-rad,center+rad) if n else None})
        return {'completed_events':len(rows),'control_samples':controls,'groups':out,
                'warning':'按事件归类，仍需按交易时段聚类/跨批次验证；影子模式不代表真实可执行收益'}


def record_delivery(outbox_key, status, at, path=None):
    """Called after Telegram transport acknowledges delivery (not when merely queued)."""
    path=path or ROOT/'radar_v52.db'
    if not Path(path).exists():return
    with connect(path) as db:
        row=db.execute('SELECT event_id FROM radar_notification_map WHERE outbox_key=?',(int(outbox_key),)).fetchone()
        if row:
            db.execute("UPDATE radar_events SET notification_status=?, notify_at=CASE WHEN ?='SENT' THEN ? ELSE notify_at END WHERE event_id=?",
                  (status,status,at,row['event_id']))
