"""V4.8.0 1H/4H Bollinger-middle trend context.

Only SMA20 (Bollinger middle) is used.  No upper/lower bands, bandwidth,
%B, squeeze, or breakout logic is implemented.  The provider filters out the
currently forming candle and therefore uses only bars completed before the
Model-A trigger timestamp.
"""
from __future__ import annotations

import asyncio
import logging
import time

import aiohttp

from config import config

logger = logging.getLogger(__name__)
TREND_ENGINE_VERSION = "4.8.0"


class TrendContextEngine:
    def __init__(self):
        self._session = None
        self._cache: dict[tuple[str, str, int], tuple[float, float]] = {}
        self._sem = asyncio.Semaphore(int(config.trend_context_concurrency))

    async def _session_obj(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()),
                timeout=aiohttp.ClientTimeout(total=float(config.trend_context_timeout_seconds)),
            )
        return self._session

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()

    @staticmethod
    def _interval_seconds(interval: str) -> int:
        return 3600 if interval == "1h" else 4 * 3600


    @staticmethod
    def _middle_from_rows(raw, signal_at: float):
        """Pure no-lookahead SMA20 helper used by runtime and tests."""
        completed=[]
        for row in raw or []:
            try:
                close_at=float(row[6])/1000.0
                close=float(row[4])
            except (IndexError,TypeError,ValueError):
                continue
            if close_at < float(signal_at):
                completed.append((close_at,close))
        if len(completed) < 20:
            raise RuntimeError("complete bars <20")
        last20=completed[-20:]
        return sum(x[1] for x in last20)/20.0,last20[-1][0]

    async def _middle(self, symbol: str, interval: str, signal_at: float):
        sec = self._interval_seconds(interval)
        # The middle line cannot change until another higher-timeframe bar closes.
        last_complete_boundary = int(signal_at // sec) * sec
        key = (symbol, interval, last_complete_boundary)
        cached = self._cache.get(key)
        if cached:
            return cached

        async with self._sem:
            session = await self._session_obj()
            async with session.get(
                "https://fapi.binance.com/fapi/v1/klines",
                params={"symbol": symbol, "interval": interval, "limit": 30, "endTime": int(signal_at * 1000) - 1},
                proxy=config.proxy_url if config.use_proxy else None,
            ) as resp:
                if resp.status in (418, 429):
                    raise RuntimeError(f"trend-context rate limited: HTTP {resp.status}")
                resp.raise_for_status()
                raw = await resp.json()

        mid, last_closed_at = self._middle_from_rows(raw, signal_at)
        self._cache[key] = (mid, last_closed_at)
        # Bounded cache; stale buckets are cheap to refetch if ever needed.
        if len(self._cache) > 5000:
            for k in list(self._cache)[:1000]:
                self._cache.pop(k, None)
        return mid, last_closed_at

    @staticmethod
    def _position(price: float, mid: float):
        if mid <= 0:
            return "UNKNOWN", None
        distance = (float(price) / float(mid) - 1.0) * 100.0
        eps = float(config.bb_mid_at_tolerance_pct)
        if abs(distance) <= eps:
            return "AT", distance
        return ("ABOVE" if distance > 0 else "BELOW"), distance

    async def snapshot(self, symbol: str, signal_at: float, trigger_price: float):
        if not config.trend_context_enabled:
            return {"data_quality": "UNKNOWN", "reason": "趋势上下文研究已关闭", "engine_version": TREND_ENGINE_VERSION}
        try:
            one, four = await asyncio.wait_for(
                asyncio.gather(self._middle(symbol, "1h", signal_at), self._middle(symbol, "4h", signal_at)),
                timeout=float(config.trend_context_timeout_seconds) + 1.0,
            )
            mid1, close1 = one; mid4, close4 = four
            p1, d1 = self._position(trigger_price, mid1)
            p4, d4 = self._position(trigger_price, mid4)
            if "UNKNOWN" in (p1, p4):
                combo = "UNKNOWN"
            else:
                combo = f"{p1}_{p4}"
            direction = None
            return {
                "bb_1h_mid": mid1, "bb_1h_position": p1, "bb_1h_distance_pct": d1,
                "bb_1h_last_closed_at": close1,
                "bb_4h_mid": mid4, "bb_4h_position": p4, "bb_4h_distance_pct": d4,
                "bb_4h_last_closed_at": close4,
                "bb_trend_context": combo,
                "data_quality": "OK", "reason": "", "sampled_at": time.time(),
                "engine_version": TREND_ENGINE_VERSION,
            }
        except Exception as exc:
            logger.warning("Trend context degraded | %s | %s", symbol, type(exc).__name__)
            return {
                "bb_1h_mid": None, "bb_1h_position": "UNKNOWN", "bb_1h_distance_pct": None,
                "bb_1h_last_closed_at": None,
                "bb_4h_mid": None, "bb_4h_position": "UNKNOWN", "bb_4h_distance_pct": None,
                "bb_4h_last_closed_at": None,
                "bb_trend_context": "UNKNOWN", "data_quality": "UNKNOWN",
                "reason": str(exc)[:160], "sampled_at": time.time(), "engine_version": TREND_ENGINE_VERSION,
            }

    @staticmethod
    def alignment(direction: str, trend: dict):
        p1 = str((trend or {}).get("bb_1h_position") or "UNKNOWN")
        p4 = str((trend or {}).get("bb_4h_position") or "UNKNOWN")
        if "UNKNOWN" in (p1, p4) or "AT" in (p1, p4):
            return "MIXED" if "UNKNOWN" not in (p1, p4) else "UNKNOWN"
        favorable = "ABOVE" if direction == "LONG" else "BELOW"
        opposed = "BELOW" if direction == "LONG" else "ABOVE"
        if p1 == favorable and p4 == favorable:
            return "ALIGNED"
        if p1 == opposed and p4 == opposed:
            return "OPPOSED"
        return "MIXED"


trend_context_engine = TrendContextEngine()
