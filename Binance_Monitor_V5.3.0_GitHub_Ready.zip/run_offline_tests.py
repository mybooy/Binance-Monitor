"""Run this repository's plain test functions using only Python's standard library.

Network access is blocked and all databases point to a temporary directory.
No application lifespan, Telegram delivery or production DB migration is run.
"""
import importlib
import inspect
import socket
import sys
import tempfile
import unittest
import aiohttp
from pathlib import Path
from unittest.mock import patch, AsyncMock

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tests'))


def run_one(function):
    import database
    import research_archive
    from config import config
    with tempfile.TemporaryDirectory(prefix='monitor-offline-') as folder:
        root=Path(folder)
        args={}
        for name in inspect.signature(function).parameters:
            if name=='tmp_path': args[name]=root
            elif name=='monkeypatch': args[name]=None  # legacy fixture is declared but unused
            else: raise ValueError(f'Unsupported fixture: {name}')
        with patch.object(database,'DB_PATH',root/'runtime.db'),patch.object(research_archive,'ARCHIVE_PATH',root/'archive.db'),patch.object(config,'_settings',config._settings.model_copy(deep=True)):
            config._settings.crowding_telegram_enabled=True  # outbox-only; delivery is never invoked
            function(**args)


if __name__=='__main__':
    suite=unittest.TestSuite()
    for path in sorted((ROOT/'tests').glob('test_*.py')):
        module=importlib.import_module(path.stem)
        for name,function in inspect.getmembers(module,inspect.isfunction):
            if name.startswith('test_') and function.__module__==module.__name__:
                suite.addTest(unittest.FunctionTestCase(lambda f=function:run_one(f),description=f'{path.stem}.{name}'))
    original_connect=socket.socket.connect
    def local_eventloop_only(sock,address):
        if address[0] not in ('127.0.0.1','::1'):
            raise AssertionError('External network forbidden in offline tests')
        return original_connect(sock,address)
    with patch.object(socket.socket,'connect',local_eventloop_only),patch.object(aiohttp.ClientSession,'_request',AsyncMock(side_effect=AssertionError('HTTP forbidden in offline tests'))),patch.object(aiohttp.ClientSession,'ws_connect',side_effect=AssertionError('WebSocket forbidden in offline tests')):
        result=unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())
