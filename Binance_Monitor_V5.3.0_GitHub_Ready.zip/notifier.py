"""Durable Telegram delivery with explicit success/failure logging."""
import asyncio
import logging
import time
import aiohttp
from config import config
from database import get_due_notifications, update_notification

logger = logging.getLogger("v4.telegram")


class TelegramNotifier:
    def __init__(self):
        self.session = None

    async def send_alert(self, title, content):
        if not config.telegram_bot_token or not config.telegram_chat_id:
            return False, 30, "未配置 Telegram"
        try:
            if self.session is None or self.session.closed:
                self.session = aiohttp.ClientSession(connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()))
            payload={"chat_id": config.telegram_chat_id, "text": f"{title}\n\n{content}"}
            # Telegram does not support arbitrary font colors. A+ messages use a red emoji plus HTML bold for a strong red visual cue.
            if str(title).startswith("🔴 <b>"):
                payload["parse_mode"]="HTML"
            async with self.session.post(
                f"https://api.telegram.org/bot{config.telegram_bot_token}/sendMessage",
                json=payload,
                proxy=config.proxy_url if config.use_proxy else None,
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                data = await resp.json()
                if resp.status == 200 and data.get("ok") is True:
                    return True, 0, ""
                retry = min(max(float(data.get("parameters", {}).get("retry_after", 0)), 0), 86400)
                return False, retry, f"Telegram HTTP {resp.status}"
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError):
            return False, 0, "Telegram 请求失败"

    async def deliver_pending(self):
        for item in await get_due_notifications():
            now = time.time()
            if now - item.created_at > config.notification_expiry_seconds:
                await update_notification(item.id, "expired", item.attempts, now, "超过投递有效期")
                logger.warning("Telegram expired | id=%s | title=%s", item.id, item.title)
                continue
            ok, retry, error = await self.send_alert(item.title, item.body)
            attempts = item.attempts + 1
            status = "sent" if ok else ("failed" if attempts >= config.notification_max_attempts else "pending")
            next_at = now + max(retry, min(300, 2 ** attempts * 5))
            await update_notification(item.id, status, attempts, next_at, error)
            if status in ('sent','failed','expired') and abs(int(item.alert_id))>=2_000_000_000_000_000:
                try:
                    from radar_storage import record_delivery
                    await asyncio.to_thread(record_delivery,item.alert_id,status.upper(),time.time())
                except Exception:
                    logger.exception('Radar Telegram delivery timestamp reconciliation failed')
            if ok:
                logger.info("Telegram sent | id=%s | title=%s", item.id, item.title)
            else:
                logger.warning("Telegram retry | id=%s | attempt=%s/%s | error=%s",
                               item.id, attempts, config.notification_max_attempts, error)

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()


notifier = TelegramNotifier()
