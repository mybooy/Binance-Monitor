"""One bounded REST client shared by scan and evaluation workloads."""
import asyncio
import logging
import time
import aiohttp
from config import config

logger = logging.getLogger(__name__)

class MarketClient:
    def __init__(self):
        self.session = None
        self.limit = asyncio.Semaphore(config.request_concurrency)
        self.retry_after = 0.0
        self.rate_limited_until = 0.0
        self.last_success_at = 0.0
        self.last_error_at = 0.0
        self.last_error = ""

    def record_error(self, error):
        self.last_error_at = time.time()
        self.last_error = error

    def network_state(self):
        now = time.time()
        if self.rate_limited_until > now:
            return {"status": "rate_limited", "label": "限流冷却",
                    "last_success": self.last_success_at, "last_error": self.last_error,
                    "retry_at": self.rate_limited_until}
        if self.last_error and self.last_error_at >= self.last_success_at:
            return {"status": "error", "label": "连接异常",
                    "last_success": self.last_success_at, "last_error": self.last_error}
        if not self.last_success_at:
            return {"status": "waiting", "label": "等待首次请求",
                    "last_success": 0.0, "last_error": ""}
        return {"status": "healthy", "label": "正常",
                "last_success": self.last_success_at, "last_error": ""}

    async def get(self, path, _headers=None, **params):
        for attempt in range(3):
            if self.retry_after > time.monotonic():
                self.record_error("限流冷却")
                raise RuntimeError("行情接口处于限流冷却期")
            try:
                async with self.limit:
                    if self.retry_after > time.monotonic():
                        self.record_error("限流冷却")
                        raise RuntimeError("行情接口处于限流冷却期")
                    if self.session is None or self.session.closed:
                        self.session = aiohttp.ClientSession(
                            connector=aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver()),
                            timeout=aiohttp.ClientTimeout(total=8))
                    async with self.session.get("https://fapi.binance.com" + path, params=params, headers=_headers or None,
                                                proxy=config.proxy_url if config.use_proxy else None) as resp:
                        if resp.status in (418, 429):
                            delay = max(5, min(float(resp.headers.get("Retry-After", 60)), 86400))
                            self.retry_after = time.monotonic() + delay
                            self.rate_limited_until = time.time() + delay
                            self.record_error(f"HTTP {resp.status}")
                            raise RuntimeError("行情接口限流，暂停请求")
                        resp.raise_for_status()
                        result = await resp.json()
                        if isinstance(result, dict) and "code" in result and result["code"] != 0:
                            self.record_error("行情接口业务错误")
                            raise ValueError("行情接口返回业务错误")
                        self.last_success_at = time.time()
                        self.last_error = ""
                        return result
            except (aiohttp.ClientError, asyncio.TimeoutError):
                if attempt == 2:
                    self.record_error("网络请求失败")
                    raise RuntimeError("行情请求失败") from None
                await asyncio.sleep(0.5 * (2 ** attempt))

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()

market_client = MarketClient()
