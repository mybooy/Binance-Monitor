"""Independent chronological V5.2 research snapshot; run: python export_v52_research.py.
Only completed forward observations are considered. Export never modifies monitor DBs.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import random
import sqlite3
import statistics
from collections import defaultdict
from pathlib import Path

from config import ROOT


def wilson(k,n):
    if not n:return None
    z=1.95996398454;p=k/n;d=1+z*z/n
    m=(p+z*z/(2*n))/d
    h=z*((p*(1-p)/n+z*z/(4*n*n))**.5)/d
    return [round(m-h,4),round(m+h,4)]


def cluster_bootstrap(group,seed=52,iterations=500):
    # Same 15m market episode gets resampled together; not independent signal bootstrap.
    episode=defaultdict(list)
    for x in group:episode[int(x['first_at']//900)].append(x['return_240m'])
    blocks=list(episode.values())
    if len(blocks)<8:return None
    rng=random.Random(seed)
    estimates=[]
    for i in range(iterations):
        sampled=[v for _ in blocks for v in rng.choice(blocks)]
        estimates.append(statistics.median(sampled))
    estimates.sort()
    return [round(estimates[int(.025*iterations)],4), round(estimates[int(.975*iterations)],4)]


def summarise(rows,group_keys):
    groups=defaultdict(list)
    for row in rows:
        if row['return_240m'] is None:continue
        groups[tuple(row[k] for k in group_keys)].append(row)
    result=[]
    for key,items in sorted(groups.items()):
        xs=[float(x['return_240m']) for x in items]
        n=len(xs);pos=sum(x>0 for x in xs)
        episodes=len({int(x['first_at']//900) for x in items})
        result.append({**dict(zip(group_keys,key)),'n':n,'market_episodes_15m':episodes,
          'positive_240m':round(pos/n,4),'wilson_95':json.dumps(wilson(pos,n)),
          'median_240m_pct':round(statistics.median(xs),4),'mean_240m_pct':round(statistics.mean(xs),4),
          'cluster_bootstrap_95':json.dumps(cluster_bootstrap(items))})
    return result


def main():
    radar_db=ROOT/'radar_v52.db'
    model_db=ROOT/'research_archive.db'
    now=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S')
    out=ROOT/'research_exports'/now
    out.mkdir(parents=True,exist_ok=True)
    radar=[];model_count=0
    if radar_db.exists():
        with sqlite3.connect(f'file:{radar_db.as_posix()}?mode=ro',uri=True) as db:
            db.row_factory=sqlite3.Row
            radar=[dict(x) for x in db.execute("SELECT * FROM radar_events WHERE completed_at IS NOT NULL AND return_240m IS NOT NULL")]
    if model_db.exists():
        with sqlite3.connect(f'file:{model_db.as_posix()}?mode=ro',uri=True) as db:
            try:
                model_count=db.execute("SELECT count(*) FROM model_a_research ").fetchone()[0]
            except sqlite3.OperationalError: pass
    # Chronological holdout by entire 15m episodes, never random individual signals.
    episodes=sorted({int(x['first_at']//900) for x in radar})
    cut=episodes[int(len(episodes)*.7)] if len(episodes)>1 else None
    for x in radar:
        x['split']='HOLDOUT' if cut is not None and int(x['first_at']//900)>=cut else 'DEVELOPMENT'
    summary=summarise(radar,['event_type','direction','split'])
    columns=['event_type','direction','split','n','market_episodes_15m','positive_240m','wilson_95',
             'median_240m_pct','mean_240m_pct','cluster_bootstrap_95']
    with (out/'radar_group_stats.csv').open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.DictWriter(f,fieldnames=columns);wr.writeheader();wr.writerows(summary)
    if radar:
        with (out/'radar_completed_events.csv').open('w',newline='',encoding='utf-8-sig') as f:
            wr=csv.DictWriter(f,fieldnames=list(radar[0]));wr.writeheader();wr.writerows(radar)
    lines=['# V5.3 融合版 Radar R1 事件级前向研究报告', '',f'- 完成且有240m结果的雷达事件：{len(radar)}',
           f'- Model A 全版本研究库信号（各版本禁止混合估计收益）：{model_count}',
           f'- 独立15分钟市场事件：{len(episodes)}',
           '- 研究切分：按触发时间排序的15分钟市场事件，前70%为开发区，后30%为留出区。',
           '- 重要限制：留出区被事后查看，不等于实时独立前向验证。',
           '- Radar PRICE路径是定期 REST 快照：240m为首次越过指定时长后的样本，不是严格分钟收盘。',
           '- 无完整清算、真实订单薄/资金费扣除，绝不可视为可交易的真实净收益。',
           '- 5%无预警对照样本尚未具备完整标签，无法可信计算召回率。',
           '- 15分钟同事件聚类Bootstrap不足8个独立时段不生成CI。', '',
           '| 分类 | 方向 | 切分 | N | 独立时段 | 240m中位% | 正收益率 | Wilson 95% | 聚类Bootstrap 95% |',
           '|---|---|---|---:|---:|---:|---:|---|---|']
    for r in summary:
        lines.append(f"| {r['event_type']} | {r['direction']} | {r['split']} | {r['n']} | {r['market_episodes_15m']} | {r['median_240m_pct']:+.3f} | {r['positive_240m']:.1%} | {r['wilson_95']} | {r['cluster_bootstrap_95']} |")
    (out/'前向复盘报告.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(out),'radar_events':len(radar),'model_a_all_versions':model_count,'independent_episodes':len(episodes)},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
