**融合版 V5.3.0：请首先阅读 `FUSION_V5.3.0.md` 和 `VERSION_COMPARISON.md`。以下为 V4.9.0 基础功能说明。**

# Binance USDT 永续异常机会监测 V4.9.0

当前运行版本为 **模型 A + 模型 B**。模型 A 的量比基准已改为“前 20 个完整周期去掉一个最高值，余下 19 个取均值”；模型 B 固定监控 BTC/ETH，其他标的按异动发现、关联核验、分级预警运行。

启动仍使用 `start_monitor.bat`。新规则、数据质量要求、数据库兼容和离线测试见 [V4.9.0 升级说明](UPGRADE_V4.9.0.md)。以下 V4.8.0 章节为历史说明，与升级说明冲突时以 V4.9.0 为准。

## Market Breadth & Model A Research Core

V4.8.0 把系统正式收敛为 **Model A 单模型研究平台**：发现实际异常成交量 → 冻结触发时市场环境与标的趋势 → A+/A++ 质量分层 → 跟踪最多 240 分钟收益路径 → 自动压缩成熟样本到轻量研究归档。

本版本的重点不是增加入场过滤器，而是为下一轮前向复盘回答两个问题：

1. **什么样的市场环境下，Model A 预警收益更好？**
2. **标的处于什么趋势阶段时，Model A 预警收益更好？**

Breadth、1H/4H 布林中轨位置都只作为研究变量，暂不改变 Model A 触发规则。

---

## 1. 核心规则保持不变

### Model A

- Binance USDT 本位永续合约。
- 当前 15 分钟窗口**实际累计 Base Volume** ÷ 过去 N 根完整 15m Base Volume 平均值。
- 默认 VR：`3.0`。
- 默认历史基准：20 根完整 15m。
- 从当前 15m 的第 5 分钟开始扫描，到第 15 分钟。
- 不预测未来成交量，不外推最终 15m 成交量。
- 方向由实际价格运动决定。

### Fixed A+

保持正式规则：

- ATR% ≥ `0.85%`
- P1 ≥ `+0.11%`

A+ 确认后的真实 Execution 使用 **P1 完成时的确认价格**，不能使用 T0 原始预警价冒充真实可执行入场价。

### A++

继续只作为持仓质量升级：

- `A++ Trend`：Fixed A+ 且 `P3 > P1`
- `A++ Persistence`：Fixed A+ 且 `0 < P1 < P3 < P5`

A++ 不是新的追单信号。

### 4小时生命周期

每条 Model A 最长研究 240 分钟：

- 0–60m：每 1 分钟保存
- 65–240m：每 5 分钟保存
- 完整路径最多 97 个点

市场环境只在信号触发时冻结一次；不会把信号发生后的市场环境重复写入该信号。

---

## 2. V4.8.0 新增：全市场永续 Breadth

Market Breadth 使用全部公开、正在交易的 Binance USDT 永续合约，而不是只看 Model A 的高流动性交易池。

### Session 起点

每天：

- UTC `00:00`
- 北京 / 新加坡时间 `08:00`

从当天 08:00 的开盘价开始计算全市场横截面涨跌。

### 核心字段

- `session_up_pct`
- `session_down_pct`
- `session_flat_pct`
- `breadth_score = 上涨比例 - 下跌比例`，映射到 -100～+100
- `median_session_return_pct`
- `pct_up_1 / pct_up_3`
- `pct_down_1 / pct_down_3`
- `breadth_score_delta_15m`
- `breadth_score_delta_30m`
- 全市场覆盖率与样本数
- 高流动性 Top-N 的独立 Breadth

因此，如果北京时间 08:00 以来约 80% 的交易对都在下跌，Breadth 会直接表现为广泛强偏空，不会因为 BTC/ETH 横盘而把整个市场简单理解成中性。

Breadth 取数失败只降级为 `UNKNOWN`，不会阻塞 Model A。

---

## 3. V4.8.0 新增：1H / 4H 布林中轨趋势研究

这里的“布林”只使用标准中轨：

`Bollinger Middle = SMA20`

**不加入：**

- 上轨
- 下轨
- 带宽
- %B
- squeeze
- 上下轨突破逻辑

研究目标只有一个：

> Model A 触发时，价格位于 1H / 4H SMA20 中轨上方还是下方？这种趋势背景对后续收益有没有增益？

### 严格无未来泄漏

信号触发时只使用**已经完成**的 20 根 1H / 4H K线。

例如信号发生在 10:37：

- 1H 中轨不能使用 10:00–11:00 尚未完成的K线；
- 4H 中轨也不能使用信号时仍未收盘的4H K线。

### 四种组合

- `ABOVE_ABOVE`：1H上 + 4H上
- `ABOVE_BELOW`：1H上 + 4H下
- `BELOW_ABOVE`：1H下 + 4H上
- `BELOW_BELOW`：1H下 + 4H下

另外保存相对信号方向的：

- `ALIGNED`：双周期顺势
- `OPPOSED`：双周期逆势
- `MIXED`：两个周期不一致

后续复盘会进一步结合 Trigger Extension 判断“顺势但未过度延伸”与“顺势但已经高延伸”。

---

## 4. 初始市场环境冻结字段

每个 Model A 只冻结一条 `signal_market_context`，包含：

- BTC/ETH Direction Score / Stress Score
- BTC/ETH 原始上下文
- 全市场 Breadth
- 高流动性 Breadth
- Breadth 最近 15m / 30m 变化
- 1H SMA20 中轨及位置
- 4H SMA20 中轨及位置
- 趋势组合 / 趋势一致性
- 各研究引擎版本

信号后 4 小时只记录收益路径，不更新这份初始环境。

---

## 5. 长期研究归档：不再依赖超大旧运行库

V4.8.0 新增独立：

`research_archive.db`

每条完成 240 分钟生命周期的 Model A，会被压缩成**一条信号一行**，长期保存：

- Signal / A+ / A++
- VR / ATR / ATR Percentile / Extension / CLV
- 初始 BTC/ETH 环境
- Breadth
- 1H / 4H 中轨趋势
- 1～240m Return / MFE / MAE
- First Passage
- Time-to-MFE
- Giveback

运行数据库中的高体量明细默认只保留：

- `signal_path_points`：7 天
- `volume_observations`：72 小时

成熟样本先归档，再清理明细。

### 保存每次复盘结果

前端点击：

**生成不可变分析快照**

或者运行：

```bat
export_analysis_snapshot.bat
```

系统会在：

`analysis_reports/YYYYMMDD_HHMMSS/`

保存：

- `factor_summary.csv`
- `market_trend_matrix.csv`
- `trend_extension_matrix.csv`
- `manifest.json`
- `report.md`

因此下一次复盘不必继续保留几百 MB 的旧 `monitor_v4.db`。

---

## 6. 推荐的 V4.7.1 → V4.8.0 数据迁移方式

### 推荐方案：新运行库 + 旧研究归档

这是控制数据库体积最干净的方案。

1. 新建 V4.8.0 文件夹。
2. 复制旧 `.env`。
3. 如果旧 `config.json` 有自定义参数，可复制；V4.8 会自动忽略已经删除的旧字段。
4. **不要复制旧 `monitor_v4.db`。** V4.8 会创建新的轻量运行库。
5. 如需保留 V4.7.1 历史研究结果，把之前保存的 `V4.7.1_research_archive_20261007.db` 放到 V4.8 目录，然后运行：

```bat
venv\Scripts\python.exe import_v471_research_archive.py V4.7.1_research_archive_20261007.db
```

这样旧的 500MB 运行库就不再是长期研究依赖。

### 兼容方案：直接复制旧 monitor_v4.db

V4.8 也支持直接迁移旧运行库：

- Model A 数据保留；
- 已废弃模型的专属运行表与共享记录会被迁移清理；
- 新 Breadth / Trend 字段自动创建。

但如果目标是控制数据库体积，更推荐上面的“新运行库 + 研究归档”。

---

## 7. 启动

Windows：

1. 解压整个 V4.8.0 目录。
2. 配置 `.env`。
3. 双击 `start_monitor.bat`。
4. 浏览器打开：`http://127.0.0.1:8000`

不要复制：

- 旧 `venv`
- `monitor_v4.db-wal`
- `monitor_v4.db-shm`

---

## 8. 下一次复盘固定回答的问题

V4.8.0 的数据结构就是为下一次复盘服务。复盘将固定输出：

1. **最佳市场环境**：Breadth、Direction、Stress、Market Spike 的组合；
2. **最佳标的趋势阶段**：1H/4H中轨组合 × Trigger Extension；
3. LONG / SHORT 完全分开；
4. First +1/+2/+3、MFE、MAE、60/120/240m、Time-to-MFE、Giveback；
5. 每个结论附样本数，并明确区分“发现”与“可前向确认”。

V4.8.0 不会根据当前几天的数据自动修改交易规则。
