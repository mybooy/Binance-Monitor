// Offline DOM smoke test: no browser network or server startup.
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const html = fs.readFileSync(require('path').join(__dirname, '../web_ui/index.html'), 'utf8');
const source = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].map(x=>x[1]).join('\n');
const nodes = new Map();
const node = id => {
  if (!nodes.has(id)) nodes.set(id, {innerHTML:'',textContent:'',style:{},classList:{add(){},remove(){},toggle(){}},querySelectorAll(){return []}});
  return nodes.get(id);
};
const now = Date.now()/1000;
const fixture = {symbol:'BTCUSDT',is_benchmark:true,direction:'UNKNOWN',score:0,level:0,
  level_cn:'常态',sector:'L1_L2',data_quality:'INCOMPLETE',oi_percentile:null,oi_zscore:null,
  vr_1h:null,funding_apr:null,basis_pct:null,fs_ratio:null,clv:null,liq_total_5m:0,
  trigger_reasons:['MARKET_BENCHMARK'],oi_history_samples:0,sampled_at:now};
const context=vm.createContext({console,Date,Math,Number,Object,Array,JSON,Error,Promise,
  document:{getElementById:node,querySelectorAll(){return []}},setInterval(){},alert(){},confirm(){return false},
  fetch:async url=>({ok:true,json:async()=> url==='/api/state' ? {model_a:[],market_state:{},market_breadth:{}} :
    url==='/api/crowding/top' ? {updated_at:now,items:[fixture],benchmarks:[fixture],health:{universe:2}} :
    url.includes('/alerts') ? [] : {}})});
vm.runInContext(source,context);
setImmediate(()=>{
  assert(node('crowd-full-body').innerHTML.includes('方向未确认'));
  assert(node('crowd-full-body').innerHTML.includes('核验未完成'));
  assert(!node('crowd-full-body').innerHTML.includes('nullx'));
  assert(!node('crowd-full-body').innerHTML.includes('NaN'));
  assert(node('model-b-benchmarks').innerHTML.includes('BTCUSDT'));
  assert(node('model-a-full-body').innerHTML.includes('暂无放量突破信号'));
  vm.runInContext("cachedCrowd=[{symbol:'STALEUSDT',level:4,score:90,stale:true,trigger_reasons:[],data_quality:'OK'}]; renderCrowdTables();",context);
  assert(!node('master-crowd-body').innerHTML.includes('STALEUSDT'));
  console.log('Frontend smoke test passed: unknown, missing, stale, benchmark and empty-history states.');
});
