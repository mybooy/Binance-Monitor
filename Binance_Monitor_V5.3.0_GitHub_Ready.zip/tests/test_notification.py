import main


def test_model_a_message_contains_breadth_and_trend_context():
    e={
        'symbol':'DOTUSDT','direction':'LONG','bar_15m_open_at':1000.0,'observation_at':1600.0,
        'elapsed_minutes':10,'vr_live_actual':3.1,'return_live_pct':1.2,'atr_percentile_200':41,
        'trigger_move_atr_ratio':1.7,'market_spike_risk':'NORMAL','directional_close_location':.93,
        'quote_volume_24h':64_100_000,'price':1.1867,
        'market_state':{'status':'NEUTRAL'},
        'market_breadth':{'status':'BROAD_BEAR','session_up_pct':.18,'session_down_pct':.80,'median_session_return_pct':-1.2},
        'trend_context':{'bb_1h_position':'ABOVE','bb_4h_position':'BELOW'},
    }
    title,body=main._telegram_model_a(e)
    assert '模型A' in title
    assert '全市场广度' in body and '下跌80%' in body
    assert '1小时中轨上' in body and '4小时中轨下' in body
    assert '模型B' not in body
