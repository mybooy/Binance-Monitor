import asyncio, sqlite3
import database


def test_v49_schema_preserves_legacy_model_b_and_adds_separate_radar_tables(tmp_path):
    old=database.DB_PATH; database.DB_PATH=tmp_path/'m.db'
    try:
        asyncio.run(database.init_db())
        db=sqlite3.connect(database.DB_PATH)
        # Simulate obsolete V4.7 Model-B runtime artifacts.
        db.execute('create table alerts(id integer primary key, model text)')
        db.execute('create table market_episodes(id integer primary key)')
        db.execute('create table model_events(id integer primary key, model text)')
        db.execute("insert into alerts(model) values('MODEL_B')")
        db.execute("insert into model_events(model) values('MODEL_B')")
        db.execute("insert into signal_lifecycle(source_type,source_id,symbol,direction,trigger_at,trigger_price) values('MODEL_B',99,'XUSDT','LONG',1,1)")
        db.commit(); db.close()
        asyncio.run(database.init_db())
        db=sqlite3.connect(database.DB_PATH)
        tables={r[0] for r in db.execute("select name from sqlite_master where type='table'")}
        assert {'alerts','market_episodes','model_events','model_b_alerts','model_b_snapshots','model_b_state'} <= tables
        assert db.execute("select count(*) from signal_lifecycle where source_type='MODEL_B'").fetchone()[0]==1
        assert {'signal_market_context','signal_path_points','signal_execution_results'} <= tables
        assert db.execute('pragma integrity_check').fetchone()[0]=='ok'
        db.close()
    finally:
        database.DB_PATH=old
