import asyncio
import sqlite3
from dataclasses import asdict

from multi_exchange import Quote,ThreeExchangeClient,Instrument,number
from radar_storage import RadarStorage,connect
from radar_v52 import RadarEngine,fresh
from research_archive import _research_identity

T=1_700_000_000.


def q(ex,market,price,t,oi=None, funding=None):
    return Quote(exchange=ex,symbol='BTCUSDT' if ex!='okx' else ('BTC-USDT-SWAP' if market=='PERP' else 'BTC-USDT'),
        asset='BTC',market=market,price=price,event_time_ms=None,received_at=t,
        volume_24h_quote=2e9,oi_native=oi,oi_base=oi,oi_usd=oi*price if oi is not None else None,
        funding_rate=funding,funding_interval_hours=8 if funding is not None else None,
        funding_kind='ESTIMATED')


def batch(t,p1=100,p2=100,p3=100,oi=1000):
    return [q('binance','PERP',p1,t,oi),q('okx','PERP',p2,t,oi),q('bybit','PERP',p3,t,oi),
            q('binance','SPOT',p1*.999,t),q('okx','SPOT',p2*.999,t),q('bybit','SPOT',p3*.999,t)]


def test_missing_not_zero_and_stale():
    assert number('') is None
    assert number('NaN') is None
    assert not fresh(q('binance','PERP',100,T),T+250)
    assert fresh(q('binance','PERP',100,T),T+30)


def test_three_exchange_union_and_symbol_mapping():
    c=ThreeExchangeClient()
    c._add('okx','PERP','ONLY-USDT-SWAP','ONLY')
    c._add('bybit','PERP','BTCUSDT','BTC')
    c._add('binance','SPOT','BTCUSDT','BTC')
    assert c.coverage()['union_assets']==2
    assert c.coverage()['okx']['perp']==1
    assert c.coverage()['bybit']['perp']==1


def test_cross_resonance_and_event_study_4h(tmp_path):
    async def case():
        store=RadarStorage(tmp_path/'radar.db')
        await store.start()
        r=RadarEngine(storage=store)
        await r.step(batch(T),now=T,do_enrich=False)
        assert not r.latest_events
        await r.step(batch(T+75,101.3,101.1,101.2,oi=1030),now=T+75,do_enrich=False)
        names={e['event_type'] for e in r.latest_events}
        assert 'CROSS_RESONANCE' in names and 'LEVERAGE_BUILD' in names
        events=await store.recent()
        assert any(e['event_type']=='CROSS_RESONANCE' for e in events)
        prior=len(events)
        await r.step(batch(T+150,101.4,101.2,101.3,oi=1033),now=T+150,do_enrich=False)
        assert len(await store.recent())==prior  # same episode, no duplicate
        # Cross 240m boundary in a valid observation; first after horizon is a measured sample.
        await r.step(batch(T+75+240*60,102,102,102,oi=1100),now=T+75+240*60,do_enrich=False)
        study=await store.study()
        assert study['completed_events']>=1
        assert sum(group['mature'] for group in study['groups'])>=1
        await r.close()
    asyncio.run(case())


def test_local_anomaly_without_multi_confirmation(tmp_path):
    async def case():
        st=RadarStorage(tmp_path/'radar.db');await st.start()
        r=RadarEngine(storage=st)
        await r.step(batch(T),now=T,do_enrich=False)
        await r.step(batch(T+75,101.5,100.1,100.1,oi=1030),now=T+75,do_enrich=False)
        assert 'LOCAL_DISLOCATION' in {e['event_type'] for e in r.latest_events}
        assert 'CROSS_RESONANCE' not in {e['event_type'] for e in r.latest_events}
        await r.close()
    asyncio.run(case())


def test_recover_state_after_restart(tmp_path):
    async def case():
        path=tmp_path/'radar.db'
        store=RadarStorage(path);await store.start()
        r=RadarEngine(storage=store)
        await r.step(batch(T),now=T,do_enrich=False)
        await r.step(batch(T+75,101,101,101,oi=1030),now=T+75,do_enrich=False)
        before=len(r.active)
        await r.close()
        restarted=RadarEngine(storage=RadarStorage(path))
        await restarted.storage.start()
        # restore selects only last 5h relative to clock; build example close to now in separate case.
        with connect(path) as db:
            db.execute('UPDATE radar_events SET first_at=?,last_at=?',( __import__('time').time()-600,__import__('time').time()-300))
        await restarted.restore()
        assert len(restarted.active)==before
        await restarted.close()
    asyncio.run(case())


def test_archive_source_id_collision_no_longer_defines_identity():
    a=_research_identity('4.8.0','BTCUSDT',1800000000.0,100,'LONG')
    b=_research_identity('4.8.0','ETHUSDT',1800000000.0,100,'LONG')
    c=_research_identity('4.8.0','BTCUSDT',1800000000.0,100,'LONG')
    assert a != b and a == c
