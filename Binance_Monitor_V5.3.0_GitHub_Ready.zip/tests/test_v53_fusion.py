import asyncio
import sqlite3
import time
from unittest.mock import patch
import database
import main
import radar_storage
from radar_storage import RadarStorage
from reliability_v52 import recompute_spike_counts


def test_venues_and_binance_model_b_have_distinct_routes():
    paths={r.path for r in main.app.routes}
    assert {'/api/radar/events','/api/radar/study','/api/crowding/top','/api/crowding/alerts'}<=paths
    assert database.ENGINE_VERSION=='4.9.0'
    from radar_v52 import ENGINE_VERSION
    assert ENGINE_VERSION=='RADAR_R1_5.2.0'


def test_writer_keeps_failed_batch_and_recovers(tmp_path):
    async def case():
        st=RadarStorage(tmp_path/'events.db')
        await st.start()
        t=time.time()
        row=dict(event_id='id1',asset='BTC',event_type='LEVERAGE_BUILD',exchange='binance',status='CONFIRMED',
            first_at=t,last_at=t,exchange_event_ms=int(t*1000),receive_at=t,decision_at=t,
            reference_price=100,reference_exchange='binance',direction='LONG',risk=55,
            confidence='MEDIUM',quality='OK',evidence_json='{}',coverage_json='{}',notification_status='SHADOW')
        with patch.object(radar_storage,'apply_batch',side_effect=sqlite3.OperationalError('disk full')):
            await st.write('event',row)
            for _ in range(100):
                if st.task.done():break
                await asyncio.sleep(.1)
            assert st.task.done() and len(st._failed_batch)==1
            try: await st.flush()
            except RuntimeError: pass
            else: assert False,'flush must fail on lost persistence'
        await st.start()
        await st.flush()
        assert st.health()['failed_batch']==0
        assert (await st.recent())[0]['event_id']=='id1'
        await st.close()
    asyncio.run(case())


def test_spike_count_reconcile_minute_and_version(tmp_path):
    async def case():
        await database.init_db()
        with database._connect() as db:
            now=time.time();minute=int(now//60)*60
            for ix,v in enumerate(('4.9.0','4.9.0','4.8.0')):
                db.execute('''INSERT INTO volume_alerts(created_at,symbol,direction,observation_at,trigger_price,window_open,
                    volume_state,vr10_now,vr10_projected,prev_vr10_projected,atr_pct,quote_volume_24h,payload,
                    source_signal_engine_version,signal_engine_version)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(minute,f'COIN{ix}USDT','LONG',minute+ix*.13,1,minute-60,
                    'ACTIVE',3.1,3.1,3.0,.8,10000000,'{}',v,v))
        assert recompute_spike_counts()>=2
        with database._connect() as db:
            v49=[r[0] for r in db.execute("SELECT market_spike_count_1m FROM volume_alerts WHERE source_signal_engine_version='4.9.0'")]
            v48=[r[0] for r in db.execute("SELECT market_spike_count_1m FROM volume_alerts WHERE source_signal_engine_version='4.8.0'")]
        assert v49==[2,2] and v48==[1]
    asyncio.run(case())

def test_v52_source_uuid_archive_migrates_without_data_loss(tmp_path):
    from research_archive import _connect
    p=tmp_path/'archive-v52.db'
    with sqlite3.connect(p) as db:
        db.execute('''CREATE TABLE model_a_research(source_uuid TEXT PRIMARY KEY,source_version TEXT NOT NULL,
           source_id INTEGER NOT NULL,symbol TEXT NOT NULL,direction TEXT NOT NULL,signal_at REAL NOT NULL,
           trigger_price REAL NOT NULL,archived_at REAL NOT NULL)''')
        db.executemany('INSERT INTO model_a_research VALUES(?,?,?,?,?,?,?,?)',[
            ('uuid1','4.8.0',1,'BTCUSDT','LONG',1800000000.,100.,1800000100.),
            ('uuid2','4.8.0',1,'ETHUSDT','SHORT',1800000001.,200.,1800000101.)])
    for _ in range(2):
        with _connect(p) as db:
            assert db.execute('SELECT COUNT(*) FROM model_a_research').fetchone()[0]==2
            assert db.execute('SELECT COUNT(*) FROM model_a_research_v52_backup').fetchone()[0]==2
            assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
