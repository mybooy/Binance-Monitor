import asyncio, sqlite3, time
from pathlib import Path

import database
import research_archive
from market_breadth import MarketBreadthEngine, _session_start_utc
from trend_context import TrendContextEngine


def test_session_start_is_utc_midnight():
    # 2026-10-07 10:23 UTC -> 2026-10-07 00:00 UTC, Beijing 08:00.
    ts=1791368580.0
    start=_session_start_utc(ts)
    assert start % 86400 == 0
    assert 0 <= ts-start < 86400


def test_breadth_80_percent_down_is_not_neutral(monkeypatch):
    e=MarketBreadthEngine()
    e._running=True
    e._symbols=frozenset(f'S{i}USDT' for i in range(10))
    e._session_start=_session_start_utc()
    e._session_open={s:100.0 for s in e._symbols}
    e._quote_volume_24h={s:1_000_000 for s in e._symbols}
    quotes={}
    for i,s in enumerate(sorted(e._symbols)):
        quotes[s]={'price':98.0 if i<8 else 101.0,'timestamp':time.time()}
    out=asyncio.run(e.sample(quotes))
    assert out['session_down_pct'] == .8
    assert out['status']=='BROAD_STRONG_BEAR'
    assert out['breadth_score'] < -50


def test_trend_position_and_alignment_are_directional():
    e=TrendContextEngine()
    p,d=e._position(110,100)
    assert p=='ABOVE' and d>0
    trend={'bb_1h_position':'ABOVE','bb_4h_position':'ABOVE'}
    assert e.alignment('LONG',trend)=='ALIGNED'
    assert e.alignment('SHORT',trend)=='OPPOSED'


def _event():
    return {'symbol':'CTXUSDT','direction':'LONG','direction_basis':'LIVE_PRICE','volume_state':'FIRST_BREAKOUT',
      'bar_15m_open_at':900.0,'observation_at':1500.0,'elapsed_minutes':10,'price':1.0,
      'vr_live_actual':3.4,'prev_live_vr':2.9,'delta_vr_live':0.5,'atr_14_5m_pct':1.2,
      'quote_volume_24h':20_000_000,'base_volume_live':340,'baseline_base_volume_15m':100,
      'return_live_pct':1.0,'atr_14_5m':0.01,'vpe_atr':0.4,'vpe_raw':0.2,'close_location':.9,
      'market_state':{'status':'NEUTRAL','direction_score':3,'stress_score':10,'updated_at':1495,'engine_version':'4.8.0','assets':{}},
      'market_breadth':{'status':'BROAD_BEAR','breadth_score':-62,'session_up_pct':.15,'session_down_pct':.80,
        'session_flat_pct':.05,'median_session_return_pct':-1.4,'pct_up_1':.1,'pct_up_3':0,'pct_down_1':.6,
        'pct_down_3':.2,'coverage':.95,'sample_size':100,'eligible_symbol_count':105,'updated_at':1498,
        'engine_version':'4.8.0','liquid':{'breadth_score':-50,'session_up_pct':.2,'session_down_pct':.7,'median_session_return_pct':-1.0}},
      'trend_context':{'bb_1h_mid':.98,'bb_1h_position':'ABOVE','bb_1h_distance_pct':2.04,'bb_1h_last_closed_at':1000,
        'bb_4h_mid':1.05,'bb_4h_position':'BELOW','bb_4h_distance_pct':-4.76,'bb_4h_last_closed_at':900,
        'bb_trend_context':'ABOVE_BELOW','trend_alignment':'MIXED','data_quality':'OK','engine_version':'4.8.0'}}


def test_trigger_context_freezes_breadth_and_midline(tmp_path):
    old=database.DB_PATH; database.DB_PATH=tmp_path/'x.db'
    try:
        asyncio.run(database.init_db())
        _,aid=asyncio.run(database.start_volume_episode(_event()))
        db=sqlite3.connect(database.DB_PATH); db.row_factory=sqlite3.Row
        r=db.execute('select * from signal_market_context where source_id=?',(aid,)).fetchone()
        assert r['breadth_status']=='BROAD_BEAR' and abs(r['session_down_pct']-.8)<1e-9
        assert r['bb_1h_position']=='ABOVE' and r['bb_4h_position']=='BELOW'
        assert r['trend_alignment']=='MIXED'
        db.close()
    finally:
        database.DB_PATH=old


def test_compact_archive_is_one_row_per_mature_model_a(tmp_path):
    old_db=database.DB_PATH; old_archive=research_archive.ARCHIVE_PATH
    database.DB_PATH=tmp_path/'runtime.db'; research_archive.ARCHIVE_PATH=tmp_path/'research_archive.db'
    try:
        asyncio.run(database.init_db())
        _,aid=asyncio.run(database.start_volume_episode(_event()))
        db=sqlite3.connect(database.DB_PATH)
        db.execute("update signal_lifecycle set completed=1,completed_at=?,return_240m=1.2,mfe_240m=2.3,mae_240m=-.8 where source_id=?",(time.time(),aid))
        db.execute("update volume_alerts set tracking_ended=1,tracking_status='complete',final_return_pct=1.2,mfe_pct=2.3,mae_pct=-.8 where id=?",(aid,))
        db.commit(); db.row_factory=sqlite3.Row
        assert research_archive.archive_completed_signal(db,aid) is True
        db.close()
        arc=sqlite3.connect(research_archive.ARCHIVE_PATH)
        assert arc.execute('select count(*) from model_a_research').fetchone()[0]==1
        assert arc.execute('pragma integrity_check').fetchone()[0]=='ok'
        arc.close()
    finally:
        database.DB_PATH=old_db; research_archive.ARCHIVE_PATH=old_archive


def test_bb_middle_excludes_forming_or_future_bar():
    signal_at=10_000.0
    raw=[]
    # 20 completed bars all close at 100.
    for i in range(20):
        close_at=signal_at-20+i
        raw.append([0,0,0,0,100,0,int(close_at*1000)])
    # A giant current/future close must not change the historical middle.
    raw.append([0,0,0,0,1000,0,int(signal_at*1000)])
    mid,last=TrendContextEngine._middle_from_rows(raw,signal_at)
    assert mid==100.0
    assert last < signal_at
