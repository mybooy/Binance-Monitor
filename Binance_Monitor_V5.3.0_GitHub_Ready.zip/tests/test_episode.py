import asyncio, sqlite3
import database


def event(elapsed=10):
    return {'symbol':'CAPUSDT','direction':'LONG','direction_basis':'LIVE_PRICE','volume_state':'FIRST_BREAKOUT',
      'bar_15m_open_at':900.0,'observation_at':900.0+elapsed*60,'elapsed_minutes':elapsed,'price':1.0,
      'vr_live_actual':3.4,'prev_live_vr':2.9,'delta_vr_live':0.5,
      'atr_14_5m_pct':1.2,'quote_volume_24h':20_000_000,'base_volume_live':340,'baseline_base_volume_15m':100,
      'return_live_pct':1.0,'atr_14_5m':0.01,'vpe_atr':0.4,'vpe_raw':0.2,'close_location':.9}


def test_one_active_episode_per_symbol(tmp_path):
    old=database.DB_PATH; database.DB_PATH=tmp_path/'x.db'
    try:
        asyncio.run(database.init_db()); ep,alert=asyncio.run(database.start_volume_episode(event()))
        ep2,alert2=asyncio.run(database.start_volume_episode({**event(),'observation_at':1600.0,'vr_live_actual':5.0}))
        assert ep2==ep and alert2 is None
    finally: database.DB_PATH=old


def test_minute15_trigger_is_confirmed_immediately(tmp_path):
    old=database.DB_PATH; database.DB_PATH=tmp_path/'x.db'
    try:
        asyncio.run(database.init_db()); asyncio.run(database.start_volume_episode(event(15)))
        db=sqlite3.connect(database.DB_PATH); row=db.execute('select confirmation_status,final_actual_vr15 from volume_alerts').fetchone(); db.close()
        assert row[0]=='CONFIRMED' and abs(row[1]-3.4)<1e-9
    finally: database.DB_PATH=old


def test_persistence_update(tmp_path):
    old=database.DB_PATH; database.DB_PATH=tmp_path/'x.db'
    try:
        asyncio.run(database.init_db()); _,alert=asyncio.run(database.start_volume_episode(event()))
        asyncio.run(database.update_persistence(alert,1,1.25)); asyncio.run(database.update_persistence(alert,5,2.5))
        asyncio.run(database.update_close_persistence(alert,'CURRENT',1.8))
        db=sqlite3.connect(database.DB_PATH); v=db.execute('select persistence_1m_pct,persistence_5m_pct,persistence_15m_close_pct from volume_alerts').fetchone(); db.close()
        assert abs(v[0]-1.25)<1e-9 and abs(v[1]-2.5)<1e-9 and abs(v[2]-1.8)<1e-9
    finally: database.DB_PATH=old

def test_high_quality_confirmation_is_atomic_and_once(tmp_path):
    old=database.DB_PATH; database.DB_PATH=tmp_path/'hq.db'
    try:
        asyncio.run(database.init_db()); _,alert=asyncio.run(database.start_volume_episode(event()))
        ok1=asyncio.run(database.confirm_high_quality_and_enqueue(alert,'🔴 <b>A+</b>','body'))
        ok2=asyncio.run(database.confirm_high_quality_and_enqueue(alert,'🔴 <b>A+</b>','body'))
        assert ok1 is True and ok2 is False
        db=sqlite3.connect(database.DB_PATH)
        row=db.execute('select high_quality_confirmed from volume_alerts where id=?',(alert,)).fetchone()
        n=db.execute('select count(*) from notification_outbox').fetchone()[0]
        db.close()
        assert row[0]==1 and n==1
    finally: database.DB_PATH=old

def test_dynamic_quantile_and_market_spike_fields(tmp_path):
    old=database.DB_PATH; database.DB_PATH=tmp_path/'q.db'
    try:
        asyncio.run(database.init_db())
        ids=[]
        for i in range(105):
            e={**event(), 'symbol':f'Q{i}USDT', 'bar_15m_open_at':900.0+i*900, 'observation_at':1500.0+i*900,
               'atr_14_5m_pct':0.5+i/1000}
            _,aid=asyncio.run(database.start_volume_episode(e)); ids.append(aid)
            asyncio.run(database.update_persistence(aid,1,0.05+i/10000))
            asyncio.run(database.close_volume_episode(i+1,'test'))
        q=asyncio.run(database.rolling_a_plus_thresholds(ids[-1],100,50,.75))
        assert q and q['n']>=50 and q['atr']>0.5 and q['p1']>0.05
        asyncio.run(database.mark_dynamic_q75(ids[-1],q['atr'],q['p1']))
        asyncio.run(database.set_market_spike_count(ids[-3:],3))
        db=sqlite3.connect(database.DB_PATH)
        row=db.execute('select dynamic_q75_confirmed,market_spike_count_1m from volume_alerts where id=?',(ids[-1],)).fetchone(); db.close()
        assert row==(1,3)
    finally: database.DB_PATH=old
