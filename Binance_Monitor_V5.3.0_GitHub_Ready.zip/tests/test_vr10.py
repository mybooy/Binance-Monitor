from data_engine import DataEngine, classify_volume_state
from main import build_model_a_event


def _bar(t, vol, price=1.0, high=None, low=None, close=None):
    close=price if close is None else close
    return {'open_at':float(t),'open':price,'high':high if high is not None else max(price,close)*1.001,
            'low':low if low is not None else min(price,close)*0.999,'close':close,
            'base_volume':float(vol),'quote_volume':float(vol)*close,'trade_count':1,'taker_buy_base':float(vol)/2,'closed':True}


def seed_history(eng,s,window_open,group_vol=100):
    start=window_open-24*900
    for g in range(24):
        for j in range(3):
            t=start+g*900+j*300
            eng.five_klines[s][float(t)] = _bar(t,group_vol/3,1.0)


def seed_minutes(eng,s,window_open,vols,prices=None):
    prices=prices or [1.0]*len(vols)
    for i,(v,px) in enumerate(zip(vols,prices)):
        t=window_open+i*60
        op=prices[i-1] if i else prices[0]
        eng.minute_klines[s][float(t)] = _bar(t,v,op,close=px)
        # ingest-like completed 5m bars for indicators when enough minute bars exist
        b=float(int(t//300)*300)
        parts=[eng.minute_klines[s].get(b+k*60) for k in range(5)]
        if all(parts):
            eng.five_klines[s][b]={'open_at':b,'open':parts[0]['open'],'high':max(x['high'] for x in parts),
              'low':min(x['low'] for x in parts),'close':parts[-1]['close'],'base_volume':sum(x['base_volume'] for x in parts),
              'quote_volume':sum(x['quote_volume'] for x in parts),'trade_count':5,'taker_buy_base':sum(x['taker_buy_base'] for x in parts),'closed':True}


def test_actual_vr_has_no_projection():
    eng=DataEngine(); s='XUSDT'; w=100*900.0
    seed_history(eng,s,w,100); seed_minutes(eng,s,w,[31]*10)
    f=eng.live_vr_snapshot(s,w+9*60)
    assert f and f['elapsed_minutes']==10
    assert 3.09 < f['vr_live_actual'] < 3.11
    assert 'vr15_forecast' not in f and 'vr10_projected' not in f


def test_late_burst_after_minute10_is_seen_when_actual_crosses():
    eng=DataEngine(); s='VELVETUSDT'; w=200*900.0
    seed_history(eng,s,w,100); seed_minutes(eng,s,w,[5]*10)
    f10=eng.live_vr_snapshot(s,w+9*60); assert f10 and f10['vr_live_actual']<3
    eng.minute_klines[s][w+10*60]=_bar(w+10*60,280,1.0)
    f11=eng.live_vr_snapshot(s,w+10*60)
    assert f11 and f11['vr_live_actual']>=3


def test_historical_baseline_drops_one_maximum():
    eng=DataEngine(); s='NILUSDT'; w=300*900.0
    start=w-20*900
    vols=[100]*19+[1000]
    for g,total in enumerate(vols):
        for j in range(3): eng.five_klines[s][start+g*900+j*300]=_bar(start+g*900+j*300,total/3)
    baseline=eng._baseline_before_window(s,w)
    assert abs(baseline-100.0)<1e-9


def test_model_a_requires_actual_vr_not_prediction():
    f={'symbol':'XUSDT','bucket':1000.0,'price':1.0,'bar_15m_open_at':0.0,'observation_at':600.0,
       'elapsed_minutes':10,'return_live_pct':-0.2,'base_volume_live':310,'baseline_base_volume_15m':100,
       'vr_live_actual':3.1,'prev_live_vr':2.7,'delta_vr_live':0.4,
       'atr_14_5m':0.01,'atr_14_5m_pct':1.0,'vpe_atr':0.3,'vpe_raw':0.1,'close_location':0.2}
    e=build_model_a_event(f,6_000_000)
    assert e and e['model']=='MODEL_A' and e['direction']=='SHORT'
    assert build_model_a_event({**f,'vr_live_actual':2.99},6_000_000) is None
    assert build_model_a_event(f,5_000_000) is None


def test_volume_states_use_actual_vr():
    assert classify_volume_state(3.2,0,3.0,10,False)=='FIRST_BREAKOUT'
    assert classify_volume_state(3.2,3.1,3.0,10,True)=='CONTINUING'
    assert classify_volume_state(4.0,3.2,3.0,10,True)=='REACCELERATING'
    assert classify_volume_state(2.8,4.0,3.0,10,True)=='DECAY'

def test_model_a_can_detect_from_minute5_with_actual_volume():
    eng=DataEngine(); s='EARLYUSDT'; w=400*900.0
    seed_history(eng,s,w,100); seed_minutes(eng,s,w,[65]*5)
    f=eng.live_vr_snapshot(s,w+4*60)
    assert f and f['elapsed_minutes']==5
    assert 3.24 < f['vr_live_actual'] < 3.26
    assert build_model_a_event(f,6_000_000) is not None


def test_before_configured_start_minute_is_not_scanned():
    eng=DataEngine(); s='TOOEARLYUSDT'; w=500*900.0
    seed_history(eng,s,w,100); seed_minutes(eng,s,w,[100]*4)
    assert eng.live_vr_snapshot(s,w+3*60) is None
