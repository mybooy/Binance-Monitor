import asyncio
import json
import sqlite3
import time
from unittest.mock import AsyncMock, patch

import database
import main
import research_archive
from config import config
from data_engine import DataEngine
from model_b import ModelBEngine, BENCHMARKS, percentile
from test_episode import event
from test_vr10 import seed_history, seed_minutes, _bar


def ready_engine(now, symbol='XUSDT', close=100):
    engine=DataEngine()
    end=int(now//300)*300-300
    for i in range(300):
        t=end-i*300
        engine.five_klines[symbol][float(t)]=_bar(t,100,100,high=110,low=90,close=close)
    radar=ModelBEngine(engine)
    radar._oi[symbol]=(now,200)
    radar._oi_samples[symbol]=[(now-i*300,100+i/100) for i in range(288,0,-1)]
    radar._watch[symbol]={'reasons':['OI_HIGH_PERCENTILE'],'expires_at':now+1800,'first_seen_at':now}
    return radar


def premium(now):
    return {'funding_apr':30,'basis_pct':.2,'sampled_at':now,'funding_interval_hours':8}


def test_trimmed_baseline_duplicates_and_invalid():
    assert DataEngine._volume_mean([100]*18+[1000,1000]) == (1800+1000)/19
    assert DataEngine._volume_mean([100]*19)==0
    assert DataEngine._volume_mean([100]*19+[float('nan')])==0
    assert percentile(100,[100]*288)==50


def test_baseline_rejects_missing_adjacent_window():
    e=DataEngine(); w=90000
    seed_history(e,'XUSDT',w)
    e.five_klines['XUSDT'].pop(w-600)
    assert e._baseline_before_window('XUSDT',w)==0


def test_closed_bar_cannot_be_replaced_by_partial():
    e=DataEngine()
    k={'t':0,'i':'1m','o':'1','h':'2','l':'1','c':'2','v':'10','q':'20','x':True}
    e.ingest_1m('XUSDT',k)
    assert not e.ingest_1m('XUSDT',{**k,'x':False,'c':'1'})
    assert e.minute_klines['XUSDT'][0]['close']==2


def test_model_b_cold_start_missing_values_never_high_risk():
    r=ModelBEngine(DataEngine())
    out=r._evaluate('XUSDT',{},None,{},time.time())
    assert out['score']==0 and out['level']==0
    assert out['oi_percentile'] is None and out['fs_ratio'] is None
    assert out['direction']=='UNKNOWN' and out['data_quality']=='INCOMPLETE'


def test_oi_only_discovers_symbol_and_benchmarks_always_present():
    now=time.time(); r=ready_engine(now)
    targets=r._discovery({'XUSDT'},{'XUSDT':10_000_000},{},now)
    assert all(s in targets for s in (*BENCHMARKS,'XUSDT'))
    assert r._watch['XUSDT']['reasons']==['OI_HIGH_PERCENTILE']
    assert r._discovery(set(),{}, {},now)==list(BENCHMARKS)


def test_score_cannot_substitute_for_structure_or_liquidation():
    now=time.time(); r=ready_engine(now,close=109)
    out=r._evaluate('XUSDT',premium(now),1,{},now)
    assert out['score']>=70 and out['level']==2
    r=ready_engine(now,close=95)
    out=r._evaluate('XUSDT',premium(now),1,{},now)
    assert out['level']==3 and out['data_quality']=='OK'
    assert r._evaluate('XUSDT',premium(now),None,{},now)['level']<3
    r._liq_connected=True
    r._liquidations['XUSDT'].append((now,'LONG_LIQ',200000))
    assert r._evaluate('XUSDT',premium(now),1,{},now)['level']==4
    r._liq_connected=False
    assert r._evaluate('XUSDT',premium(now),1,{},now)['level']==3


def test_liquidation_uses_filled_quantity_not_order_quantity():
    r=ModelBEngine(DataEngine()); now=time.time()
    r._ingest_liquidation({'E':now*1000,'o':{'s':'XUSDT','S':'SELL','ap':'100','q':'1000','z':'2'}})
    assert r._get_liquidation_metrics('XUSDT')['liq_total_5m']==200


def test_stale_oi_and_conflicting_cost_direction_are_not_high_risk():
    now=time.time(); r=ready_engine(now,close=95)
    out=r._evaluate('XUSDT',{**premium(now),'basis_pct':-.2},1,{},now)
    assert out['direction']=='UNKNOWN' and out['level']<3
    r._oi['XUSDT']=(now-181,200)
    assert r._evaluate('XUSDT',premium(now),1,{},now)['oi_percentile'] is None


def test_funding_annualization_uses_contract_interval():
    async def run():
        r=ModelBEngine(DataEngine()); now=time.time()
        async def get(path,**kw):
            if path.endswith('fundingInfo'): return [{'symbol':'XUSDT','fundingIntervalHours':4}]
            return [{'symbol':'XUSDT','markPrice':'101','indexPrice':'100','lastFundingRate':'.001','time':now*1000}]
        with patch('model_b.market_client.get',side_effect=get):
            p=await r._premiums()
        assert abs(p['XUSDT']['funding_apr']-219)<1e-9
    asyncio.run(run())


def test_alert_cooldown_survives_restart_and_outbox_atomic(tmp_path):
    async def run():
        await database.init_db()
        r=ready_engine(time.time(),close=95)
        async def spot(*args): return 1
        async def premiums(): return {'XUSDT':premium(time.time())}
        r._sample_oi=AsyncMock(); r._spot_hour=spot; r._premiums=premiums
        await r.scan_and_evaluate({'XUSDT'},{'XUSDT':10_000_000},{})
        await r.scan_and_evaluate({'XUSDT'},{'XUSDT':10_000_000},{})
        assert len(await database.recent_model_b_alerts())==1
        r2=ready_engine(time.time(),close=95)
        r2.symbol_state_machine=await database.load_model_b_state()
        r2._sample_oi=AsyncMock(); r2._spot_hour=spot; r2._premiums=premiums
        await r2.scan_and_evaluate({'XUSDT'},{'XUSDT':10_000_000},{})
        assert len(await database.recent_model_b_alerts())==1
        with database._connect() as db:
            assert db.execute('select count(*) from notification_outbox').fetchone()[0]==1
    asyncio.run(run())


def test_model_a_runtime_resets_episode_and_confirms_entry(tmp_path):
    async def run():
        await database.init_db()
        e=DataEngine(); s='CAPUSDT'; w=90000
        seed_history(e,s,w)
        for b in e.five_klines[s].values():
            b['high']=1.02; b['low']=.98
        seed_minutes(e,s,w,[70]*5,prices=[1,1.02,1.01,1.03,1.04])
        with patch.object(main,'engine',e),patch.object(main,'volume_episode_cache',{}),patch.object(main,'quote_volume_24h',{s:20_000_000}),patch.object(main.trend_context_engine,'snapshot',AsyncMock(return_value={'bb_1h_position':'ABOVE','bb_4h_position':'ABOVE'})):
            await main._process_live_volume_observation(w+240,{s})
            alerts=await database.recent_volume_alerts()
            assert len(alerts)==1
            a=alerts[0]
            await main._update_signal_confirmations(w+360,{s:{'close':a['trigger_price']*1.01}})
            a=(await database.recent_volume_alerts())[0]
            assert a['persistence_1m_pct'] is not None
            assert a['a_plus_confirm_at']==w+360 and a['a_plus_confirm_price']>a['trigger_price']
            seed_minutes(e,s,w,[70]*5+[1]*10)
            await main._process_live_volume_observation(w+840,{s})
            for step in (1,2):
                nw=w+step*900
                seed_minutes(e,s,nw,[1]*15)
                await main._process_live_volume_observation(nw+840,{s})
            assert not main.volume_episode_cache
            nw=w+2700
            seed_minutes(e,s,nw,[100]*5)
            await main._process_live_volume_observation(nw+240,{s})
            assert len(await database.recent_volume_alerts())==2
    asyncio.run(run())


def test_archive_failure_preserves_raw_path(tmp_path):
    async def run():
        await database.init_db()
        _,aid=await database.start_volume_episode(event())
        with database._connect() as db:
            db.execute('update signal_lifecycle set completed=1,completed_at=1')
        with patch.object(database,'archive_completed_signal',side_effect=OSError('disk failure')):
            result=await database.prune_runtime_research_data()
        assert result['archived']==0 and result['signal_path_points_deleted']==0
        assert (await database.signal_path('MODEL_A',aid))['points']
    asyncio.run(run())


def test_reconcile_does_not_compress_minute_gaps(tmp_path):
    async def run():
        await database.init_db()
        _,aid=await database.start_volume_episode(event())
        raw=[[(1500+i*60)*1000,1,1.01,.99,1,1,(1500+(i+1)*60)*1000-1] for i in range(250) if i!=10]
        with database._connect() as db:
            database._reconcile_lifecycle_and_execution_db(db,'MODEL_A',aid,'CAPUSDT','LONG',1500,1,raw)
            assert db.execute('select completed from signal_lifecycle').fetchone()[0]==0
            assert db.execute('select count(*) from signal_execution_results').fetchone()[0]==0
    asyncio.run(run())


def test_context_excludes_future_snapshots():
    assert main._asof_context({'status':'BULL','updated_at':1001},1000)['status']=='UNKNOWN'
    assert main._asof_context({'status':'BEAR','updated_at':999},1000)['status']=='BEAR'


def test_database_context_closes_connection(tmp_path):
    with database._connect() as db: db.execute('select 1')
    try:
        db.execute('select 1')
        assert False,'connection leaked'
    except sqlite3.ProgrammingError:
        pass


def test_archive_migration_preserves_legacy_and_dataset_identity(tmp_path):
    # Reproduce an old archive without new dataset or confirmation columns.
    legacy_schema=research_archive.ARCHIVE_SCHEMA.replace("  source_dataset TEXT NOT NULL DEFAULT 'legacy',\n",'')
    legacy_schema=legacy_schema.replace('  confirmation_entry_price REAL, confirmation_entry_at REAL,\n','').replace('  execution_results_json TEXT, signal_payload_json TEXT,\n','')
    legacy_schema=legacy_schema.replace('PRIMARY KEY(source_dataset, source_version, source_id)','PRIMARY KEY(source_version, source_id)')
    with sqlite3.connect(research_archive.ARCHIVE_PATH) as db:
        db.executescript(legacy_schema)
        db.execute("INSERT INTO model_a_research(source_version,source_id,symbol,direction,signal_at,trigger_price,archived_at) VALUES('4.8.0',1,'OLDUSDT','LONG',100,1,1)")
    db.close()
    async def archive_dataset(path):
        with patch.object(database,'DB_PATH',path):
            await database.init_db()
            _,aid=await database.start_volume_episode(event())
            await database.confirm_high_quality_and_enqueue(aid,'test','test',1.01,1560)
            with database._connect() as db:
                db.execute('UPDATE signal_lifecycle SET completed=1,completed_at=16000')
                assert research_archive.archive_completed_signal(db,aid)
    asyncio.run(archive_dataset(tmp_path/'one.db'))
    asyncio.run(archive_dataset(tmp_path/'two.db'))
    with research_archive._connect() as db:
        assert db.execute('SELECT count(*) FROM model_a_research').fetchone()[0]==3
        assert db.execute('SELECT count(*) FROM model_a_research_v48_backup').fetchone()[0]==1
        rows=db.execute("SELECT * FROM model_a_research WHERE source_version='4.9.0'").fetchall()
        assert len({r['source_dataset'] for r in rows})==2
        assert all(r['confirmation_entry_price']==1.01 for r in rows)
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    snapshot=research_archive.create_analysis_snapshot(output_root=tmp_path/'exports')
    assert snapshot['signal_count']==2 and snapshot['manifest']['source_versions']==['4.9.0']
    assert (tmp_path/'exports'/next((tmp_path/'exports').iterdir()).name/'window_clusters.csv').exists()


def test_api_reads_persisted_model_a_not_only_last_scan(tmp_path):
    async def run():
        await database.init_db()
        _,aid=await database.start_volume_episode(event(),notification=('test','test'))
        with patch.dict(main.state,{'model_a':[]}):
            state=await main.api_state()
        assert state['version']=='5.3.0-fusion' and state['model_a_signal_version']=='4.9.0'
        assert state['model_a'][0]['alert_id']==aid
        assert state['model_a'][0]['vr_live_actual']==3.4
        json.dumps(state,allow_nan=False)
    asyncio.run(run())


def test_gap_repair_restores_missing_bars_without_alerts(tmp_path):
    async def run():
        e=DataEngine(); now=time.time()
        async def get(path,**kw):
            step=60 if kw['interval']=='1m' else 300
            end=int(kw['endTime']/1000)//step*step
            return [[(end-i*step)*1000,1,1.01,.99,1,10,(end-i*step+step)*1000-1,10,1,5] for i in range(kw['limit']-1,-1,-1)]
        with patch.object(main,'engine',e),patch.object(main,'eligible_symbols',frozenset({'XUSDT'})),patch.object(main.market_client,'get',side_effect=get):
            await main.repair_market_gaps_once()
        assert len(e.five_klines['XUSDT'])>=252
        assert e.live_vr_snapshot('XUSDT',main._target_closed_minute(now)) is not None or (main._target_closed_minute(now)%900)/60+1<config.model_a_scan_start_minute
    asyncio.run(run())


def test_confirmation_execution_requires_240_minutes_after_own_entry(tmp_path):
    async def run():
        await database.init_db()
        _,aid=await database.start_volume_episode(event())
        await database.confirm_high_quality_and_enqueue(aid,'test','test',1.01,1560)
        raw=[[(1500+i*60)*1000,1,1.02,.999,1.01,1,(1500+(i+1)*60)*1000-1] for i in range(241)]
        with database._connect() as db:
            database._reconcile_lifecycle_and_execution_db(db,'MODEL_A',aid,'CAPUSDT','LONG',1500,1,raw[:240])
            assert db.execute("SELECT count(*) FROM signal_execution_results WHERE entry_mode='ENTRY_A_PLUS_CONFIRM'").fetchone()[0]==0
            database._reconcile_lifecycle_and_execution_db(db,'MODEL_A',aid,'CAPUSDT','LONG',1500,1,raw)
            result=db.execute("SELECT entry_at,entry_price,exit_at FROM signal_execution_results WHERE strategy='CONFIRM__TIME_240M'").fetchone()
            assert tuple(result)==(1560,1.01,1560+240*60)
    asyncio.run(run())


def test_trailing_checks_existing_stop_before_new_high():
    bars=[{'ts':0,'high':102.5,'low':100,'close':102}, {'ts':60,'high':110,'low':101,'close':108}]
    value,reason,stamp=database._trailing(bars,100,'LONG',2,1,1.5)
    assert abs(value-1.5)<1e-9 and stamp==60


def test_unwind_retains_recent_crowding_when_oi_has_already_fallen():
    now=time.time(); r=ready_engine(now,close=95)
    r._oi['XUSDT']=(now,90)
    r._liq_connected=True
    r._liquidations['XUSDT'].append((now,'LONG_LIQ',200000))
    r.symbol_state_machine['XUSDT:LONG']={'crowding_evidence_at':now-120}
    assert r._evaluate('XUSDT',premium(now),1,{},now)['level']==4
    r.symbol_state_machine['XUSDT:LONG']={'crowding_evidence_at':now-7200}
    assert r._evaluate('XUSDT',premium(now),1,{},now)['level']<4
