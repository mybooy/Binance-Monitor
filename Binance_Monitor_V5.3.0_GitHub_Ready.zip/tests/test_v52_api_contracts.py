import asyncio
import sqlite3
import time

import research_archive
from multi_exchange import ThreeExchangeClient
from radar_storage import RadarStorage, record_delivery, connect


def test_okx_spot_quote_volume_not_multiplied_by_price():
    c=ThreeExchangeClient()
    c._add('okx','SPOT','BTC-USDT','BTC')
    c._add('okx','PERP','BTC-USDT-SWAP','BTC',contract_multiplier=.01,contract_unit='BTC')
    spot=c.normalize_okx([{'instId':'BTC-USDT','last':'10000','volCcy24h':'500000','ts':'1700000000000'}], 'SPOT', 1700000000)
    perp=c.normalize_okx([{'instId':'BTC-USDT-SWAP','last':'10000','volCcy24h':'200','ts':'1700000000000'}], 'PERP', 1700000000)
    assert spot[0].volume_24h_quote == 500_000
    assert perp[0].volume_24h_quote == 2_000_000


def test_bybit_linear_cursor_and_spot_no_pagination():
    class FakeHTTP:
        def __init__(self):self.calls=[]
        async def get(self,host,path,params=None):
            self.calls.append(params)
            if params['category']=='spot':
                assert 'cursor' not in params and 'limit' not in params
                return {'result':{'list':[{'symbol':'ABCUSDT','baseCoin':'ABC','quoteCoin':'USDT','status':'Trading'}],
                                  'nextPageCursor':''}}
            assert params.get('limit')==1000
            if 'cursor' not in params:
                return {'result':{'list':[{'symbol':'BTCUSDT','baseCoin':'BTC','quoteCoin':'USDT',
                              'settleCoin':'USDT','status':'Trading','contractType':'LinearPerpetual',
                              'fundingInterval':'480'}], 'nextPageCursor':'next'}}
            return {'result':{'list':[{'symbol':'ETHUSDT','baseCoin':'ETH','quoteCoin':'USDT',
                  'settleCoin':'USDT','status':'Trading','contractType':'LinearPerpetual',
                  'fundingInterval':'240'}], 'nextPageCursor':''}}
    async def case():
        c=ThreeExchangeClient(FakeHTTP())
        await c.discover_bybit()
        assert c.coverage()['bybit']['perp']==2
        assert c.coverage()['bybit']['spot']==1
        assert c.instruments['bybit:PERP:ETHUSDT'].funding_interval_hours==4
    asyncio.run(case())


def test_old_archive_schema_lossless_migration(tmp_path):
    p=tmp_path/'archive.db'
    with sqlite3.connect(p) as db:
        db.execute('''CREATE TABLE model_a_research(source_version TEXT NOT NULL,source_id INTEGER NOT NULL,
          symbol TEXT NOT NULL,direction TEXT NOT NULL,signal_at REAL NOT NULL,
          trigger_price REAL NOT NULL,archived_at REAL NOT NULL,
          PRIMARY KEY(source_version,source_id))''')
        db.execute("INSERT INTO model_a_research VALUES('4.8.0',1,'BTCUSDT','LONG',1800000000,100,1900000000)")
    with research_archive._connect(p) as db:
        r=db.execute('SELECT source_dataset,source_id,symbol FROM model_a_research').fetchone()
        assert r['source_id']==1 and r['symbol']=='BTCUSDT' and r['source_dataset']=='legacy'
        db.execute('''INSERT INTO model_a_research(source_dataset,source_version,source_id,
            symbol,direction,signal_at,trigger_price,archived_at) VALUES(?,?,?,?,?,?,?,?)''',
          ('independent-run-2','4.8.0',1,'ETHUSDT','SHORT',1800000001,101,1900000001))
    with research_archive._connect(p) as db:
        assert db.execute('SELECT COUNT(*) FROM model_a_research').fetchone()[0]==2
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'


def test_radar_delivery_timestamp_means_ack_not_enqueue(tmp_path):
    async def case():
        st=RadarStorage(tmp_path/'radar.db');await st.start()
        now=time.time()
        event={'event_id':'evt1','asset':'BTC','event_type':'LEVERAGE_BUILD','exchange':'okx','status':'CONFIRMED',
          'first_at':now,'last_at':now,'exchange_event_ms':int(now*1000),'receive_at':now+1,
          'decision_at':now+2,'reference_price':100,'reference_exchange':'okx','direction':'LONG','risk':50,
          'confidence':'MEDIUM','quality':'OK','evidence_json':'{}','coverage_json':'{}',
          'notification_status':'SHADOW'}
        await st.write('event',event)
        await st.write('notify',{'outbox_key':-2010000000000000,'event_id':'evt1','at':now+3,'status':'QUEUED'})
        await st.flush()
        with connect(st.path) as db:
            r=db.execute('SELECT notify_at,notify_queued_at FROM radar_events').fetchone()
            assert r['notify_at'] is None and r['notify_queued_at'] == now+3
        record_delivery(-2010000000000000,'SENT',now+4,path=st.path)
        with connect(st.path) as db:
            assert db.execute('SELECT notify_at FROM radar_events').fetchone()[0] == now+4
        await st.close()
    asyncio.run(case())


def test_breadth_counts_assets_not_exchange_listings(tmp_path):
    from radar_v52 import RadarEngine
    from radar_storage import RadarStorage
    from multi_exchange import Quote
    engine=RadarEngine(storage=RadarStorage(tmp_path/'r.db'))
    def quote(ex,asset,price):
        return Quote(ex,asset+'USDT',asset,'PERP',price,None,1000)
    past=[quote(ex,'BTC',100) for ex in ('binance','okx','bybit')]
    later=[quote(ex,'BTC',101) for ex in ('binance','okx','bybit')]
    engine.make_aggregate(past,1000)
    engine.prev={f'{q.exchange}:{q.market}:{q.symbol}':q for q in past}
    engine.prev_seen={f'{q.exchange}:{q.market}:{q.symbol}':1000 for q in past}
    for q in later:q.received_at=1075
    f=engine.make_aggregate(later,1075)
    b=engine.cross_market_snapshot(f,1075)
    assert b['asset_sample_count']==1 and b['up_assets']==1
