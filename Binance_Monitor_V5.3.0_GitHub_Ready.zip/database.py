"""SQLite persistence for V4.8.0 Market Breadth & Model-A Research Core."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from types import SimpleNamespace

from config import ROOT, config
from research_archive import archive_completed_signal, archive_summary, create_analysis_snapshot

DB_PATH = ROOT / "monitor_v4.db"
_LOCK = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS runtime_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS model_b_state (key TEXT PRIMARY KEY, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS model_b_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, sampled_at REAL NOT NULL, payload TEXT NOT NULL,
    UNIQUE(symbol, sampled_at)
);
CREATE INDEX IF NOT EXISTS idx_model_b_snapshot_time ON model_b_snapshots(sampled_at);
CREATE TABLE IF NOT EXISTS model_b_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL, payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS leverage_crowding_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at REAL NOT NULL,
    symbol TEXT NOT NULL,
    direction TEXT NOT NULL,
    score REAL NOT NULL,
    level INTEGER NOT NULL,
    level_name TEXT NOT NULL,
    sector TEXT NOT NULL,
    vr_1h REAL NOT NULL,
    oi REAL NOT NULL,
    oi_percentile REAL NOT NULL,
    oi_zscore REAL NOT NULL,
    funding_apr REAL NOT NULL,
    funding_percentile REAL NOT NULL,
    basis_pct REAL NOT NULL,
    basis_percentile REAL NOT NULL,
    fs_ratio REAL NOT NULL,
    clv REAL NOT NULL,
    return_1h_pct REAL NOT NULL,
    liq_total_5m REAL NOT NULL,
    liq_imbalance_5m REAL NOT NULL,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crowd_alerts_created ON leverage_crowding_alerts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_crowd_alerts_symbol ON leverage_crowding_alerts(symbol, created_at DESC);

CREATE TABLE IF NOT EXISTS leverage_crowding_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    sampled_at REAL NOT NULL,
    score REAL NOT NULL,
    level INTEGER NOT NULL,
    vr_1h REAL NOT NULL,
    oi REAL NOT NULL,
    funding_apr REAL NOT NULL,
    basis_pct REAL NOT NULL,
    fs_ratio REAL NOT NULL,
    clv REAL NOT NULL,
    payload TEXT NOT NULL,
    UNIQUE(symbol, sampled_at)
);
CREATE INDEX IF NOT EXISTS idx_crowd_snap_sym ON leverage_crowding_snapshots(symbol, sampled_at DESC);
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS system_meta (
  key TEXT PRIMARY KEY, value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS volume_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, window_open REAL NOT NULL, observation_at REAL NOT NULL,
  symbol TEXT NOT NULL, direction TEXT NOT NULL, model TEXT NOT NULL DEFAULT 'MODEL_A', volume_state TEXT NOT NULL,
  trigger_price REAL NOT NULL, vr10_now REAL NOT NULL, vr10_projected REAL NOT NULL, prev_vr10_projected REAL NOT NULL,
  atr_pct REAL NOT NULL, vpe_atr REAL NOT NULL DEFAULT 0, vpe_raw REAL NOT NULL DEFAULT 0,
  close_location REAL NOT NULL DEFAULT 0.5, directional_close_location REAL NOT NULL DEFAULT 0.5,
  persistence_1m_pct REAL, persistence_2m_pct REAL, persistence_3m_pct REAL, persistence_5m_pct REAL,
  persistence_15m_close_pct REAL, persistence_next_15m_close_pct REAL,
  market_spike_count_1m INTEGER NOT NULL DEFAULT 1, market_spike_risk TEXT NOT NULL DEFAULT 'NORMAL',
  high_quality_confirmed INTEGER NOT NULL DEFAULT 0, dynamic_q75_confirmed INTEGER NOT NULL DEFAULT 0,
  dynamic_q75_atr_threshold REAL, dynamic_q75_p1_threshold REAL, dynamic_q80_confirmed INTEGER NOT NULL DEFAULT 0,
  dynamic_q80_atr_threshold REAL, dynamic_q80_p1_threshold REAL, high_quality_confirmed_at REAL,
  quote_volume_24h REAL NOT NULL, payload TEXT NOT NULL, notified INTEGER NOT NULL DEFAULT 0,
  mfe_pct REAL NOT NULL DEFAULT 0, mae_pct REAL NOT NULL DEFAULT 0, final_return_pct REAL,
  first_plus_1_at REAL, first_plus_2_at REAL, first_plus_3_at REAL, first_plus_5_at REAL,
  first_minus_1_at REAL, first_minus_1_5_at REAL, first_minus_2_at REAL, mfe_at REAL,
  tracking_status TEXT NOT NULL DEFAULT 'tracking', tracking_ended INTEGER NOT NULL DEFAULT 0, tracking_v45 INTEGER NOT NULL DEFAULT 1,
  signal_engine_version TEXT NOT NULL DEFAULT '', tracking_version INTEGER NOT NULL DEFAULT 0,
  source_signal_engine_version TEXT NOT NULL DEFAULT '', tracking_engine_version TEXT NOT NULL DEFAULT '', execution_engine_version TEXT NOT NULL DEFAULT '',
  atr_percentile_200 REAL, atr_percentile_500 REAL, trigger_directional_move_pct REAL, trigger_move_atr_ratio REAL,
  a_plus_confirm_price REAL, a_plus_confirm_at REAL, persistence_state TEXT NOT NULL DEFAULT 'PENDING',
  a_plus_plus_trend INTEGER NOT NULL DEFAULT 0, a_plus_plus_persistence INTEGER NOT NULL DEFAULT 0, a_plus_plus_confirmed_at REAL,
  systemic_market_shock INTEGER NOT NULL DEFAULT 0, market_state_status TEXT NOT NULL DEFAULT 'UNKNOWN',
  market_state_direction_score REAL, market_state_stress_score REAL,
  episode_id INTEGER, elapsed_minutes INTEGER NOT NULL DEFAULT 10, actual_vr_at_trigger REAL NOT NULL DEFAULT 0,
  predicted_vr_at_trigger REAL NOT NULL DEFAULT 0, confirmation_status TEXT NOT NULL DEFAULT 'PENDING',
  final_actual_vr15 REAL, confirmed_at REAL,
  UNIQUE(window_open, symbol)
);
CREATE INDEX IF NOT EXISTS idx_volume_alerts_created ON volume_alerts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_volume_alerts_symbol ON volume_alerts(symbol, created_at DESC);
CREATE TABLE IF NOT EXISTS volume_episodes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, direction TEXT NOT NULL, started_at REAL NOT NULL,
  start_window_open REAL NOT NULL, trigger_alert_id INTEGER, status TEXT NOT NULL DEFAULT 'ACTIVE',
  last_observation_at REAL NOT NULL, last_predicted_vr REAL NOT NULL DEFAULT 0, peak_predicted_vr REAL NOT NULL DEFAULT 0,
  last_actual_vr REAL NOT NULL DEFAULT 0, peak_episode_actual_vr REAL NOT NULL DEFAULT 0, peak_actual_vr REAL NOT NULL DEFAULT 0,
  below_reset_windows INTEGER NOT NULL DEFAULT 0, ended_at REAL, end_reason TEXT NOT NULL DEFAULT '', payload TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_volume_episodes_symbol ON volume_episodes(symbol,status,started_at DESC);
CREATE TABLE IF NOT EXISTS volume_observations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, episode_id INTEGER, symbol TEXT NOT NULL,
  window_open REAL NOT NULL, observation_at REAL NOT NULL, elapsed_minutes INTEGER NOT NULL, volume_state TEXT NOT NULL,
  actual_vr REAL NOT NULL, predicted_vr REAL NOT NULL, recent_1m_rate REAL NOT NULL, cumulative_base_volume REAL NOT NULL,
  baseline_base_volume REAL NOT NULL, price REAL NOT NULL, return_live_pct REAL NOT NULL, atr_pct REAL NOT NULL,
  vpe_atr REAL NOT NULL DEFAULT 0, vpe_raw REAL NOT NULL DEFAULT 0, close_location REAL NOT NULL DEFAULT 0.5,
  directional_close_location REAL NOT NULL DEFAULT 0.5, payload TEXT NOT NULL, UNIQUE(symbol, observation_at)
);
CREATE INDEX IF NOT EXISTS idx_volume_obs_symbol ON volume_observations(symbol,observation_at DESC);
CREATE TABLE IF NOT EXISTS signal_lifecycle (
  id INTEGER PRIMARY KEY AUTOINCREMENT, source_type TEXT NOT NULL DEFAULT 'MODEL_A', source_id INTEGER NOT NULL,
  symbol TEXT NOT NULL, direction TEXT NOT NULL, trigger_at REAL NOT NULL, trigger_price REAL NOT NULL,
  signal_engine_version TEXT NOT NULL DEFAULT '4.8.0', tracking_version INTEGER NOT NULL DEFAULT 5,
  source_signal_engine_version TEXT NOT NULL DEFAULT '4.8.0', tracking_engine_version TEXT NOT NULL DEFAULT '4.8.0',
  execution_engine_version TEXT NOT NULL DEFAULT '4.8.0', confirmation_entry_price REAL, confirmation_entry_at REAL,
  last_observation_at REAL, running_mfe_pct REAL NOT NULL DEFAULT 0, running_mae_pct REAL NOT NULL DEFAULT 0,
  running_mfe_at REAL, time_to_mfe_minutes REAL, current_return_pct REAL, giveback_pct REAL, giveback_ratio REAL,
  first_plus_1_min REAL, first_plus_2_min REAL, first_plus_3_min REAL, first_plus_5_min REAL,
  first_minus_1_min REAL, first_minus_1_5_min REAL, first_minus_2_min REAL,
  return_1m REAL, mfe_1m REAL, mae_1m REAL, return_3m REAL, mfe_3m REAL, mae_3m REAL, return_5m REAL, mfe_5m REAL, mae_5m REAL,
  return_10m REAL, mfe_10m REAL, mae_10m REAL, return_15m REAL, mfe_15m REAL, mae_15m REAL, return_20m REAL, mfe_20m REAL, mae_20m REAL,
  return_30m REAL, mfe_30m REAL, mae_30m REAL, return_45m REAL, mfe_45m REAL, mae_45m REAL, return_60m REAL, mfe_60m REAL, mae_60m REAL,
  return_90m REAL, mfe_90m REAL, mae_90m REAL, return_120m REAL, mfe_120m REAL, mae_120m REAL, return_240m REAL, mfe_240m REAL, mae_240m REAL,
  completed INTEGER NOT NULL DEFAULT 0, completed_at REAL, UNIQUE(source_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_lifecycle_active ON signal_lifecycle(completed,trigger_at);
CREATE INDEX IF NOT EXISTS idx_lifecycle_symbol ON signal_lifecycle(symbol,trigger_at DESC);
CREATE TABLE IF NOT EXISTS signal_market_context (
  source_type TEXT NOT NULL DEFAULT 'MODEL_A', source_id INTEGER NOT NULL, symbol TEXT NOT NULL, direction TEXT NOT NULL,
  signal_at REAL NOT NULL, captured_at REAL NOT NULL, market_sampled_at REAL, context_age_seconds REAL,
  market_state_status TEXT NOT NULL DEFAULT 'UNKNOWN', market_direction_score REAL, market_stress_score REAL,
  data_quality TEXT NOT NULL DEFAULT 'UNKNOWN', btc_state TEXT NOT NULL DEFAULT 'UNKNOWN', btc_direction_score REAL, btc_stress_score REAL,
  eth_state TEXT NOT NULL DEFAULT 'UNKNOWN', eth_direction_score REAL, eth_stress_score REAL,
  btc_velocity_5m REAL, eth_velocity_5m REAL, btc_futures_taker_imbalance_3m REAL, eth_futures_taker_imbalance_3m REAL,
  btc_oi_delta_5m REAL, eth_oi_delta_5m REAL, btc_liquidation_imbalance REAL, eth_liquidation_imbalance REAL,
  breadth_sampled_at REAL, breadth_age_seconds REAL, breadth_status TEXT NOT NULL DEFAULT 'UNKNOWN', breadth_score REAL,
  session_up_pct REAL, session_down_pct REAL, session_flat_pct REAL, median_session_return_pct REAL,
  pct_up_1 REAL, pct_up_3 REAL, pct_down_1 REAL, pct_down_3 REAL, breadth_score_delta_15m REAL, breadth_score_delta_30m REAL,
  breadth_coverage REAL, breadth_sample_size INTEGER, breadth_eligible_symbol_count INTEGER,
  liquid_breadth_score REAL, liquid_session_up_pct REAL, liquid_session_down_pct REAL, liquid_median_session_return_pct REAL,
  breadth_engine_version TEXT NOT NULL DEFAULT '',
  bb_1h_mid REAL, bb_1h_position TEXT NOT NULL DEFAULT 'UNKNOWN', bb_1h_distance_pct REAL, bb_1h_last_closed_at REAL,
  bb_4h_mid REAL, bb_4h_position TEXT NOT NULL DEFAULT 'UNKNOWN', bb_4h_distance_pct REAL, bb_4h_last_closed_at REAL,
  bb_trend_context TEXT NOT NULL DEFAULT 'UNKNOWN', trend_alignment TEXT NOT NULL DEFAULT 'UNKNOWN',
  trend_data_quality TEXT NOT NULL DEFAULT 'UNKNOWN', trend_engine_version TEXT NOT NULL DEFAULT '',
  source_signal_engine_version TEXT NOT NULL DEFAULT '', market_state_engine_version TEXT NOT NULL DEFAULT '',
  payload TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(source_type,source_id)
);
CREATE INDEX IF NOT EXISTS idx_signal_market_context_state ON signal_market_context(market_state_status,signal_at DESC);
CREATE TABLE IF NOT EXISTS signal_path_points (
  id INTEGER PRIMARY KEY AUTOINCREMENT, source_type TEXT NOT NULL DEFAULT 'MODEL_A', source_id INTEGER NOT NULL,
  symbol TEXT NOT NULL, direction TEXT NOT NULL, signal_at REAL NOT NULL, observed_at REAL NOT NULL,
  elapsed_minutes INTEGER NOT NULL, sample_interval_minutes INTEGER NOT NULL, close_price REAL NOT NULL,
  return_pct REAL NOT NULL, running_mfe_pct REAL NOT NULL, running_mae_pct REAL NOT NULL, giveback_pct REAL NOT NULL,
  giveback_ratio REAL, source_signal_engine_version TEXT NOT NULL DEFAULT '', tracking_engine_version TEXT NOT NULL DEFAULT '',
  created_at REAL NOT NULL, UNIQUE(source_type,source_id,elapsed_minutes)
);
CREATE INDEX IF NOT EXISTS idx_signal_path_source ON signal_path_points(source_type,source_id,elapsed_minutes);
CREATE INDEX IF NOT EXISTS idx_signal_path_observed ON signal_path_points(observed_at DESC);
CREATE TABLE IF NOT EXISTS signal_execution_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT, source_type TEXT NOT NULL DEFAULT 'MODEL_A', source_id INTEGER NOT NULL, strategy TEXT NOT NULL,
  direction TEXT NOT NULL, gross_return_pct REAL NOT NULL, net_return_pct REAL NOT NULL, exit_reason TEXT NOT NULL, exit_at REAL,
  metadata TEXT NOT NULL DEFAULT '{}', entry_mode TEXT NOT NULL DEFAULT 'ENTRY_TRIGGER', entry_price REAL, entry_at REAL,
  source_signal_engine_version TEXT NOT NULL DEFAULT '', tracking_engine_version TEXT NOT NULL DEFAULT '', execution_engine_version TEXT NOT NULL DEFAULT '',
  created_at REAL NOT NULL, UNIQUE(source_type,source_id,strategy)
);
CREATE INDEX IF NOT EXISTS idx_exec_strategy ON signal_execution_results(source_type,strategy);
CREATE TABLE IF NOT EXISTS notification_outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT, alert_id INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_attempt REAL NOT NULL DEFAULT 0,
  created_at REAL NOT NULL, sent_at REAL, last_error TEXT NOT NULL DEFAULT ''
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_outbox_alert_id ON notification_outbox(alert_id);
"""


class _ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc, tb):
        try:
            return super().__exit__(exc_type, exc, tb)
        finally:
            self.close()


def _connect():
    db = sqlite3.connect(DB_PATH, timeout=30, factory=_ClosingConnection)
    db.row_factory = sqlite3.Row
    return db


def _columns(db, table):
    try:
        return {r[1] for r in db.execute(f"PRAGMA table_info({table})").fetchall()}
    except sqlite3.Error:
        return set()


LIFECYCLE_HORIZONS = (1, 3, 5, 10, 15, 20, 30, 45, 60, 90, 120, 240)
ENGINE_VERSION = "4.9.0"
TRACKING_VERSION = 5
TRACKING_ENGINE_VERSION = "4.9.0"
EXECUTION_ENGINE_VERSION = "4.9.0"
SIGNAL_PATH_HORIZON_MINUTES = 240
SIGNAL_PATH_FINE_MINUTES = 60
SIGNAL_PATH_COARSE_STEP_MINUTES = 5


def _round_trip_cost_pct():
    # 1 bp = 0.01%; entry + exit each pay fee/slippage. Funding is entered directly as pct/trade.
    return 2.0 * (float(config.execution_fee_bps_per_side) + float(config.execution_slippage_bps_per_side)) / 100.0 + float(config.execution_funding_cost_pct)


def _register_lifecycle_db(db, source_type, source_id, symbol, direction, trigger_at, trigger_price, source_version=None):
    source_version = str(source_version or ENGINE_VERSION)
    db.execute("""INSERT OR IGNORE INTO signal_lifecycle
      (source_type,source_id,symbol,direction,trigger_at,trigger_price,signal_engine_version,tracking_version,
       source_signal_engine_version,tracking_engine_version,execution_engine_version)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
      (str(source_type),int(source_id),symbol,direction,float(trigger_at),float(trigger_price),source_version,TRACKING_VERSION,
       source_version,TRACKING_ENGINE_VERSION,EXECUTION_ENGINE_VERSION))


def _path_sample_interval(elapsed_minutes):
    elapsed=int(elapsed_minutes)
    if elapsed == 0:
        return 0
    if 1 <= elapsed <= SIGNAL_PATH_FINE_MINUTES:
        return 1
    if SIGNAL_PATH_FINE_MINUTES < elapsed <= SIGNAL_PATH_HORIZON_MINUTES and elapsed % SIGNAL_PATH_COARSE_STEP_MINUTES == 0:
        return SIGNAL_PATH_COARSE_STEP_MINUTES
    return None


def _freeze_market_context_db(db, source_type, source_id, symbol, direction, signal_at, market_state,
                              market_breadth=None, trend_context=None, source_version=None):
    """Freeze one immutable trigger-time context per Model-A signal."""
    ms=dict(market_state or {}); br=dict(market_breadth or {}); tr=dict(trend_context or {})
    assets=ms.get("assets") or {}; btc=assets.get("BTCUSDT") or {}; eth=assets.get("ETHUSDT") or {}
    btf=btc.get("futures") or {}; etf=eth.get("futures") or {}; liquid=br.get("liquid") or {}
    captured=time.time(); sampled=ms.get("updated_at"); bsampled=br.get("updated_at")
    def age(v):
        try: return max(0.0,captured-float(v)) if v else None
        except (TypeError,ValueError): return None
    def fv(obj,key):
        try:
            v=obj.get(key); return float(v) if v is not None else None
        except (TypeError,ValueError,AttributeError): return None
    alignment=str(tr.get("trend_alignment") or "UNKNOWN")
    record={
      "source_type":str(source_type),"source_id":int(source_id),"symbol":symbol,"direction":direction,
      "signal_at":float(signal_at),"captured_at":captured,"market_sampled_at":float(sampled) if sampled else None,
      "context_age_seconds":age(sampled),"market_state_status":str(ms.get("status") or "UNKNOWN"),
      "market_direction_score":fv(ms,"direction_score"),"market_stress_score":fv(ms,"stress_score"),
      "data_quality":str(ms.get("data_quality") or "UNKNOWN"),"btc_state":str(btc.get("state") or "UNKNOWN"),
      "btc_direction_score":fv(btc,"direction_score"),"btc_stress_score":fv(btc,"stress_score"),
      "eth_state":str(eth.get("state") or "UNKNOWN"),"eth_direction_score":fv(eth,"direction_score"),
      "eth_stress_score":fv(eth,"stress_score"),"btc_velocity_5m":fv(btf,"velocity_5m"),"eth_velocity_5m":fv(etf,"velocity_5m"),
      "btc_futures_taker_imbalance_3m":fv(btf,"taker_imbalance_3m"),"eth_futures_taker_imbalance_3m":fv(etf,"taker_imbalance_3m"),
      "btc_oi_delta_5m":fv(btc,"oi_delta_5m"),"eth_oi_delta_5m":fv(eth,"oi_delta_5m"),
      "btc_liquidation_imbalance":fv(btc,"liquidation_imbalance"),"eth_liquidation_imbalance":fv(eth,"liquidation_imbalance"),
      "breadth_sampled_at":float(bsampled) if bsampled else None,"breadth_age_seconds":age(bsampled),
      "breadth_status":str(br.get("status") or "UNKNOWN"),"breadth_score":fv(br,"breadth_score"),
      "session_up_pct":fv(br,"session_up_pct"),"session_down_pct":fv(br,"session_down_pct"),"session_flat_pct":fv(br,"session_flat_pct"),
      "median_session_return_pct":fv(br,"median_session_return_pct"),"pct_up_1":fv(br,"pct_up_1"),"pct_up_3":fv(br,"pct_up_3"),
      "pct_down_1":fv(br,"pct_down_1"),"pct_down_3":fv(br,"pct_down_3"),
      "breadth_score_delta_15m":fv(br,"breadth_score_delta_15m"),"breadth_score_delta_30m":fv(br,"breadth_score_delta_30m"),
      "breadth_coverage":fv(br,"coverage"),"breadth_sample_size":int(br.get("sample_size") or 0),
      "breadth_eligible_symbol_count":int(br.get("eligible_symbol_count") or 0),
      "liquid_breadth_score":fv(liquid,"breadth_score"),"liquid_session_up_pct":fv(liquid,"session_up_pct"),
      "liquid_session_down_pct":fv(liquid,"session_down_pct"),"liquid_median_session_return_pct":fv(liquid,"median_session_return_pct"),
      "breadth_engine_version":str(br.get("engine_version") or ""),
      "bb_1h_mid":fv(tr,"bb_1h_mid"),"bb_1h_position":str(tr.get("bb_1h_position") or "UNKNOWN"),
      "bb_1h_distance_pct":fv(tr,"bb_1h_distance_pct"),"bb_1h_last_closed_at":fv(tr,"bb_1h_last_closed_at"),
      "bb_4h_mid":fv(tr,"bb_4h_mid"),"bb_4h_position":str(tr.get("bb_4h_position") or "UNKNOWN"),
      "bb_4h_distance_pct":fv(tr,"bb_4h_distance_pct"),"bb_4h_last_closed_at":fv(tr,"bb_4h_last_closed_at"),
      "bb_trend_context":str(tr.get("bb_trend_context") or "UNKNOWN"),"trend_alignment":alignment,
      "trend_data_quality":str(tr.get("data_quality") or "UNKNOWN"),"trend_engine_version":str(tr.get("engine_version") or ""),
      "source_signal_engine_version":str(source_version or ENGINE_VERSION),
      "market_state_engine_version":str(ms.get("engine_version") or TRACKING_ENGINE_VERSION),
      "payload":json.dumps({"market_state":ms,"breadth":br,"trend":tr},ensure_ascii=False,allow_nan=False),
    }
    cols=list(record)
    db.execute(f"INSERT OR IGNORE INTO signal_market_context ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})",
               [record[c] for c in cols])


def _insert_signal_path_point_db(db, source_type, source_id, symbol, direction, signal_at, observed_at, elapsed_minutes,
                                 close_price, return_pct, running_mfe_pct, running_mae_pct, giveback_pct, giveback_ratio,
                                 source_version=None):
    interval=_path_sample_interval(elapsed_minutes)
    if interval is None:
        return False
    db.execute("""INSERT INTO signal_path_points
      (source_type,source_id,symbol,direction,signal_at,observed_at,elapsed_minutes,sample_interval_minutes,close_price,
       return_pct,running_mfe_pct,running_mae_pct,giveback_pct,giveback_ratio,source_signal_engine_version,tracking_engine_version,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(source_type,source_id,elapsed_minutes) DO UPDATE SET
       observed_at=excluded.observed_at,sample_interval_minutes=excluded.sample_interval_minutes,close_price=excluded.close_price,
       return_pct=excluded.return_pct,running_mfe_pct=excluded.running_mfe_pct,running_mae_pct=excluded.running_mae_pct,
       giveback_pct=excluded.giveback_pct,giveback_ratio=excluded.giveback_ratio,tracking_engine_version=excluded.tracking_engine_version""",
      (str(source_type),int(source_id),symbol,direction,float(signal_at),float(observed_at),int(elapsed_minutes),int(interval),
       float(close_price),float(return_pct),float(running_mfe_pct),float(running_mae_pct),float(giveback_pct),giveback_ratio,
       str(source_version or ENGINE_VERSION),TRACKING_ENGINE_VERSION,time.time()))
    return True


def _register_trigger_point_db(db, source_type, source_id, symbol, direction, signal_at, trigger_price, source_version=None):
    return _insert_signal_path_point_db(db,source_type,source_id,symbol,direction,signal_at,signal_at,0,trigger_price,0.0,0.0,0.0,0.0,None,source_version)


def _spike_risk(count):
    count=int(count or 0)
    if count >= 16: return "EXTREME"
    if count >= 9: return "HIGH"
    if count >= 4: return "ELEVATED"
    return "NORMAL"


def _percentile_rank_db(db, before_ts, current_value, limit):
    rows=db.execute("""SELECT atr_pct FROM volume_alerts
                       WHERE observation_at<? AND atr_pct IS NOT NULL AND source_signal_engine_version=?
                       ORDER BY observation_at DESC,id DESC LIMIT ?""",(float(before_ts),ENGINE_VERSION,int(limit))).fetchall()
    xs=[float(r[0]) for r in rows if r[0] is not None]
    if len(xs)<20: return None
    x=float(current_value); below=sum(v<x for v in xs); equal=sum(abs(v-x)<1e-12 for v in xs)
    return 100.0*(below+0.5*equal)/len(xs)


async def init_db():
    """Add V4.9 schemas, preserving legacy research and source versions."""
    with _LOCK, _connect() as db:
        db.executescript(SCHEMA)
        db.execute("INSERT OR IGNORE INTO runtime_meta(key,value) VALUES('dataset_id',?)",(str(uuid.uuid4()),))

        def add_columns(table, mapping):
            cols = _columns(db, table)
            for col, ddl in mapping.items():
                if col not in cols:
                    db.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
                    cols.add(col)

        add_columns("volume_alerts", {
            "episode_id":"INTEGER", "elapsed_minutes":"INTEGER NOT NULL DEFAULT 10",
            "actual_vr_at_trigger":"REAL NOT NULL DEFAULT 0", "predicted_vr_at_trigger":"REAL NOT NULL DEFAULT 0",
            "confirmation_status":"TEXT NOT NULL DEFAULT 'PENDING'", "final_actual_vr15":"REAL", "confirmed_at":"REAL",
            "model":"TEXT NOT NULL DEFAULT 'MODEL_A'", "vpe_atr":"REAL NOT NULL DEFAULT 0", "vpe_raw":"REAL NOT NULL DEFAULT 0",
            "close_location":"REAL NOT NULL DEFAULT 0.5", "directional_close_location":"REAL NOT NULL DEFAULT 0.5",
            "persistence_1m_pct":"REAL", "persistence_2m_pct":"REAL", "persistence_3m_pct":"REAL",
            "persistence_5m_pct":"REAL", "persistence_15m_close_pct":"REAL", "persistence_next_15m_close_pct":"REAL",
            "market_spike_count_1m":"INTEGER NOT NULL DEFAULT 1", "high_quality_confirmed":"INTEGER NOT NULL DEFAULT 0",
            "high_quality_confirmed_at":"REAL", "dynamic_q75_confirmed":"INTEGER NOT NULL DEFAULT 0",
            "dynamic_q75_atr_threshold":"REAL", "dynamic_q75_p1_threshold":"REAL", "dynamic_q80_confirmed":"INTEGER NOT NULL DEFAULT 0",
            "dynamic_q80_atr_threshold":"REAL", "dynamic_q80_p1_threshold":"REAL", "market_spike_risk":"TEXT NOT NULL DEFAULT 'NORMAL'",
            "first_plus_3_at":"REAL", "first_plus_5_at":"REAL", "first_minus_1_5_at":"REAL", "first_minus_2_at":"REAL",
            "mfe_at":"REAL", "tracking_v45":"INTEGER NOT NULL DEFAULT 0", "signal_engine_version":"TEXT NOT NULL DEFAULT ''",
            "tracking_version":"INTEGER NOT NULL DEFAULT 0", "source_signal_engine_version":"TEXT NOT NULL DEFAULT ''",
            "tracking_engine_version":"TEXT NOT NULL DEFAULT ''", "execution_engine_version":"TEXT NOT NULL DEFAULT ''",
            "atr_percentile_200":"REAL", "atr_percentile_500":"REAL", "trigger_directional_move_pct":"REAL",
            "trigger_move_atr_ratio":"REAL", "a_plus_confirm_price":"REAL", "a_plus_confirm_at":"REAL",
            "persistence_state":"TEXT NOT NULL DEFAULT 'PENDING'", "a_plus_plus_trend":"INTEGER NOT NULL DEFAULT 0",
            "a_plus_plus_persistence":"INTEGER NOT NULL DEFAULT 0", "a_plus_plus_confirmed_at":"REAL",
            "systemic_market_shock":"INTEGER NOT NULL DEFAULT 0", "market_state_status":"TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "market_state_direction_score":"REAL", "market_state_stress_score":"REAL",
        })
        add_columns("volume_episodes", {"last_actual_vr":"REAL NOT NULL DEFAULT 0", "peak_episode_actual_vr":"REAL NOT NULL DEFAULT 0"})
        add_columns("volume_observations", {"vpe_atr":"REAL NOT NULL DEFAULT 0", "vpe_raw":"REAL NOT NULL DEFAULT 0",
            "close_location":"REAL NOT NULL DEFAULT 0.5", "directional_close_location":"REAL NOT NULL DEFAULT 0.5"})
        add_columns("signal_lifecycle", {
            "source_signal_engine_version":"TEXT NOT NULL DEFAULT ''", "tracking_engine_version":"TEXT NOT NULL DEFAULT ''",
            "execution_engine_version":"TEXT NOT NULL DEFAULT ''", "confirmation_entry_price":"REAL", "confirmation_entry_at":"REAL",
            "running_mfe_at":"REAL", "time_to_mfe_minutes":"REAL", "current_return_pct":"REAL", "giveback_pct":"REAL",
            "giveback_ratio":"REAL", "first_plus_1_min":"REAL", "first_plus_2_min":"REAL", "first_plus_3_min":"REAL",
            "first_plus_5_min":"REAL", "first_minus_1_min":"REAL", "first_minus_1_5_min":"REAL", "first_minus_2_min":"REAL",
        })
        add_columns("signal_execution_results", {
            "entry_mode":"TEXT NOT NULL DEFAULT 'ENTRY_TRIGGER'", "entry_price":"REAL", "entry_at":"REAL",
            "source_signal_engine_version":"TEXT NOT NULL DEFAULT ''", "tracking_engine_version":"TEXT NOT NULL DEFAULT ''",
            "execution_engine_version":"TEXT NOT NULL DEFAULT ''",
        })
        add_columns("signal_market_context", {
            "breadth_sampled_at":"REAL", "breadth_age_seconds":"REAL", "breadth_status":"TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "breadth_score":"REAL", "session_up_pct":"REAL", "session_down_pct":"REAL", "session_flat_pct":"REAL",
            "median_session_return_pct":"REAL", "pct_up_1":"REAL", "pct_up_3":"REAL", "pct_down_1":"REAL", "pct_down_3":"REAL",
            "breadth_score_delta_15m":"REAL", "breadth_score_delta_30m":"REAL", "breadth_coverage":"REAL",
            "breadth_sample_size":"INTEGER", "breadth_eligible_symbol_count":"INTEGER",
            "liquid_breadth_score":"REAL", "liquid_session_up_pct":"REAL", "liquid_session_down_pct":"REAL",
            "liquid_median_session_return_pct":"REAL", "breadth_engine_version":"TEXT NOT NULL DEFAULT ''",
            "bb_1h_mid":"REAL", "bb_1h_position":"TEXT NOT NULL DEFAULT 'UNKNOWN'", "bb_1h_distance_pct":"REAL",
            "bb_1h_last_closed_at":"REAL", "bb_4h_mid":"REAL", "bb_4h_position":"TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "bb_4h_distance_pct":"REAL", "bb_4h_last_closed_at":"REAL", "bb_trend_context":"TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "trend_alignment":"TEXT NOT NULL DEFAULT 'UNKNOWN'", "trend_data_quality":"TEXT NOT NULL DEFAULT 'UNKNOWN'",
            "trend_engine_version":"TEXT NOT NULL DEFAULT ''",
        })
        db.execute("CREATE INDEX IF NOT EXISTS idx_signal_market_context_breadth ON signal_market_context(breadth_status,signal_at DESC)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_signal_market_context_trend ON signal_market_context(bb_trend_context,trend_alignment,signal_at DESC)")

        # V4.9 Model B uses separate tables. Do not erase legacy Model B / CCI evidence.
        db.execute("UPDATE notification_outbox SET status='expired',last_error='LEGACY_MODEL_RETIRED' WHERE alert_id>0 AND status='pending'")

        # Strict source-version preservation for Model A.
        db.execute("""UPDATE volume_alerts SET source_signal_engine_version=
            CASE WHEN COALESCE(source_signal_engine_version,'')<>'' THEN source_signal_engine_version
                 WHEN COALESCE(signal_engine_version,'')<>'' THEN signal_engine_version ELSE 'legacy' END""")
        db.execute("""UPDATE volume_episodes SET status='CLOSED',ended_at=?,end_reason='ENGINE_VERSION_UPGRADE'
            WHERE status='ACTIVE' AND trigger_alert_id IN
            (SELECT id FROM volume_alerts WHERE source_signal_engine_version<>?)""",(time.time(),ENGINE_VERSION))
        db.execute("""UPDATE volume_alerts SET tracking_engine_version=
            CASE WHEN COALESCE(tracking_engine_version,'')<>'' THEN tracking_engine_version
                 WHEN COALESCE(signal_engine_version,'')<>'' THEN signal_engine_version ELSE 'legacy' END""")
        db.execute("""UPDATE signal_lifecycle SET source_signal_engine_version=
            CASE WHEN COALESCE(source_signal_engine_version,'')<>'' THEN source_signal_engine_version
                 WHEN COALESCE(signal_engine_version,'')<>'' THEN signal_engine_version ELSE 'legacy' END""")
        db.execute("""UPDATE signal_lifecycle SET tracking_engine_version=
            CASE WHEN COALESCE(tracking_engine_version,'')<>'' THEN tracking_engine_version
                 WHEN COALESCE(signal_engine_version,'')<>'' THEN signal_engine_version ELSE 'legacy' END""")
        db.execute("""UPDATE signal_execution_results SET source_signal_engine_version=COALESCE(NULLIF(source_signal_engine_version,''),
            (SELECT l.source_signal_engine_version FROM signal_lifecycle l WHERE l.source_type='MODEL_A' AND l.source_id=signal_execution_results.source_id),'legacy')""")
        db.execute("""UPDATE signal_execution_results SET tracking_engine_version=COALESCE(NULLIF(tracking_engine_version,''),
            (SELECT l.tracking_engine_version FROM signal_lifecycle l WHERE l.source_type='MODEL_A' AND l.source_id=signal_execution_results.source_id),'legacy')""")

        # Existing Fixed A+ confirmation entry remains exactly reconstructable.
        db.execute("""UPDATE volume_alerts SET a_plus_confirm_at=observation_at+60,
            a_plus_confirm_price=trigger_price*(1 + (CASE WHEN direction='LONG' THEN 1 ELSE -1 END)*persistence_1m_pct/100.0)
            WHERE high_quality_confirmed=1 AND persistence_1m_pct IS NOT NULL AND a_plus_confirm_price IS NULL""")
        db.execute("""UPDATE signal_lifecycle SET confirmation_entry_price=(SELECT va.a_plus_confirm_price FROM volume_alerts va
              WHERE va.id=signal_lifecycle.source_id), confirmation_entry_at=(SELECT va.a_plus_confirm_at FROM volume_alerts va
              WHERE va.id=signal_lifecycle.source_id)
              WHERE source_type='MODEL_A' AND confirmation_entry_price IS NULL""")

        db.execute("INSERT OR REPLACE INTO system_meta(key,value) VALUES('schema_version','490')")
        db.execute("INSERT OR REPLACE INTO system_meta(key,value) VALUES('engine_version',?)", (ENGINE_VERSION,))
        db.commit()


async def expire_stale_volume_episodes(max_age_seconds=3600):
    cutoff=time.time()-float(max_age_seconds)
    with _LOCK,_connect() as db:
        db.execute("""UPDATE volume_episodes SET status='CLOSED',ended_at=?,end_reason='STALE_AFTER_RESTART'
                      WHERE status='ACTIVE' AND last_observation_at<?""",(time.time(),cutoff))
        db.commit()


async def load_active_volume_episodes():
    with _LOCK, _connect() as db:
        rows = db.execute("SELECT * FROM volume_episodes WHERE status='ACTIVE' ORDER BY started_at").fetchall()
    out = {}
    for r in rows:
        d = dict(r)
        try:
            d["details"] = json.loads(d.get("payload") or "{}")
        except Exception:
            d["details"] = {}
        out[d["symbol"]] = d
    return out


async def start_volume_episode(event, notification=None):
    """Atomically create one Model-A episode and freeze its V4.8.0 trigger-time context."""
    now=time.time()
    trigger_status="CONFIRMED" if int(event.get("elapsed_minutes",0))==15 else "PENDING"
    final_vr=float(event["vr_live_actual"]) if trigger_status=="CONFIRMED" else None
    directional_clv=float(event.get("close_location",.5)) if event["direction"]=="LONG" else 1.0-float(event.get("close_location",.5))
    d=1.0 if event["direction"]=="LONG" else -1.0
    trigger_move=float(event.get("return_live_pct",0) or 0)*d
    atr=float(event.get("atr_14_5m_pct",0) or 0)
    extension=abs(trigger_move)/max(atr,1e-9) if atr>0 else None
    ms=event.get("market_state") or {}
    br=event.get("market_breadth") or {}
    tr=event.get("trend_context") or {}
    with _LOCK,_connect() as db:
        active=db.execute("SELECT id FROM volume_episodes WHERE symbol=? AND status='ACTIVE' LIMIT 1",(event["symbol"],)).fetchone()
        if active: return int(active["id"]),None
        prior=db.execute("SELECT episode_id FROM volume_alerts WHERE symbol=? AND window_open=? LIMIT 1",
                         (event["symbol"],event["bar_15m_open_at"])).fetchone()
        if prior: return prior[0],None
        atr_q200=_percentile_rank_db(db,event["observation_at"],atr,200)
        atr_q500=_percentile_rank_db(db,event["observation_at"],atr,500)
        # Mutate the caller-visible event as well, so Telegram/UI use exactly the values persisted in DB.
        event["atr_percentile_200"]=atr_q200
        event["atr_percentile_500"]=atr_q500
        event["trigger_directional_move_pct"]=trigger_move
        event["trigger_move_atr_ratio"]=extension
        payload=json.dumps(event,ensure_ascii=False,allow_nan=False)
        cur=db.execute("""INSERT INTO volume_episodes
          (symbol,direction,started_at,start_window_open,status,last_observation_at,last_predicted_vr,peak_predicted_vr,
           peak_actual_vr,last_actual_vr,peak_episode_actual_vr,payload)
          VALUES(?,?,?,?, 'ACTIVE',?,?,?,?,?,?,?)""",
          (event["symbol"],event["direction"],now,event["bar_15m_open_at"],event["observation_at"],event["vr_live_actual"],
           event["vr_live_actual"],event["vr_live_actual"],event["vr_live_actual"],event["vr_live_actual"],payload))
        episode_id=int(cur.lastrowid)
        acur=db.execute("""INSERT INTO volume_alerts
          (created_at,window_open,observation_at,symbol,direction,model,volume_state,trigger_price,
           vr10_now,vr10_projected,prev_vr10_projected,atr_pct,vpe_atr,vpe_raw,close_location,directional_close_location,
           quote_volume_24h,payload,notified,episode_id,elapsed_minutes,actual_vr_at_trigger,predicted_vr_at_trigger,
           confirmation_status,final_actual_vr15,confirmed_at,tracking_v45,signal_engine_version,tracking_version,
           source_signal_engine_version,tracking_engine_version,execution_engine_version,atr_percentile_200,atr_percentile_500,
           trigger_directional_move_pct,trigger_move_atr_ratio,market_state_status,market_state_direction_score,market_state_stress_score)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (now,event["bar_15m_open_at"],event["observation_at"],event["symbol"],event["direction"],"MODEL_A",event["volume_state"],event["price"],
           event["vr_live_actual"],event["vr_live_actual"],event.get("prev_live_vr",0),atr,event.get("vpe_atr",0),event.get("vpe_raw",0),
           event.get("close_location",.5),directional_clv,event["quote_volume_24h"],payload,0,episode_id,event["elapsed_minutes"],
           event["vr_live_actual"],event["vr_live_actual"],trigger_status,final_vr,now if trigger_status=="CONFIRMED" else None,1,
           ENGINE_VERSION,TRACKING_VERSION,ENGINE_VERSION,TRACKING_ENGINE_VERSION,EXECUTION_ENGINE_VERSION,atr_q200,atr_q500,
           trigger_move,extension,ms.get("status","UNKNOWN"),ms.get("direction_score"),ms.get("stress_score")))
        alert_id=int(acur.lastrowid)
        _register_lifecycle_db(db,"MODEL_A",alert_id,event["symbol"],event["direction"],event["observation_at"],event["price"],ENGINE_VERSION)
        _freeze_market_context_db(db,"MODEL_A",alert_id,event["symbol"],event["direction"],event["observation_at"],ms,br,tr,ENGINE_VERSION)
        _register_trigger_point_db(db,"MODEL_A",alert_id,event["symbol"],event["direction"],event["observation_at"],event["price"],ENGINE_VERSION)
        if int(event.get("elapsed_minutes",0))==15:
            db.execute("UPDATE volume_alerts SET persistence_15m_close_pct=0 WHERE id=?",(alert_id,))
        if notification:
            title, body = notification
            db.execute("""INSERT OR IGNORE INTO notification_outbox
                (alert_id,title,body,status,attempts,next_attempt,created_at) VALUES(?,?,?,'pending',0,0,?)""",
                (-(1_000_000_000_000+alert_id),title,body,now))
        db.execute("UPDATE volume_episodes SET trigger_alert_id=? WHERE id=?",(alert_id,episode_id)); db.commit()
        return episode_id,alert_id


async def record_volume_observation(event, episode_id, volume_state):
    payload=json.dumps(event,ensure_ascii=False,allow_nan=False)
    with _LOCK,_connect() as db:
        directional_clv = float(event.get("directional_close_location", event.get("close_location", .5)))
        db.execute("""INSERT OR REPLACE INTO volume_observations
          (created_at,episode_id,symbol,window_open,observation_at,elapsed_minutes,volume_state,actual_vr,predicted_vr,
           recent_1m_rate,cumulative_base_volume,baseline_base_volume,price,return_live_pct,atr_pct,
           vpe_atr,vpe_raw,close_location,directional_close_location,payload)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (time.time(),episode_id,event["symbol"],event["bar_15m_open_at"],event["observation_at"],event["elapsed_minutes"],volume_state,
           event["vr_live_actual"],event["vr_live_actual"],event.get("delta_vr_live",0)*event["baseline_base_volume_15m"],event["base_volume_live"],
           event["baseline_base_volume_15m"],event["price"],event["return_live_pct"],event["atr_14_5m_pct"],
           event.get("vpe_atr",0),event.get("vpe_raw",0),event.get("close_location",.5),directional_clv,payload)); db.commit()


async def update_volume_episode(episode_id,event,volume_state,below_reset_windows=None):
    payload=json.dumps({**event,"volume_state":volume_state},ensure_ascii=False,allow_nan=False)
    with _LOCK,_connect() as db:
        row=db.execute("SELECT peak_actual_vr,peak_episode_actual_vr,below_reset_windows FROM volume_episodes WHERE id=?",(episode_id,)).fetchone()
        if not row:return
        brw=int(row["below_reset_windows"] if below_reset_windows is None else below_reset_windows)
        peak=max(float(row["peak_episode_actual_vr"] or row["peak_actual_vr"] or 0),float(event["vr_live_actual"]))
        db.execute("""UPDATE volume_episodes SET last_observation_at=?,last_predicted_vr=?,peak_predicted_vr=?,peak_actual_vr=?,
                     last_actual_vr=?,peak_episode_actual_vr=?,below_reset_windows=?,payload=? WHERE id=?""",
          (event["observation_at"],event["vr_live_actual"],peak,peak,event["vr_live_actual"],peak,brw,payload,episode_id)); db.commit()


async def finalize_trigger_actual(episode_id, window_open, final_actual_vr, threshold):
    # Under actual-volume triggering, a complete window is factual confirmation.
    status="CONFIRMED" if float(final_actual_vr)>=float(threshold) else "BELOW_TRIGGER_AT_CLOSE"
    now=time.time()
    with _LOCK,_connect() as db:
        db.execute("""UPDATE volume_alerts SET confirmation_status=?,final_actual_vr15=?,confirmed_at=?
                      WHERE episode_id=? AND window_open=?""",(status,float(final_actual_vr),now,episode_id,window_open)); db.commit()
    return status


async def mark_pending_confirmations_incomplete(cutoff_window_open):
    with _LOCK,_connect() as db:
        db.execute("""UPDATE volume_alerts SET confirmation_status='INCOMPLETE_DATA',confirmed_at=?
                      WHERE confirmation_status='PENDING' AND window_open<?""",(time.time(),float(cutoff_window_open))); db.commit()


def _quantile(values, q):
    xs=sorted(float(x) for x in values if x is not None)
    if not xs: return None
    if len(xs)==1: return xs[0]
    pos=(len(xs)-1)*float(q); lo=int(pos); hi=min(lo+1,len(xs)-1); frac=pos-lo
    return xs[lo]*(1-frac)+xs[hi]*frac


async def pending_persistence_alerts(observation_at, max_age_minutes=6):
    lo=float(observation_at)-max_age_minutes*60
    with _LOCK,_connect() as db:
        rows=db.execute("""SELECT id,symbol,direction,trigger_price,window_open,observation_at,
                                  persistence_1m_pct,persistence_2m_pct,persistence_3m_pct,persistence_5m_pct,
                                  persistence_15m_close_pct,persistence_next_15m_close_pct,
                                  atr_pct,vpe_atr,vpe_raw,directional_close_location,actual_vr_at_trigger,
                                  market_spike_count_1m,market_spike_risk,
                                  atr_percentile_200,atr_percentile_500,trigger_directional_move_pct,trigger_move_atr_ratio,
                                  persistence_state,a_plus_plus_trend,a_plus_plus_persistence,
                                  market_state_status,market_state_direction_score,market_state_stress_score,
                                  high_quality_confirmed,dynamic_q75_confirmed,dynamic_q80_confirmed
                           FROM volume_alerts WHERE observation_at>=? AND observation_at<?""",(lo,float(observation_at))).fetchall()
    return [dict(r) for r in rows]


def _persistence_state(p1,p3,p5):
    if p1 is None: return "PENDING"
    if float(p1) <= 0: return "P1_FAIL"
    if p3 is None: return "P1_PASS"
    if float(p3) <= float(p1): return "P3_WEAKENING"
    if p5 is None: return "TREND_ESTABLISHED"
    if float(p5) > float(p3): return "TREND_PERSISTENCE"
    return "P5_WEAKENING"


async def update_persistence(alert_id, minute_no, directional_return_pct):
    if int(minute_no) not in (1,2,3,5): return None
    col=f"persistence_{int(minute_no)}m_pct"; alert_id=int(alert_id)
    with _LOCK,_connect() as db:
        db.execute(f"UPDATE volume_alerts SET {col}=COALESCE({col},?) WHERE id=?",(float(directional_return_pct),alert_id))
        r=db.execute("""SELECT persistence_1m_pct,persistence_3m_pct,persistence_5m_pct,high_quality_confirmed,
                               a_plus_plus_trend,a_plus_plus_persistence FROM volume_alerts WHERE id=?""",(alert_id,)).fetchone()
        if not r: db.commit(); return None
        p1,p3,p5=r[0],r[1],r[2]; state=_persistence_state(p1,p3,p5)
        old_t=int(r[4] or 0); old_p=int(r[5] or 0); fixed=int(r[3] or 0)==1
        trend=1 if fixed and p1 is not None and p3 is not None and float(p3)>float(p1) else old_t
        persist=1 if fixed and None not in (p1,p3,p5) and 0<float(p1)<float(p3)<float(p5) else old_p
        confirmed_at=time.time() if (persist and not old_p) or (trend and not old_t) else None
        db.execute("""UPDATE volume_alerts SET persistence_state=?,a_plus_plus_trend=?,a_plus_plus_persistence=?,
                     a_plus_plus_confirmed_at=COALESCE(a_plus_plus_confirmed_at,?) WHERE id=?""",
                   (state,trend,persist,confirmed_at,alert_id)); db.commit()
        return {"state":state,"p1":p1,"p3":p3,"p5":p5,"new_trend":bool(trend and not old_t),
                "new_persistence":bool(persist and not old_p),"trend":bool(trend),"persistence":bool(persist)}


async def set_confirmation_entry_price(alert_id, price, confirmed_at):
    with _LOCK,_connect() as db:
        db.execute("""UPDATE volume_alerts SET a_plus_confirm_price=COALESCE(a_plus_confirm_price,?),
                     a_plus_confirm_at=COALESCE(a_plus_confirm_at,?) WHERE id=?""",
                   (float(price),float(confirmed_at),int(alert_id)))
        db.execute("""UPDATE signal_lifecycle SET confirmation_entry_price=COALESCE(confirmation_entry_price,?),
                     confirmation_entry_at=COALESCE(confirmation_entry_at,?) WHERE source_type='MODEL_A' AND source_id=?""",
                   (float(price),float(confirmed_at),int(alert_id)))
        db.commit()


async def update_close_persistence(alert_id, which, directional_return_pct):
    col={"CURRENT":"persistence_15m_close_pct","NEXT":"persistence_next_15m_close_pct"}.get(str(which).upper())
    if not col: return
    with _LOCK,_connect() as db:
        db.execute(f"UPDATE volume_alerts SET {col}=COALESCE({col},?) WHERE id=?",(float(directional_return_pct),int(alert_id))); db.commit()


async def pending_close_persistence_alerts(observation_at):
    t=float(observation_at)
    with _LOCK,_connect() as db:
        rows=db.execute("""SELECT id,symbol,direction,trigger_price,window_open,observation_at,
                                  persistence_15m_close_pct,persistence_next_15m_close_pct
                           FROM volume_alerts
                           WHERE (persistence_15m_close_pct IS NULL AND window_open+900=?)
                              OR (persistence_next_15m_close_pct IS NULL AND window_open+1800=?)""",(t,t)).fetchall()
    return [dict(r) for r in rows]


async def rolling_a_plus_thresholds(before_alert_id, window, min_samples, quantile):
    with _LOCK,_connect() as db:
        rows=db.execute("""SELECT atr_pct,persistence_1m_pct FROM volume_alerts
                           WHERE id<? AND persistence_1m_pct IS NOT NULL
                           ORDER BY id DESC LIMIT ?""",(int(before_alert_id),int(window))).fetchall()
    if len(rows)<int(min_samples): return None
    atr_q=_quantile([r["atr_pct"] for r in rows],quantile)
    p1_q=_quantile([r["persistence_1m_pct"] for r in rows],quantile)
    if atr_q is None or p1_q is None: return None
    return {"atr":float(atr_q),"p1":float(p1_q),"n":len(rows)}


async def mark_dynamic_q75(alert_id, atr_threshold, p1_threshold):
    with _LOCK,_connect() as db:
        db.execute("""UPDATE volume_alerts SET dynamic_q75_confirmed=1,dynamic_q75_atr_threshold=?,dynamic_q75_p1_threshold=?
                      WHERE id=? AND COALESCE(dynamic_q75_confirmed,0)=0""",(float(atr_threshold),float(p1_threshold),int(alert_id))); db.commit()


async def mark_dynamic_q80(alert_id, atr_threshold, p1_threshold):
    with _LOCK,_connect() as db:
        db.execute("""UPDATE volume_alerts SET dynamic_q80_confirmed=1,dynamic_q80_atr_threshold=?,dynamic_q80_p1_threshold=?
                      WHERE id=? AND COALESCE(dynamic_q80_confirmed,0)=0""",(float(atr_threshold),float(p1_threshold),int(alert_id))); db.commit()


async def set_market_spike_count(alert_ids, count):
    ids=[int(x) for x in alert_ids if x is not None]
    if not ids: return
    marks=','.join('?' for _ in ids)
    risk=_spike_risk(count)
    with _LOCK,_connect() as db:
        db.execute(f"UPDATE volume_alerts SET market_spike_count_1m=?,market_spike_risk=?,systemic_market_shock=? WHERE id IN ({marks})",
                   [int(count),risk,1 if risk=="EXTREME" else 0,*ids]); db.commit()



def _directional_bar_returns(trigger_price, direction, high, low, close):
    d=1.0 if direction=="LONG" else -1.0
    fav_price=float(high) if d>0 else float(low)
    adv_price=float(low) if d>0 else float(high)
    fav=(fav_price/float(trigger_price)-1.0)*100.0*d
    adv=(adv_price/float(trigger_price)-1.0)*100.0*d
    ret=(float(close)/float(trigger_price)-1.0)*100.0*d
    return fav,adv,ret


async def update_lifecycle_live(observation_at, bars_by_symbol):
    """Track trigger-entry lifecycle and persist the V4.7.1 4H signal path.

    Path cadence: every minute through 60m, then every 5m through 240m.
    No market-state data is attached after the trigger-time snapshot.
    """
    t=float(observation_at); horizon=SIGNAL_PATH_HORIZON_MINUTES
    with _LOCK,_connect() as db:
        rows=db.execute("""SELECT * FROM signal_lifecycle WHERE completed=0 AND trigger_at<? AND trigger_at+? >= ?""",
                        (t,horizon*60,t)).fetchall()
        for r in rows:
            bar=bars_by_symbol.get(r["symbol"])
            if not bar: continue
            if r["last_observation_at"] and t <= float(r["last_observation_at"]): continue
            elapsed=int(round((t-float(r["trigger_at"]))/60.0))
            if elapsed<=0 or elapsed>horizon: continue
            fav,adv,ret=_directional_bar_returns(r["trigger_price"],r["direction"],bar["high"],bar["low"],bar["close"])
            old_mfe=float(r["running_mfe_pct"] or 0); mfe=max(old_mfe,fav); mae=min(float(r["running_mae_pct"] or 0),adv)
            peak_at=float(r["running_mfe_at"]) if r["running_mfe_at"] is not None else None
            ttm=float(r["time_to_mfe_minutes"]) if r["time_to_mfe_minutes"] is not None else None
            if fav>old_mfe:
                peak_at=t; ttm=float(elapsed)
            giveback=mfe-ret; giveback_ratio=(giveback/mfe) if mfe>1e-12 else None
            _insert_signal_path_point_db(db,r["source_type"],r["source_id"],r["symbol"],r["direction"],r["trigger_at"],t,elapsed,
                                         bar["close"],ret,mfe,mae,giveback,giveback_ratio,r["source_signal_engine_version"] or r["signal_engine_version"] or "legacy")
            sets=["last_observation_at=?","running_mfe_pct=?","running_mae_pct=?","running_mfe_at=?","time_to_mfe_minutes=?",
                  "current_return_pct=?","giveback_pct=?","giveback_ratio=?","tracking_engine_version=?"]
            vals=[t,mfe,mae,peak_at,ttm,ret,giveback,giveback_ratio,TRACKING_ENGINE_VERSION]
            for threshold,col in ((1,"first_plus_1_min"),(2,"first_plus_2_min"),(3,"first_plus_3_min"),(5,"first_plus_5_min")):
                if fav>=threshold: sets.append(f"{col}=COALESCE({col},?)"); vals.append(float(elapsed))
            for threshold,col in ((-1,"first_minus_1_min"),(-1.5,"first_minus_1_5_min"),(-2,"first_minus_2_min")):
                if adv<=threshold: sets.append(f"{col}=COALESCE({col},?)"); vals.append(float(elapsed))
            if elapsed in LIFECYCLE_HORIZONS:
                sets += [f"return_{elapsed}m=COALESCE(return_{elapsed}m,?)",f"mfe_{elapsed}m=COALESCE(mfe_{elapsed}m,?)",f"mae_{elapsed}m=COALESCE(mae_{elapsed}m,?)"]
                vals += [ret,mfe,mae]
            # Completion is certified by contiguous REST reconciliation, not a lone T+240 tick.
            vals += [int(r["id"])]
            db.execute(f"UPDATE signal_lifecycle SET {','.join(sets)} WHERE id=?",vals)
        db.commit()


def _normalize_raw_bars(raw, trigger_at, horizon_minutes):
    start=float(trigger_at); end=start+int(horizon_minutes)*60
    bars=[]
    for row in raw or []:
        ts=float(row[0])/1000.0
        if ts < start-0.001 or ts >= end-0.001: continue
        bars.append({"ts":ts,"high":float(row[2]),"low":float(row[3]),"close":float(row[4])})
    bars.sort(key=lambda x:x["ts"])
    return bars


def _fixed_tp_sl(bars, trigger_price, direction, tp, sl):
    for b in bars:
        fav,adv,_=_directional_bar_returns(trigger_price,direction,b["high"],b["low"],b["close"])
        # Conservative intraminute rule: if both can be touched in one 1m bar, adverse stop is assumed first.
        if adv<=-float(sl): return -float(sl),"SL",b["ts"]
        if fav>=float(tp): return float(tp),"TP",b["ts"]
    if not bars: return 0.0,"NO_DATA",None
    _,_,ret=_directional_bar_returns(trigger_price,direction,bars[-1]["high"],bars[-1]["low"],bars[-1]["close"])
    return ret,"TIME_240",bars[-1]["ts"]+60


def _break_even_after_2(bars, trigger_price, direction):
    armed=False; initial_sl=1.0
    for b in bars:
        fav,adv,_=_directional_bar_returns(trigger_price,direction,b["high"],b["low"],b["close"])
        stop=0.0 if armed else -initial_sl
        if adv<=stop: return stop,"BE_STOP" if armed else "SL",b["ts"]
        if not armed and fav>=2.0:
            armed=True
            if adv<=0.0: return 0.0,"BE_SAME_BAR_CONSERVATIVE",b["ts"]
    if not bars:return 0.0,"NO_DATA",None
    _,_,ret=_directional_bar_returns(trigger_price,direction,bars[-1]["high"],bars[-1]["low"],bars[-1]["close"])
    return ret,"TIME_240",bars[-1]["ts"]+60


def _trailing(bars, trigger_price, direction, activate, distance, initial_stop):
    active=False; peak=0.0
    for b in bars:
        fav,adv,_=_directional_bar_returns(trigger_price,direction,b["high"],b["low"],b["close"])
        if not active:
            if adv<=-float(initial_stop): return -float(initial_stop),"SL",b["ts"]
            if fav>=float(activate):
                active=True; peak=max(float(activate),fav)
                # Stop adjustment takes effect next minute: intrabar high/low order is unknown.
        else:
            stop=peak-float(distance)
            if adv<=stop: return stop,"TRAIL",b["ts"]
            # A new high adjusts the stop for the next candle; OHLC cannot order the intrabar extremes.
            peak=max(peak,fav)
    if not bars:return 0.0,"NO_DATA",None
    _,_,ret=_directional_bar_returns(trigger_price,direction,bars[-1]["high"],bars[-1]["low"],bars[-1]["close"])
    return ret,"TIME_240",bars[-1]["ts"]+60


def _partial_2_3_trail(bars, trigger_price, direction):
    realized=0.0; remaining=1.0; hit2=False; hit3=False; active=False; peak=0.0; initial_stop=1.5; distance=1.5
    for b in bars:
        fav,adv,_=_directional_bar_returns(trigger_price,direction,b["high"],b["low"],b["close"])
        stop=(peak-distance) if active else -initial_stop
        if remaining>0 and adv<=stop:
            realized += remaining*stop
            return realized,"PARTIAL_TRAIL" if active else "SL",b["ts"]
        if not hit2 and fav>=2.0:
            hit2=True; realized += .30*2.0; remaining-=.30
        if not hit3 and fav>=3.0:
            hit3=True; realized += .30*3.0; remaining-=.30; active=True; peak=max(3.0,fav)
        elif active:
            peak=max(peak,fav)
    if not bars:return 0.0,"NO_DATA",None
    _,_,ret=_directional_bar_returns(trigger_price,direction,bars[-1]["high"],bars[-1]["low"],bars[-1]["close"])
    realized += remaining*ret
    return realized,"TIME_240",bars[-1]["ts"]+60


def _execution_strategies_from_bars(bars, trigger_price, direction):
    out={}
    for name,tp,sl in (("TP2_SL1",2,1),("TP3_SL1_5",3,1.5),("TP5_SL2",5,2)):
        out[name]=_fixed_tp_sl(bars,trigger_price,direction,tp,sl)
    out["BE_AFTER_2"]=_break_even_after_2(bars,trigger_price,direction)
    out["TRAIL_A2_D1"]=_trailing(bars,trigger_price,direction,float(config.execution_trail_activate_pct),float(config.execution_trail_distance_pct),float(config.execution_initial_stop_pct))
    out["TRAIL_A3_D1_5"]=_trailing(bars,trigger_price,direction,3.0,1.5,float(config.execution_initial_stop_pct))
    out["PARTIAL_2_3_TRAIL"]=_partial_2_3_trail(bars,trigger_price,direction)
    for m in (15,30,45,60,90,120,240):
        if len(bars)>=m:
            _,_,ret=_directional_bar_returns(trigger_price,direction,bars[m-1]["high"],bars[m-1]["low"],bars[m-1]["close"])
            out[f"TIME_{m}M"]=(ret,f"TIME_{m}M",bars[m-1]["ts"]+60)
    return out


def _reconcile_lifecycle_and_execution_db(db, source_type, source_id, symbol, direction, trigger_at, trigger_price, raw):
    if str(source_type) != "MODEL_A":
        return
    horizon=SIGNAL_PATH_HORIZON_MINUTES
    all_bars=_normalize_raw_bars(raw,trigger_at,horizon+10)
    by_time={b["ts"]:b for b in all_bars}
    bars=[by_time.get(float(trigger_at)+i*60) for i in range(horizon)]
    # Never compress gaps into adjacent elapsed minutes or certify incomplete execution results.
    if any(b is None for b in bars): return
    if not bars:return
    src=db.execute("""SELECT source_signal_engine_version,a_plus_confirm_price,a_plus_confirm_at,
                             high_quality_confirmed,dynamic_q75_confirmed,dynamic_q80_confirmed
                      FROM volume_alerts WHERE id=?""",(int(source_id),)).fetchone()
    if not src:return
    source_version=(src[0] if src[0] else ENGINE_VERSION)
    confirm_price=float(src[1]) if src[1] is not None else None
    confirm_at=float(src[2]) if src[2] is not None else None
    is_aplus=bool(any(int(src[i] or 0) for i in (3,4,5)))

    _register_trigger_point_db(db,"MODEL_A",source_id,symbol,direction,trigger_at,trigger_price,source_version)
    running_mfe=0.0; running_mae=0.0; checkpoints={}; peak_at=None; ttm=None
    targets={"first_plus_1_min":None,"first_plus_2_min":None,"first_plus_3_min":None,"first_plus_5_min":None,
             "first_minus_1_min":None,"first_minus_1_5_min":None,"first_minus_2_min":None}
    current_ret=0.0
    for i,b in enumerate(bars,1):
        fav,adv,ret=_directional_bar_returns(trigger_price,direction,b["high"],b["low"],b["close"]); current_ret=ret
        if fav>running_mfe: running_mfe=fav; peak_at=b["ts"]+60; ttm=float(i)
        running_mae=min(running_mae,adv)
        point_giveback=running_mfe-ret; point_ratio=point_giveback/running_mfe if running_mfe>1e-12 else None
        _insert_signal_path_point_db(db,"MODEL_A",source_id,symbol,direction,trigger_at,b["ts"]+60,i,b["close"],ret,
                                     running_mfe,running_mae,point_giveback,point_ratio,source_version)
        for th,col in ((1,"first_plus_1_min"),(2,"first_plus_2_min"),(3,"first_plus_3_min"),(5,"first_plus_5_min")):
            if targets[col] is None and fav>=th: targets[col]=float(i)
        for th,col in ((-1,"first_minus_1_min"),(-1.5,"first_minus_1_5_min"),(-2,"first_minus_2_min")):
            if targets[col] is None and adv<=th: targets[col]=float(i)
        if i in LIFECYCLE_HORIZONS: checkpoints[i]=(ret,running_mfe,running_mae)
    giveback=running_mfe-current_ret; giveback_ratio=giveback/running_mfe if running_mfe>1e-12 else None
    _register_lifecycle_db(db,"MODEL_A",source_id,symbol,direction,trigger_at,trigger_price,source_version)
    sets=["last_observation_at=?","running_mfe_pct=?","running_mae_pct=?","running_mfe_at=?","time_to_mfe_minutes=?",
          "current_return_pct=?","giveback_pct=?","giveback_ratio=?","tracking_engine_version=?","source_signal_engine_version=?",
          "execution_engine_version=?","confirmation_entry_price=COALESCE(confirmation_entry_price,?)",
          "confirmation_entry_at=COALESCE(confirmation_entry_at,?)"]
    vals=[bars[-1]["ts"]+60,running_mfe,running_mae,peak_at,ttm,current_ret,giveback,giveback_ratio,
          TRACKING_ENGINE_VERSION,source_version,EXECUTION_ENGINE_VERSION,confirm_price,confirm_at]
    for col,val in targets.items(): sets.append(f"{col}=?"); vals.append(val)
    for m,(ret,mfe,mae) in checkpoints.items():
        sets += [f"return_{m}m=?",f"mfe_{m}m=?",f"mae_{m}m=?"]; vals += [ret,mfe,mae]
    if len(bars)>=horizon:
        sets += ["completed=1","completed_at=?"]; vals += [bars[horizon-1]["ts"]+60]
    vals += ["MODEL_A",int(source_id)]
    db.execute(f"UPDATE signal_lifecycle SET {','.join(sets)} WHERE source_type=? AND source_id=?",vals)

    if len(bars)>=horizon:
        cost=_round_trip_cost_pct()
        def persist(entry_mode,prefix,ebars,eprice,eat):
            for strategy,(gross,reason,exit_at) in _execution_strategies_from_bars(ebars,eprice,direction).items():
                key=prefix+strategy
                meta=json.dumps({"cost_pct":cost,"intraminute_rule":"adverse_first_when_ambiguous","entry_mode":entry_mode},ensure_ascii=False)
                db.execute("""INSERT INTO signal_execution_results
                  (source_type,source_id,strategy,direction,gross_return_pct,net_return_pct,exit_reason,exit_at,metadata,
                   entry_mode,entry_price,entry_at,source_signal_engine_version,tracking_engine_version,execution_engine_version,created_at)
                  VALUES('MODEL_A',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                  ON CONFLICT(source_type,source_id,strategy) DO UPDATE SET gross_return_pct=excluded.gross_return_pct,
                    net_return_pct=excluded.net_return_pct,exit_reason=excluded.exit_reason,exit_at=excluded.exit_at,metadata=excluded.metadata,
                    entry_mode=excluded.entry_mode,entry_price=excluded.entry_price,entry_at=excluded.entry_at,
                    source_signal_engine_version=excluded.source_signal_engine_version,tracking_engine_version=excluded.tracking_engine_version,
                    execution_engine_version=excluded.execution_engine_version,created_at=excluded.created_at""",
                  (int(source_id),key,direction,float(gross),float(gross)-cost,reason,exit_at,meta,entry_mode,float(eprice),
                   float(eat),source_version,TRACKING_ENGINE_VERSION,EXECUTION_ENGINE_VERSION,time.time()))
        persist("ENTRY_TRIGGER","",bars[:horizon],float(trigger_price),float(trigger_at))
        if is_aplus and confirm_price is not None and confirm_at is not None:
            cbars=[b for b in all_bars if b["ts"]>=confirm_at][:horizon]
            if len(cbars)==horizon and [b["ts"] for b in cbars]==[confirm_at+i*60 for i in range(horizon)]:
                persist("ENTRY_A_PLUS_CONFIRM","CONFIRM__",cbars,confirm_price,confirm_at)
        # Compact archive is the durable research layer; raw path storage can be pruned later.
        try:
            archive_completed_signal(db,int(source_id))
        except Exception:
            pass


async def recent_signal_lifecycle(limit=100):
    limit=max(1,min(int(limit),500))
    with _LOCK,_connect() as db:
        rows=db.execute("""SELECT l.*,va.actual_vr_at_trigger AS actual_vr,va.high_quality_confirmed AS fixed_a_plus,va.dynamic_q75_confirmed AS q75_a_plus,
          va.dynamic_q80_confirmed AS q80_a_plus,va.market_spike_risk,va.persistence_state,va.a_plus_plus_trend,
          va.a_plus_plus_persistence,va.atr_percentile_200,va.trigger_move_atr_ratio,
          c.market_state_status AS initial_market_state,c.market_direction_score AS initial_direction_score,
          c.market_stress_score AS initial_stress_score,c.breadth_status,c.breadth_score,c.session_up_pct,c.session_down_pct,
          c.median_session_return_pct,c.bb_1h_position,c.bb_4h_position,c.bb_trend_context,c.trend_alignment,
          c.context_age_seconds AS market_context_age_seconds,
          (SELECT COUNT(*) FROM signal_path_points p WHERE p.source_type='MODEL_A' AND p.source_id=l.source_id) AS path_points
          FROM signal_lifecycle l JOIN volume_alerts va ON va.id=l.source_id
          LEFT JOIN signal_market_context c ON c.source_type='MODEL_A' AND c.source_id=l.source_id
          WHERE l.source_type='MODEL_A' ORDER BY l.trigger_at DESC LIMIT ?""",(limit,)).fetchall()
    return [dict(r) for r in rows]


async def signal_path(source_type, source_id):
    if str(source_type or "").upper() != "MODEL_A":
        return {"signal":None,"context":None,"points":[]}
    source_id=int(source_id)
    with _LOCK,_connect() as db:
        life=db.execute("SELECT * FROM signal_lifecycle WHERE source_type='MODEL_A' AND source_id=?",(source_id,)).fetchone()
        context=db.execute("SELECT * FROM signal_market_context WHERE source_type='MODEL_A' AND source_id=?",(source_id,)).fetchone()
        points=db.execute("""SELECT elapsed_minutes,observed_at,sample_interval_minutes,close_price,return_pct,running_mfe_pct,
                                    running_mae_pct,giveback_pct,giveback_ratio,source_signal_engine_version,tracking_engine_version
                             FROM signal_path_points WHERE source_type='MODEL_A' AND source_id=? AND elapsed_minutes<=?
                             ORDER BY elapsed_minutes""",(source_id,SIGNAL_PATH_HORIZON_MINUTES)).fetchall()
        src=db.execute("""SELECT symbol,direction,observation_at AS signal_at,trigger_price,high_quality_confirmed,
                                 a_plus_plus_trend,a_plus_plus_persistence,market_spike_risk,atr_percentile_200
                          FROM volume_alerts WHERE id=?""",(source_id,)).fetchone()
    ctx=dict(context) if context else None
    if ctx:
        try: ctx["details"]=json.loads(ctx.pop("payload"))
        except Exception: ctx["details"]={}
    return {"signal":dict(src) if src else (dict(life) if life else None),"lifecycle":dict(life) if life else None,
            "context":ctx,"points":[dict(r) for r in points],"horizon_minutes":SIGNAL_PATH_HORIZON_MINUTES}


def _direction_score_bucket(v):
    if v is None: return "UNKNOWN"
    v=float(v)
    if v < -60: return "-100~-60"
    if v < -20: return "-60~-20"
    if v < 20: return "-20~+20"
    if v < 60: return "+20~+60"
    return "+60~+100"


def _stress_score_bucket(v):
    if v is None: return "UNKNOWN"
    v=float(v)
    if v < 30: return "0~30"
    if v < 50: return "30~50"
    if v < 70: return "50~70"
    return "70~100"


def _truth_metrics(rows):
    if not rows: return {}
    def avg(col):
        xs=[float(r[col]) for r in rows if r[col] is not None]
        return sum(xs)/len(xs) if xs else None
    def before(pos_col,neg_col):
        n=0
        for r in rows:
            p=r[pos_col]; neg=r[neg_col]
            if p is not None and (neg is None or float(p)<float(neg)): n+=1
        return n/len(rows)
    return {"n":len(rows),"first1_before_minus1_rate":before("first_plus_1_min","first_minus_1_min"),
            "first2_before_minus1_rate":before("first_plus_2_min","first_minus_1_min"),
            "first3_before_minus1_5_rate":before("first_plus_3_min","first_minus_1_5_min"),
            "mfe_ge_3_rate":sum(float(r["running_mfe_pct"] or 0)>=3 for r in rows)/len(rows),
            "mfe_ge_5_rate":sum(float(r["running_mfe_pct"] or 0)>=5 for r in rows)/len(rows),
            "avg_mfe_pct":avg("running_mfe_pct"),"avg_mae_pct":avg("running_mae_pct"),
            "avg_return_60m":avg("return_60m"),"avg_return_120m":avg("return_120m"),"avg_return_240m":avg("return_240m"),
            "avg_time_to_mfe_min":avg("time_to_mfe_minutes"),"avg_giveback_pct":avg("giveback_pct"),
            "avg_direction_score":avg("initial_direction_score"),"avg_stress_score":avg("initial_stress_score")}


async def initial_context_research_stats():
    """Completed V4.8 Model-A outcomes grouped by frozen trigger-time context."""
    with _LOCK,_connect() as db:
        rows=db.execute("""SELECT l.*,c.market_state_status AS initial_market_state,
          c.market_direction_score AS initial_direction_score,c.market_stress_score AS initial_stress_score,
          c.breadth_status,c.breadth_score,c.session_up_pct,c.session_down_pct,c.median_session_return_pct,
          c.bb_1h_position,c.bb_4h_position,c.bb_trend_context,c.trend_alignment,
          va.high_quality_confirmed,va.a_plus_plus_trend,va.a_plus_plus_persistence
          FROM signal_lifecycle l JOIN signal_market_context c ON c.source_type='MODEL_A' AND c.source_id=l.source_id
          JOIN volume_alerts va ON va.id=l.source_id
          WHERE l.source_type='MODEL_A' AND l.completed=1 AND l.source_signal_engine_version=?
          ORDER BY l.trigger_at""",(ENGINE_VERSION,)).fetchall()
    state_groups={}; score_groups={}; breadth_groups={}; trend_groups={}; combined_groups={}
    for r in rows:
        quality=_quality_label(r); direction=r["direction"]; state=str(r["initial_market_state"] or "UNKNOWN")
        state_groups.setdefault((quality,direction,state),[]).append(r)
        dbu=_direction_score_bucket(r["initial_direction_score"]); sbu=_stress_score_bucket(r["initial_stress_score"])
        score_groups.setdefault((quality,direction,dbu,sbu),[]).append(r)
        breadth=str(r["breadth_status"] or "UNKNOWN"); trend=str(r["bb_trend_context"] or "UNKNOWN"); align=str(r["trend_alignment"] or "UNKNOWN")
        breadth_groups.setdefault((quality,direction,breadth),[]).append(r)
        trend_groups.setdefault((quality,direction,trend,align),[]).append(r)
        combined_groups.setdefault((quality,direction,breadth,trend),[]).append(r)
    def pack(groups,names):
        out=[]
        for key,rr in groups.items(): out.append({**dict(zip(names,key)),**_truth_metrics(rr)})
        return out
    return {"source_version":ENGINE_VERSION,"definition":{
              "first1":"+1% before -1%","first2":"+2% before -1%","first3":"+3% before -1.5%",
              "market_context":"trigger-time snapshot only","breadth_session":"00:00 UTC = 08:00 UTC+8",
              "bb_middle":"SMA20 of completed 1H/4H bars","outcome_horizon_minutes":SIGNAL_PATH_HORIZON_MINUTES},
            "state_groups":pack(state_groups,["quality","direction","initial_market_state"]),
            "score_groups":pack(score_groups,["quality","direction","direction_bucket","stress_bucket"]),
            "breadth_groups":pack(breadth_groups,["quality","direction","breadth_status"]),
            "trend_groups":pack(trend_groups,["quality","direction","bb_trend_context","trend_alignment"]),
            "breadth_trend_groups":pack(combined_groups,["quality","direction","breadth_status","bb_trend_context"])}


def _curve_rows_for_cohort(db, source_type, direction=None, quality="ALL"):
    where=["l.source_type=?","l.completed=1","l.source_signal_engine_version=?"]; params=[source_type,ENGINE_VERSION]
    if direction:
        where.append("l.direction=?"); params.append(direction)
    join=""
    if source_type=="MODEL_A":
        join=" JOIN volume_alerts va ON va.id=l.source_id "
        if quality=="FIXED": where.append("va.high_quality_confirmed=1")
        elif quality=="Q75": where.append("va.dynamic_q75_confirmed=1")
        elif quality=="Q80": where.append("va.dynamic_q80_confirmed=1")
        elif quality=="A++TREND": where.append("va.a_plus_plus_trend=1")
        elif quality=="A++PERSIST": where.append("va.a_plus_plus_persistence=1")
        elif quality=="SPIKE_NORMAL": where.append("va.market_spike_risk='NORMAL'")
    return db.execute(f"SELECT l.* FROM signal_lifecycle l {join} WHERE {' AND '.join(where)} ORDER BY l.trigger_at",params).fetchall()


async def return_curve_stats():
    out=[]
    with _LOCK,_connect() as db:
        cohorts=[("MODEL_A","ALL"),("MODEL_A","FIXED"),("MODEL_A","Q75"),("MODEL_A","Q80"),("MODEL_A","A++TREND"),("MODEL_A","A++PERSIST")]
        for source,quality in cohorts:
            for direction in ("LONG","SHORT"):
                rows=_curve_rows_for_cohort(db,source,direction,quality)
                if not rows: continue
                for m in LIFECYCLE_HORIZONS:
                    vals=[float(r[f"return_{m}m"]) for r in rows if r[f"return_{m}m"] is not None]
                    mfes=[float(r[f"mfe_{m}m"]) for r in rows if r[f"mfe_{m}m"] is not None]
                    maes=[float(r[f"mae_{m}m"]) for r in rows if r[f"mae_{m}m"] is not None]
                    if not vals: continue
                    sv=sorted(vals); med=sv[len(sv)//2] if len(sv)%2 else (sv[len(sv)//2-1]+sv[len(sv)//2])/2
                    out.append({"model":"MODEL_A","quality":quality,"direction":direction,"minute":m,"n":len(vals),
                                "avg_return_pct":sum(vals)/len(vals),"median_return_pct":med,
                                "positive_rate":sum(v>0 for v in vals)/len(vals),
                                "avg_mfe_pct":sum(mfes)/len(mfes) if mfes else 0.0,"avg_mae_pct":sum(maes)/len(maes) if maes else 0.0})
    return out


def _cohort_signal_ids(db, source_type, quality, direction):
    if source_type!="MODEL_A": return set()
    wh=["direction=?","source_signal_engine_version=?"]; params=[direction,ENGINE_VERSION]
    if quality=="FIXED":wh.append("high_quality_confirmed=1")
    elif quality=="Q75":wh.append("dynamic_q75_confirmed=1")
    elif quality=="Q80":wh.append("dynamic_q80_confirmed=1")
    elif quality=="A++TREND":wh.append("a_plus_plus_trend=1")
    elif quality=="A++PERSIST":wh.append("a_plus_plus_persistence=1")
    rows=db.execute(f"SELECT id FROM volume_alerts WHERE {' AND '.join(wh)}",params).fetchall()
    return {int(r[0]) for r in rows}


def _max_drawdown_and_streak(values):
    equity=0.0; peak=0.0; maxdd=0.0; streak=0; maxstreak=0
    for v in values:
        equity+=v; peak=max(peak,equity); maxdd=min(maxdd,equity-peak)
        if v<0: streak+=1; maxstreak=max(maxstreak,streak)
        else: streak=0
    return maxdd,maxstreak


async def execution_research_stats():
    out=[]; cost=_round_trip_cost_pct()
    with _LOCK,_connect() as db:
        all_rows=db.execute("""SELECT e.*,l.trigger_at FROM signal_execution_results e
                               JOIN signal_lifecycle l ON l.source_type='MODEL_A' AND l.source_id=e.source_id
                               WHERE e.source_type='MODEL_A' AND e.source_signal_engine_version=? ORDER BY l.trigger_at""",(ENGINE_VERSION,)).fetchall()
        cohorts=("ALL","FIXED","Q75","Q80","A++TREND","A++PERSIST")
        for quality in cohorts:
            for direction in ("LONG","SHORT"):
                ids=_cohort_signal_ids(db,"MODEL_A",quality,direction)
                subset=[r for r in all_rows if r["direction"]==direction and int(r["source_id"]) in ids]
                for strategy in sorted({r["strategy"] for r in subset}):
                    rr=[r for r in subset if r["strategy"]==strategy]
                    nets=[float(r["net_return_pct"]) for r in rr]; gross=[float(r["gross_return_pct"]) for r in rr]
                    if not nets: continue
                    pos=sum(v for v in nets if v>0); neg=-sum(v for v in nets if v<0); sv=sorted(nets)
                    med=sv[len(sv)//2] if len(sv)%2 else (sv[len(sv)//2-1]+sv[len(sv)//2])/2
                    dd,streak=_max_drawdown_and_streak(nets)
                    out.append({"model":"MODEL_A","quality":quality,"direction":direction,"strategy":strategy,
                                "entry_mode":rr[0]["entry_mode"],"n":len(nets),"win_rate":sum(v>0 for v in nets)/len(nets),
                                "avg_gross_pct":sum(gross)/len(gross),"avg_net_pct":sum(nets)/len(nets),"median_net_pct":med,
                                "profit_factor":pos/neg if neg>0 else (999.0 if pos>0 else 0.0),
                                "max_drawdown_pct":dd,"max_losing_streak":streak,"cost_pct":cost})
    return out


async def direction_comparison_stats():
    out=[]
    with _LOCK,_connect() as db:
        for direction in ("LONG","SHORT"):
            rows=db.execute("""SELECT va.*,l.return_30m,l.return_60m,l.return_120m,l.mfe_60m,l.mae_60m
                               FROM volume_alerts va LEFT JOIN signal_lifecycle l ON l.source_type='MODEL_A' AND l.source_id=va.id
                               WHERE va.tracking_ended=1 AND va.source_signal_engine_version=? AND va.direction=?""",(ENGINE_VERSION,direction)).fetchall()
            cohorts=(("ALL",lambda r:True),("FIXED",lambda r:int(r["high_quality_confirmed"] or 0)==1),
                     ("A++TREND",lambda r:int(r["a_plus_plus_trend"] or 0)==1),("A++PERSIST",lambda r:int(r["a_plus_plus_persistence"] or 0)==1))
            for quality,pred in cohorts:
                rr=[r for r in rows if pred(r)]
                if not rr:continue
                def avg(col):
                    xs=[float(r[col]) for r in rr if r[col] is not None]; return sum(xs)/len(xs) if xs else None
                out.append({"direction":direction,"quality":quality,"n":len(rr),
                            "first2_rate":sum(1 for r in rr if r["first_plus_2_at"] is not None and (r["first_minus_1_at"] is None or r["first_plus_2_at"]<r["first_minus_1_at"]))/len(rr),
                            "mfe3_rate":sum(float(r["mfe_pct"] or 0)>=3 for r in rr)/len(rr),"mfe5_rate":sum(float(r["mfe_pct"] or 0)>=5 for r in rr)/len(rr),
                            "avg_mfe_pct":avg("mfe_pct"),"avg_mae_pct":avg("mae_pct"),"avg_final_pct":avg("final_return_pct"),
                            "avg_return_30m":avg("return_30m"),"avg_return_60m":avg("return_60m"),"avg_return_120m":avg("return_120m")})
    return out

def _atr_position_bucket(q):
    if q is None: return "样本不足"
    q=float(q)
    if q < 25: return "Q0-25"
    if q < 50: return "Q25-50"
    if q < 75: return "Q50-75"
    if q < 90: return "Q75-90"
    return "Q90+"


def _quality_label(row):
    if int(row["a_plus_plus_persistence"] or 0): return "A++ Persistence"
    if int(row["a_plus_plus_trend"] or 0): return "A++ Trend"
    if int(row["high_quality_confirmed"] or 0): return "A+ Fixed"
    return "A Base"


async def context_research_matrix():
    """V4.8 Model-A-only research matrix with breadth and trend context."""
    with _LOCK,_connect() as db:
        rows=db.execute("""SELECT va.id,va.direction,va.high_quality_confirmed,va.a_plus_plus_trend,va.a_plus_plus_persistence,
          va.market_spike_risk,va.atr_percentile_200,va.persistence_state,
          c.market_state_status,c.breadth_status,c.bb_trend_context,c.trend_alignment,
          l.running_mfe_pct,l.running_mae_pct,l.time_to_mfe_minutes,l.giveback_pct,l.giveback_ratio,l.completed
          FROM volume_alerts va JOIN signal_lifecycle l ON l.source_type='MODEL_A' AND l.source_id=va.id
          LEFT JOIN signal_market_context c ON c.source_type='MODEL_A' AND c.source_id=va.id
          WHERE va.source_signal_engine_version=?""",(ENGINE_VERSION,)).fetchall()
        exec_rows=db.execute("""SELECT source_id,strategy,net_return_pct FROM signal_execution_results
          WHERE source_type='MODEL_A' AND source_signal_engine_version=? AND strategy IN ('TIME_60M','CONFIRM__TIME_60M')""",(ENGINE_VERSION,)).fetchall()
    ex={(int(r["source_id"]),r["strategy"]):float(r["net_return_pct"]) for r in exec_rows}; groups={}
    for r in rows:
        quality=_quality_label(r); preferred="CONFIRM__TIME_60M" if quality!="A Base" else "TIME_60M"
        key=(quality,r["direction"],r["market_state_status"] or "UNKNOWN",r["breadth_status"] or "UNKNOWN",
             r["bb_trend_context"] or "UNKNOWN",r["trend_alignment"] or "UNKNOWN",r["market_spike_risk"] or "NORMAL",
             _atr_position_bucket(r["atr_percentile_200"]),r["persistence_state"] or "PENDING")
        g=groups.setdefault(key,{"model":"MODEL_A","quality":quality,"direction":r["direction"],"market_state":key[2],
          "breadth_status":key[3],"bb_trend_context":key[4],"trend_alignment":key[5],"spike_risk":key[6],
          "atr_position":key[7],"persistence_state":key[8],"n":0,"mfe3":0,"mfe5":0,"mae":[],"peak":[],"giveback":[],"giveback_ratio":[],"net60":[]})
        g["n"]+=1; mfe=float(r["running_mfe_pct"] or 0); g["mfe3"]+=mfe>=3; g["mfe5"]+=mfe>=5
        if r["running_mae_pct"] is not None:g["mae"].append(float(r["running_mae_pct"]))
        if r["time_to_mfe_minutes"] is not None:g["peak"].append(float(r["time_to_mfe_minutes"]))
        if r["giveback_pct"] is not None:g["giveback"].append(float(r["giveback_pct"]))
        if r["giveback_ratio"] is not None:g["giveback_ratio"].append(float(r["giveback_ratio"]))
        net=ex.get((int(r["id"]),preferred))
        if net is not None:g["net60"].append(net)
    out=[]
    for g in groups.values():
        n=g["n"]; nets=g.pop("net60"); maes=g.pop("mae"); peaks=g.pop("peak"); givebacks=g.pop("giveback"); ratios=g.pop("giveback_ratio")
        pos=sum(x for x in nets if x>0); neg=-sum(x for x in nets if x<0)
        g.update({"mfe_ge_3_rate":g.pop("mfe3")/n if n else 0,"mfe_ge_5_rate":g.pop("mfe5")/n if n else 0,
          "avg_mae_pct":sum(maes)/len(maes) if maes else None,"avg_peak_time_min":sum(peaks)/len(peaks) if peaks else None,
          "avg_giveback_pct":sum(givebacks)/len(givebacks) if givebacks else None,
          "avg_giveback_ratio":sum(ratios)/len(ratios) if ratios else None,"execution_n_60m":len(nets),
          "avg_net_60m_pct":sum(nets)/len(nets) if nets else None,
          "profit_factor_60m":(pos/neg if neg>0 else (999.0 if pos>0 else None))})
        out.append(g)
    return sorted(out,key=lambda x:(x["quality"],x["direction"],x["breadth_status"],x["bb_trend_context"]))


async def confirm_high_quality_and_enqueue(alert_id, title, body, confirm_price=None, confirm_at=None):
    """Persist Fixed A+ and its executable confirmation entry exactly once."""
    now=time.time(); alert_id=int(alert_id); stable_key=-(2_000_000_000_000+alert_id)
    with _LOCK,_connect() as db:
        row=db.execute("SELECT COALESCE(high_quality_confirmed,0) AS hq FROM volume_alerts WHERE id=?",(alert_id,)).fetchone()
        if not row or int(row["hq"] or 0): return False
        db.execute("""UPDATE volume_alerts SET high_quality_confirmed=1,high_quality_confirmed_at=?,
                     a_plus_confirm_price=COALESCE(a_plus_confirm_price,?),a_plus_confirm_at=COALESCE(a_plus_confirm_at,?) WHERE id=?""",
                   (now,confirm_price,confirm_at,alert_id))
        if confirm_price is not None and confirm_at is not None:
            db.execute("""UPDATE signal_lifecycle SET confirmation_entry_price=COALESCE(confirmation_entry_price,?),
                         confirmation_entry_at=COALESCE(confirmation_entry_at,?) WHERE source_type='MODEL_A' AND source_id=?""",
                       (float(confirm_price),float(confirm_at),alert_id))
        exists=db.execute("SELECT id FROM notification_outbox WHERE alert_id=? LIMIT 1",(stable_key,)).fetchone()
        if not exists:
            db.execute("""INSERT INTO notification_outbox(alert_id,title,body,status,attempts,next_attempt,created_at)
                          VALUES(?,?,?,'pending',0,0,?)""",(stable_key,title,body,now))
        db.commit(); return True


async def enqueue_a_plus_plus_notification(alert_id, level, title, body):
    base=3_000_000_000_000 if str(level).upper()=="TREND" else 4_000_000_000_000
    return await enqueue_notification(-(base+int(alert_id)),title,body)


async def close_volume_episode(episode_id, reason):
    with _LOCK,_connect() as db:
        db.execute("UPDATE volume_episodes SET status='CLOSED',ended_at=?,end_reason=? WHERE id=?",(time.time(),str(reason),episode_id)); db.commit()


async def enqueue_notification(alert_id, title, body):
    now = time.time()
    with _LOCK, _connect() as db:
        exists = db.execute("SELECT id FROM notification_outbox WHERE alert_id=? LIMIT 1", (int(alert_id),)).fetchone()
        if exists:
            return int(exists["id"])
        cur = db.execute("""INSERT INTO notification_outbox(alert_id,title,body,status,attempts,next_attempt,created_at)
                            VALUES(?,?,?,'pending',0,0,?)""", (int(alert_id), title, body, now))
        db.commit()
        return int(cur.lastrowid)


async def enqueue_volume_notification(volume_alert_id, title, body):
    # Stable negative keyspace for Model-A Telegram notifications.
    stable_key = -(1_000_000_000_000 + int(volume_alert_id))
    return await enqueue_notification(stable_key, title, body)


async def enqueue_system_notification(stable_key, title, body):
    key = -abs(int(stable_key))
    if key == 0:
        key = -1
    return await enqueue_notification(key, title, body)








async def recent_volume_episodes(limit=100):
    limit=max(1,min(int(limit),500))
    with _LOCK,_connect() as db:
        rows=db.execute("SELECT * FROM volume_episodes ORDER BY started_at DESC LIMIT ?",(limit,)).fetchall()
    return [dict(r) for r in rows]


async def recent_volume_alerts(limit=100):
    limit = max(1, min(int(limit), 500))
    with _LOCK, _connect() as db:
        rows = db.execute("SELECT * FROM volume_alerts ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for r in rows:
        item = dict(r)
        try:
            item["details"] = json.loads(item.pop("payload"))
        except Exception:
            item["details"] = {}
        out.append(item)
    return out


async def volume_alert_stats():
    """Current-source Model-A research stats; old versions are excluded by default."""
    with _LOCK,_connect() as db:
        rows=db.execute("""
            SELECT direction,confirmation_status,COUNT(*) AS n,
              SUM(CASE WHEN first_plus_2_at IS NOT NULL AND (first_minus_1_at IS NULL OR first_plus_2_at < first_minus_1_at) THEN 1 ELSE 0 END) AS first2_win,
              SUM(CASE WHEN mfe_pct>=3 THEN 1 ELSE 0 END) AS mfe3,
              SUM(CASE WHEN mfe_pct>=5 THEN 1 ELSE 0 END) AS mfe5,
              AVG(mfe_pct) AS avg_mfe, AVG(mae_pct) AS avg_mae, AVG(final_return_pct) AS avg_final,
              AVG(atr_pct) AS avg_atr_pct, AVG(vpe_raw) AS avg_vpe_raw, AVG(vpe_atr) AS avg_vpe_atr,
              AVG(directional_close_location) AS avg_directional_clv,
              AVG(persistence_1m_pct) AS avg_persist_1m, AVG(persistence_3m_pct) AS avg_persist_3m,
              AVG(persistence_5m_pct) AS avg_persist_5m, AVG(actual_vr_at_trigger) AS avg_actual_trigger_vr,
              AVG(market_spike_count_1m) AS avg_spike_count,
              SUM(CASE WHEN high_quality_confirmed=1 THEN 1 ELSE 0 END) AS fixed_a_plus,
              SUM(CASE WHEN dynamic_q75_confirmed=1 THEN 1 ELSE 0 END) AS dynamic_a_plus,
              SUM(CASE WHEN dynamic_q80_confirmed=1 THEN 1 ELSE 0 END) AS dynamic_q80_plus,
              SUM(CASE WHEN a_plus_plus_trend=1 THEN 1 ELSE 0 END) AS a_plus_plus_trend,
              SUM(CASE WHEN a_plus_plus_persistence=1 THEN 1 ELSE 0 END) AS a_plus_plus_persistence,
              SUM(CASE WHEN market_spike_risk='HIGH' THEN 1 ELSE 0 END) AS spike_high,
              SUM(CASE WHEN market_spike_risk='EXTREME' THEN 1 ELSE 0 END) AS spike_extreme
            FROM volume_alerts WHERE tracking_ended=1 AND source_signal_engine_version=?
            GROUP BY direction,confirmation_status ORDER BY direction,confirmation_status
        """,(ENGINE_VERSION,)).fetchall()
    out=[]
    for r in rows:
        d=dict(r); n=int(d["n"] or 0); wins=int(d["first2_win"] or 0)
        d["first2_rate"]=wins/n if n else 0.0; d["mfe3_rate"]=int(d["mfe3"] or 0)/n if n else 0.0; d["mfe5_rate"]=int(d["mfe5"] or 0)/n if n else 0.0
        out.append(d)
    return out


async def research_dashboard_summary():
    with _LOCK,_connect() as db:
        a=db.execute("""SELECT COUNT(*) n,SUM(tracking_ended) mature,
          SUM(CASE WHEN high_quality_confirmed=1 THEN 1 ELSE 0 END) fixed_aplus,
          SUM(CASE WHEN dynamic_q75_confirmed=1 THEN 1 ELSE 0 END) dynamic_aplus,
          SUM(CASE WHEN dynamic_q80_confirmed=1 THEN 1 ELSE 0 END) dynamic_q80_aplus,
          SUM(CASE WHEN a_plus_plus_trend=1 THEN 1 ELSE 0 END) aplusplus_trend,
          SUM(CASE WHEN a_plus_plus_persistence=1 THEN 1 ELSE 0 END) aplusplus_persistence,
          SUM(CASE WHEN market_spike_risk='HIGH' THEN 1 ELSE 0 END) spike_high,
          SUM(CASE WHEN market_spike_risk='EXTREME' THEN 1 ELSE 0 END) spike_extreme,
          AVG(CASE WHEN tracking_ended=1 THEN final_return_pct END) avg_final
          FROM volume_alerts WHERE source_signal_engine_version=?""",(ENGINE_VERSION,)).fetchone()
        l=db.execute("SELECT COUNT(*) n,SUM(completed) mature FROM signal_lifecycle WHERE source_type='MODEL_A' AND source_signal_engine_version=?",(ENGINE_VERSION,)).fetchone()
        c=db.execute("SELECT COUNT(*) n FROM signal_market_context WHERE source_type='MODEL_A' AND source_signal_engine_version=?",(ENGINE_VERSION,)).fetchone()
        p=db.execute("SELECT COUNT(*) points,COUNT(DISTINCT source_id) signals FROM signal_path_points WHERE source_type='MODEL_A' AND source_signal_engine_version=?",(ENGINE_VERSION,)).fetchone()
        latest=db.execute("SELECT created_at FROM volume_alerts WHERE source_signal_engine_version=? ORDER BY created_at DESC LIMIT 1",(ENGINE_VERSION,)).fetchone()
    return {"source_version":ENGINE_VERSION,"model_a":dict(a),"lifecycle":dict(l),"initial_context":dict(c),
            "signal_path":dict(p),"archive":archive_summary(),"latest_model_a_at":float(latest[0]) if latest else None}


def _update_table_live(db, table, rows, quotes, now, horizon):
    for r in rows:
        if now - r["created_at"] >= horizon: continue
        q = quotes.get(r["symbol"])
        if not q or q["timestamp"] < r["created_at"]: continue
        d = 1 if r["direction"] == "LONG" else -1
        pnl = (q["price"] / r["trigger_price"] - 1) * 100 * d
        old_mfe=float(r["mfe_pct"] or 0); mfe=max(old_mfe,pnl); mae=min(float(r["mae_pct"] or 0),pnl)
        mfe_at=r["mfe_at"] if "mfe_at" in r.keys() else None
        if pnl>old_mfe: mfe_at=q["timestamp"]
        plus = r["first_plus_1_at"] or (q["timestamp"] if pnl >= 1 else None)
        plus2 = r["first_plus_2_at"] or (q["timestamp"] if pnl >= 2 else None)
        plus3 = r["first_plus_3_at"] or (q["timestamp"] if pnl >= 3 else None)
        plus5 = r["first_plus_5_at"] or (q["timestamp"] if pnl >= 5 else None)
        minus = r["first_minus_1_at"] or (q["timestamp"] if pnl <= -1 else None)
        minus15 = r["first_minus_1_5_at"] or (q["timestamp"] if pnl <= -1.5 else None)
        minus2 = r["first_minus_2_at"] or (q["timestamp"] if pnl <= -2 else None)
        db.execute(f"""UPDATE {table} SET mfe_pct=?,mae_pct=?,final_return_pct=?,first_plus_1_at=?,first_plus_2_at=?,
                    first_plus_3_at=?,first_plus_5_at=?,first_minus_1_at=?,first_minus_1_5_at=?,first_minus_2_at=?,mfe_at=? WHERE id=?""",
                   (mfe,mae,pnl,plus,plus2,plus3,plus5,minus,minus15,minus2,mfe_at,r["id"]))


async def update_live_tracking(quotes):
    now=time.time(); horizon=config.tracking_hours*3600
    with _LOCK,_connect() as db:
        rows=db.execute("SELECT * FROM volume_alerts WHERE tracking_ended=0").fetchall()
        _update_table_live(db,"volume_alerts",rows,quotes,now,horizon); db.commit()


async def _backfill_table(client, table, where_clause, limit):
    if table != "volume_alerts": return
    now=time.time(); horizon=config.tracking_hours*3600
    with _LOCK,_connect() as db:
        rows=[dict(r) for r in db.execute("""SELECT * FROM volume_alerts WHERE tracking_ended=0
            AND MAX(observation_at,COALESCE(a_plus_confirm_at,observation_at))<=? ORDER BY observation_at LIMIT ?""",
                                          (now-horizon,int(limit))).fetchall()]
    for r in rows:
        try:
            trigger_at=float(r["observation_at"])
            raw_all=await client.get("/fapi/v1/klines",symbol=r["symbol"],interval="1m",startTime=int(trigger_at*1000),
                                     endTime=int((trigger_at+horizon+10*60)*1000),limit=1000)
            raw_all=[x for x in (raw_all or []) if trigger_at<=float(x[0])/1000.0<trigger_at+horizon+10*60]
            raw_all=sorted({float(x[0]):x for x in raw_all if float(x[6])/1000 < now}.values(),key=lambda x:float(x[0]))
            raw=[x for x in raw_all if float(x[0])/1000.0<trigger_at+horizon]
            if [float(x[0])/1000 for x in raw] != [trigger_at+i*60 for i in range(int(horizon//60))]: continue
            if r.get("a_plus_confirm_at"):
                ct=float(r["a_plus_confirm_at"])
                confirmed=[x for x in raw_all if ct<=float(x[0])/1000<ct+horizon]
                if [float(x[0])/1000 for x in confirmed] != [ct+i*60 for i in range(int(horizon//60))]: continue
            d=1 if r["direction"]=="LONG" else -1; mfe=mae=0.0; mfe_at=plus=plus2=plus3=plus5=minus=minus15=minus2=None
            for row in raw:
                ts=float(row[0])/1000; high=float(row[2]); low=float(row[3]); fav=high if d==1 else low; adv=low if d==1 else high
                fp=(fav/r["trigger_price"]-1)*100*d; ap=(adv/r["trigger_price"]-1)*100*d
                if fp>mfe:mfe=fp;mfe_at=ts
                mae=min(mae,ap)
                if plus is None and fp>=1:plus=ts
                if plus2 is None and fp>=2:plus2=ts
                if plus3 is None and fp>=3:plus3=ts
                if plus5 is None and fp>=5:plus5=ts
                if minus is None and ap<=-1:minus=ts
                if minus15 is None and ap<=-1.5:minus15=ts
                if minus2 is None and ap<=-2:minus2=ts
            final=(float(raw[-1][4])/r["trigger_price"]-1)*100*d
            with _LOCK,_connect() as db:
                db.execute("""UPDATE volume_alerts SET mfe_pct=?,mae_pct=?,final_return_pct=?,first_plus_1_at=?,first_plus_2_at=?,
                  first_plus_3_at=?,first_plus_5_at=?,first_minus_1_at=?,first_minus_1_5_at=?,first_minus_2_at=?,mfe_at=?,
                  tracking_status='complete',tracking_ended=1 WHERE id=?""",
                  (mfe,mae,final,plus,plus2,plus3,plus5,minus,minus15,minus2,mfe_at,r["id"]))
                _reconcile_lifecycle_and_execution_db(db,"MODEL_A",int(r["id"]),r["symbol"],r["direction"],trigger_at,float(r["trigger_price"]),raw_all)
                db.execute("UPDATE volume_alerts SET execution_engine_version=? WHERE id=?",(EXECUTION_ENGINE_VERSION,int(r["id"])))
                db.commit()
        except Exception:
            continue


async def backfill_due_lifecycle(client, limit=20):
    now=time.time(); horizon=SIGNAL_PATH_HORIZON_MINUTES
    with _LOCK,_connect() as db:
        rows=[dict(r) for r in db.execute("""SELECT l.* FROM signal_lifecycle l JOIN volume_alerts va ON va.id=l.source_id
          WHERE l.source_type='MODEL_A' AND l.completed=0 AND l.trigger_at<=? AND va.tracking_ended=1
          ORDER BY l.trigger_at LIMIT ?""",(now-horizon*60,int(limit))).fetchall()]
    for r in rows:
        try:
            raw=await client.get("/fapi/v1/klines",symbol=r["symbol"],interval="1m",startTime=int(float(r["trigger_at"])*1000),
                                 endTime=int((float(r["trigger_at"])+(horizon+10)*60)*1000),limit=1000)
            raw=[x for x in (raw or []) if float(r["trigger_at"])<=float(x[0])/1000.0<float(r["trigger_at"])+(horizon+10)*60]
            if len([x for x in raw if float(x[0])/1000.0<float(r["trigger_at"])+horizon*60])<horizon: continue
            with _LOCK,_connect() as db:
                _reconcile_lifecycle_and_execution_db(db,"MODEL_A",r["source_id"],r["symbol"],r["direction"],r["trigger_at"],r["trigger_price"],raw); db.commit()
        except Exception: continue


async def backfill_due_alerts(client, limit=20):
    await _backfill_table(client,"volume_alerts","1=1",limit)
    await backfill_due_lifecycle(client,limit)


async def prune_runtime_research_data():
    """Prune high-volume runtime detail only after mature Model-A rows are archived.

    The compact research archive is the long-term source for cross-version review.
    Runtime DB keeps recent paths/observations for the live dashboard and debugging.
    """
    now=time.time()
    path_cutoff=now-float(config.signal_path_retention_days)*86400.0
    obs_cutoff=now-float(config.volume_observation_retention_hours)*3600.0
    with _LOCK,_connect() as db:
        # Ensure every mature V4.8 Model-A signal that is about to age out has a compact archive row.
        mature=[int(r[0]) for r in db.execute(
            """SELECT source_id FROM signal_lifecycle
               WHERE source_type='MODEL_A' AND completed=1 AND completed_at IS NOT NULL AND completed_at<?""",
            (path_cutoff,)
        ).fetchall()]
        archived=0
        path_deleted=0
        for source_id in mature:
            try:
                if archive_completed_signal(db,source_id):
                    archived += 1
                    path_deleted += db.execute("DELETE FROM signal_path_points WHERE source_type='MODEL_A' AND source_id=?",(source_id,)).rowcount
            except Exception:
                # Keep source evidence when archive creation failed.
                continue
        db.execute("DELETE FROM model_b_snapshots WHERE sampled_at<?",(path_cutoff,))
        obs_deleted=db.execute("DELETE FROM volume_observations WHERE observation_at<?",(obs_cutoff,)).rowcount
        db.commit()
    return {"archived":archived,"signal_path_points_deleted":path_deleted,"volume_observations_deleted":obs_deleted,
            "path_cutoff":path_cutoff,"observation_cutoff":obs_cutoff}


async def create_research_analysis_snapshot():
    """Create a timestamped immutable analysis snapshot from the compact archive."""
    return create_analysis_snapshot()


async def get_due_notifications():
    with _LOCK, _connect() as db:
        rows = db.execute("SELECT * FROM notification_outbox WHERE status='pending' AND next_attempt<=? ORDER BY id LIMIT 20",
                          (time.time(),)).fetchall()
    return [SimpleNamespace(**dict(r)) for r in rows]


async def update_notification(item_id, status, attempts, next_attempt, error=""):
    with _LOCK, _connect() as db:
        db.execute("UPDATE notification_outbox SET status=?,attempts=?,next_attempt=?,last_error=?,sent_at=? WHERE id=?",
                   (status, attempts, next_attempt, error, time.time() if status == "sent" else None, item_id))
        if status == "sent":
            key=db.execute('SELECT alert_id FROM notification_outbox WHERE id=?',(item_id,)).fetchone()
            if key and -2_000_000_000_000 < key[0] < -1_000_000_000_000:
                db.execute('UPDATE volume_alerts SET notified=1 WHERE id=?',(-key[0]-1_000_000_000_000,))
        db.commit()

async def load_model_b_state():
    with _LOCK, _connect() as db:
        return {r["key"]:json.loads(r["payload"]) for r in db.execute("SELECT * FROM model_b_state")}


async def persist_model_b_evaluation(key, state, data, title=None, body=None):
    """Commit snapshot, alert, outbox and restart cooldown in one transaction."""
    payload=json.dumps(data,ensure_ascii=False,allow_nan=False)
    with _LOCK, _connect() as db:
        db.execute("INSERT OR REPLACE INTO model_b_snapshots(symbol,sampled_at,payload) VALUES(?,?,?)",
                   (data["symbol"],data["sampled_at"],payload))
        if title:
            cur=db.execute("INSERT INTO model_b_alerts(created_at,symbol,payload) VALUES(?,?,?)",
                           (data["sampled_at"],data["symbol"],payload))
            if config.crowding_telegram_enabled:
                db.execute("""INSERT INTO notification_outbox(alert_id,title,body,status,attempts,next_attempt,created_at)
                              VALUES(?,?,?,'pending',0,0,?)""",
                           (-(6_000_000_000_000+cur.lastrowid),title,body,time.time()))
        db.execute("INSERT OR REPLACE INTO model_b_state(key,payload) VALUES(?,?)",
                   (key,json.dumps(state,allow_nan=False)))


async def recent_model_b_alerts(limit=50):
    with _LOCK, _connect() as db:
        rows=db.execute("SELECT * FROM model_b_alerts ORDER BY id DESC LIMIT ?",(max(1,min(int(limit),500)),)).fetchall()
    return [{**json.loads(r["payload"]),"id":r["id"],"created_at":r["created_at"]} for r in rows]


async def record_crowding_alert(data: dict) -> int:
    now = time.time()
    payload = json.dumps(data, ensure_ascii=False, allow_nan=False)
    with _LOCK, _connect() as db:
        cur = db.execute("""
            INSERT INTO leverage_crowding_alerts (
                created_at, symbol, direction, score, level, level_name, sector,
                vr_1h, oi, oi_percentile, oi_zscore, funding_apr, funding_percentile,
                basis_pct, basis_percentile, fs_ratio, clv, return_1h_pct,
                liq_total_5m, liq_imbalance_5m, payload
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            now, data["symbol"], data["direction"], data["score"], data["level"], data["level_name"], data["sector"],
            data["vr_1h"], data["oi"], data["oi_percentile"], data["oi_zscore"], data["funding_apr"], data["funding_percentile"],
            data["basis_pct"], data["basis_percentile"], data["fs_ratio"], data["clv"], data["return_1h_pct"],
            data.get("liq_total_5m", 0.0), data.get("liq_imbalance_5m", 0.0), payload
        ))
        db.commit()
        return int(cur.lastrowid)


async def save_crowding_snapshot(symbol: str, data: dict):
    payload = json.dumps(data, ensure_ascii=False, allow_nan=False)
    with _LOCK, _connect() as db:
        db.execute("""
            INSERT OR REPLACE INTO leverage_crowding_snapshots (
                symbol, sampled_at, score, level, vr_1h, oi, funding_apr, basis_pct, fs_ratio, clv, payload
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (
            symbol, data["sampled_at"], data["score"], data["level"], data["vr_1h"],
            data["oi"], data["funding_apr"], data["basis_pct"], data["fs_ratio"], data["clv"], payload
        ))
        db.commit()


async def recent_crowding_alerts(limit=50) -> list[dict]:
    limit = max(1, min(int(limit), 200))
    with _LOCK, _connect() as db:
        rows = db.execute("SELECT * FROM leverage_crowding_alerts ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["details"] = json.loads(d.pop("payload"))
            except Exception:
                d["details"] = {}
            out.append(d)
        return out


async def enqueue_crowding_notification(alert_id: int, title: str, body: str):
    stable_key = -(5_000_000_000_000 + int(alert_id))
    return await enqueue_notification(stable_key, title, body)
