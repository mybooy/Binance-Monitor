"""V5.2 public, read-only Binance/OKX/Bybit spot + linear USDT perpetual adapters.

Never equate 24-hour rolling volume differences with minute volume. Missing metrics stay None.
Official REST docs: developers.binance.com, okx.com/docs-v5, bybit-exchange.github.io/docs/v5.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, asdict
from typing import Any

import aiohttp
from config import config

log = logging.getLogger('v52.exchange')
BASE_URL = {
    'binance_futures': 'https://fapi.binance.com',
    'binance_spot': 'https://api.binance.com',
    'okx': 'https://www.okx.com',
    'bybit': 'https://api.bybit.com',
}


def number(x: Any) -> float | None:
    if x is None or x == '':
        return None
    try:
        value = float(x)
        if not (-1e300 < value < 1e300):
            return None
        return value
    except (ValueError, TypeError, OverflowError):
        return None


def base_asset(raw: str | None) -> str:
    return (raw or '').upper().strip()


@dataclass
class Instrument:
    exchange: str
    symbol: str
    asset: str
    market: str  # SPOT or PERP
    quote: str = 'USDT'
    settle: str = 'USDT'
    contract_multiplier: float | None = None
    contract_unit: str | None = None
    funding_interval_hours: float | None = None
    state: str = 'TRADING'

    @property
    def key(self):
        return f'{self.exchange}:{self.market}:{self.symbol}'


@dataclass
class Quote:
    exchange: str
    symbol: str
    asset: str
    market: str
    price: float
    event_time_ms: int | None
    received_at: float
    volume_24h_quote: float | None = None
    oi_native: float | None = None
    oi_base: float | None = None
    oi_usd: float | None = None
    funding_rate: float | None = None
    funding_interval_hours: float | None = None
    funding_kind: str | None = None
    next_funding_ms: int | None = None
    quality: str = 'OK'
    sampled_taker_buy_share: float | None = None
    sampled_trade_count: int | None = None
    sampled_trade_span_seconds: float | None = None
    sampled_quote_notional: float | None = None


class PublicHTTP:
    def __init__(self, proxy: str | None = None, timeout=12, concurrency=4):
        self.proxy = proxy if proxy is not None else (config.proxy_url if config.use_proxy else None)
        self.timeout = timeout
        self.sem = asyncio.Semaphore(concurrency)
        self.session = None
        self.retry_until: dict[str, float] = {}
        self.errors: dict[str, str] = {}
        self.last_ok: dict[str, float] = {}

    async def get(self, host, endpoint, params=None):
        now = time.monotonic()
        if now < self.retry_until.get(host, 0):
            raise RuntimeError(f'{host} rate-limit cooling down')
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout))
        async with self.sem:
            try:
                async with self.session.get(BASE_URL[host]+endpoint, params=params, proxy=self.proxy) as res:
                    if res.status in (418,429):
                        self.retry_until[host] = time.monotonic() + min(300,max(10,int(res.headers.get('Retry-After','30'))))
                        raise RuntimeError(f'{host} HTTP {res.status}: rate limited')
                    res.raise_for_status()
                    data = await res.json(content_type=None)
                    if host=='okx' and str(data.get('code','0')) != '0':
                        raise ValueError(f'OKX error code {data.get("code")}')
                    if host=='bybit' and int(data.get('retCode',-1)) != 0:
                        raise ValueError(f'Bybit error code {data.get("retCode")}')
                    if host.startswith('binance') and isinstance(data,dict) and data.get('code',0) not in (0,None):
                        raise ValueError(f'Binance error code {data.get("code")}')
                    self.last_ok[host] = time.time()
                    self.errors.pop(host,None)
                    return data
            except (aiohttp.ClientError, asyncio.TimeoutError, ValueError, RuntimeError) as exc:
                self.errors[host] = f'{type(exc).__name__}: {str(exc)[:160]}'
                raise

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()


class ThreeExchangeClient:
    def __init__(self, http: PublicHTTP | None = None):
        self.http = http or PublicHTTP()
        self.instruments: dict[str, Instrument] = {}
        self.last_discovered_at = 0.0
        self.market_errors = {}

    def _add(self, exchange, market, symbol, asset, quote='USDT', settle='USDT', **kw):
        if not symbol or not asset or quote != 'USDT':
            return
        inst=Instrument(exchange, symbol, base_asset(asset), market, quote, settle, **kw)
        self.instruments[inst.key] = inst

    async def discover_binance(self):
        f,s = await asyncio.gather(self.http.get('binance_futures','/fapi/v1/exchangeInfo'),
                                   self.http.get('binance_spot','/api/v3/exchangeInfo'))
        for v in f.get('symbols',[]):
            if v.get('status')=='TRADING' and v.get('contractType')=='PERPETUAL' and v.get('quoteAsset')=='USDT' and v.get('marginAsset')=='USDT':
                self._add('binance','PERP',v.get('symbol'),v.get('baseAsset'))
        for v in s.get('symbols',[]):
            if v.get('status')=='TRADING' and v.get('quoteAsset')=='USDT' and v.get('isSpotTradingAllowed',True):
                self._add('binance','SPOT',v.get('symbol'),v.get('baseAsset'))

    async def discover_okx(self):
        for market,inst_type in [('PERP','SWAP'),('SPOT','SPOT')]:
            resp=await self.http.get('okx','/api/v5/public/instruments',{'instType':inst_type})
            for v in resp.get('data',[]):
                if v.get('state')!='live' or v.get('quoteCcy' if market=='SPOT' else 'settleCcy')!='USDT':
                    continue
                if market=='PERP' and v.get('ctType')!='linear':
                    continue
                ct_val=number(v.get('ctVal')) if market=='PERP' else None
                unit=v.get('ctValCcy') if market=='PERP' else None
                self._add('okx',market,v.get('instId'),v.get('baseCcy') or v.get('ctValCcy') or v.get('instFamily','').split('-')[0],
                          contract_multiplier=ct_val,contract_unit=unit)

    async def discover_bybit(self):
        for market,cat in [('PERP','linear'),('SPOT','spot')]:
            cursor=None; visited=set()
            for _ in range(40):
                params={'category':cat}
                if cat != 'spot': params['limit']=1000  # Bybit spot has no pagination
                if cursor: params['cursor']=cursor
                resp=await self.http.get('bybit','/v5/market/instruments-info',params)
                result=resp.get('result',{})
                for v in result.get('list',[]):
                    if v.get('status')!='Trading' or v.get('quoteCoin')!='USDT':
                        continue
                    if market=='PERP' and (v.get('contractType')!='LinearPerpetual' or v.get('settleCoin')!='USDT'):
                        continue
                    interval=number(v.get('fundingInterval'))
                    self._add('bybit',market,v.get('symbol'),v.get('baseCoin'),
                              funding_interval_hours=interval/60 if interval else None)
                new_cursor=result.get('nextPageCursor') or ''
                if not new_cursor or new_cursor in visited: break
                visited.add(new_cursor); cursor=new_cursor
            else:
                raise RuntimeError(f'Bybit {cat} discovery exceeded 40 pages')

    async def discover(self):
        previous=dict(self.instruments)
        self.instruments.clear()
        results=await asyncio.gather(self.discover_binance(),self.discover_okx(),self.discover_bybit(),return_exceptions=True)
        for exchange,result in zip(('binance','okx','bybit'),results):
            if isinstance(result,BaseException):
                self.market_errors[exchange]=f'{type(result).__name__}: {str(result)[:150]}'
                # Preserve last-known metadata during a temporary exchange outage;
                # stale metadata alone is never interpreted as fresh market quotes.
                for key,inst in previous.items():
                    if inst.exchange==exchange:self.instruments.setdefault(key,inst)
            else:
                self.market_errors.pop(exchange,None)
        self.last_discovered_at=time.time()
        return self.coverage()

    def coverage(self):
        out={}
        for ex in ('binance','okx','bybit'):
            inst=[v for v in self.instruments.values() if v.exchange==ex]
            out[ex]={'perp':sum(v.market=='PERP' for v in inst),'spot':sum(v.market=='SPOT' for v in inst),
                     'assets':len({v.asset for v in inst}), 'error':self.market_errors.get(ex)}
        out['union_assets']=len({v.asset for v in self.instruments.values() if v.market=='PERP'})
        return out

    def _inst(self,ex,market,symbol):
        return self.instruments.get(f'{ex}:{market}:{symbol}')

    def normalize_binance(self, data, market, received_at):
        out=[]
        for v in data:
            inst=self._inst('binance',market,v.get('symbol'))
            price=number(v.get('lastPrice'))
            if inst is None or not price or price<=0: continue
            out.append(Quote('binance',inst.symbol,inst.asset,market,price,
                             int(v['closeTime']) if v.get('closeTime') else None,received_at,
                             volume_24h_quote=number(v.get('quoteVolume'))))
        return out

    def normalize_okx(self,data,market,received_at):
        out=[]
        for v in data:
            inst=self._inst('okx',market,v.get('instId'))
            price=number(v.get('last'))
            if not inst or not price or price<=0:continue
            # Official OKX tickers: volCcy24h is QUOTE currency for SPOT,
            # BASE currency for derivatives. Here products are linear USDT swaps.
            vol=number(v.get('volCcy24h'))
            if market=='PERP' and vol is not None: vol*=price
            out.append(Quote('okx',inst.symbol,inst.asset,market,price,
                             int(v['ts']) if v.get('ts') else None, received_at,volume_24h_quote=vol))
        return out

    def normalize_bybit(self,data,market,received_at):
        out=[]
        for v in data:
            inst=self._inst('bybit',market,v.get('symbol'))
            price=number(v.get('lastPrice'))
            if not inst or not price or price<=0:continue
            oi=number(v.get('openInterest')) if market=='PERP' else None
            fund=number(v.get('fundingRate')) if market=='PERP' else None
            out.append(Quote('bybit',inst.symbol,inst.asset,market,price,None,received_at,
                volume_24h_quote=number(v.get('turnover24h')),
                oi_native=oi,oi_base=oi,oi_usd=number(v.get('openInterestValue')),
                funding_rate=fund,funding_interval_hours=inst.funding_interval_hours,
                funding_kind='ESTIMATED' if fund is not None else None,
                next_funding_ms=int(v['nextFundingTime']) if v.get('nextFundingTime') else None))
        return out

    async def quotes(self):
        paths=[('binance','PERP','binance_futures','/fapi/v1/ticker/24hr',None),
               ('binance','SPOT','binance_spot','/api/v3/ticker/24hr',None),
               ('okx','PERP','okx','/api/v5/market/tickers',{'instType':'SWAP'}),
               ('okx','SPOT','okx','/api/v5/market/tickers',{'instType':'SPOT'}),
               ('bybit','PERP','bybit','/v5/market/tickers',{'category':'linear'}),
               ('bybit','SPOT','bybit','/v5/market/tickers',{'category':'spot'})]
        async def one(ex,market,host,path,params):
            try:
                data=await self.http.get(host,path,params)
                now=time.time()
                if ex=='binance': out=self.normalize_binance(data,market,now)
                elif ex=='okx': out=self.normalize_okx(data.get('data',[]),market,now)
                else: out=self.normalize_bybit(data.get('result',{}).get('list',[]),market,now)
                self.market_errors.pop(f'{ex}:{market}',None)
                return out
            except Exception as e:
                self.market_errors[f'{ex}:{market}']=f'{type(e).__name__}: {str(e)[:140]}'
                return []
        batches=await asyncio.gather(*(one(*p) for p in paths))
        return [q for batch in batches for q in batch]

    async def enrich(self, quotes: list[Quote], focus_assets: set[str], binance_oi_budget=10):
        """Public OI/funding for focus; no blanket OI N* REST fanout."""
        by_key={f'{q.exchange}:{q.market}:{q.symbol}':q for q in quotes}
        tasks=[]
        async def binance_premium():
            data=await self.http.get('binance_futures','/fapi/v1/premiumIndex')
            for x in data if isinstance(data,list) else [data]:
                q=by_key.get(f'binance:PERP:{x.get("symbol")}')
                if not q: continue
                q.funding_rate=number(x.get('lastFundingRate'))
                q.funding_kind='INDICATIVE_TICKER' if q.funding_rate is not None else None
                q.next_funding_ms=int(x['nextFundingTime']) if x.get('nextFundingTime') else None
        async def okx_oi():
            data=await self.http.get('okx','/api/v5/public/open-interest',{'instType':'SWAP'})
            for x in data.get('data',[]):
                q=by_key.get(f'okx:PERP:{x.get("instId")}')
                if not q:continue
                q.oi_native=number(x.get('oi'))
                q.oi_base=number(x.get('oiCcy'))
                q.oi_usd=number(x.get('oiUsd'))
        async def binance_oi(q):
            resp=await self.http.get('binance_futures','/fapi/v1/openInterest',{'symbol':q.symbol})
            q.oi_native=number(resp.get('openInterest'));q.oi_base=q.oi_native
            q.oi_usd=q.oi_base*q.price if q.oi_base is not None else None
        tasks.extend([binance_premium(),okx_oi()])
        focus = [q for q in quotes if q.exchange=='binance' and q.market=='PERP' and q.asset in focus_assets]
        focus.sort(key=lambda x:(x.asset not in {'BTC','ETH'},-(x.volume_24h_quote or 0)))
        tasks.extend(binance_oi(q) for q in focus[:binance_oi_budget])
        results=await asyncio.gather(*tasks,return_exceptions=True)
        for r in results:
            if isinstance(r,BaseException):log.warning('cross-market enrichment degraded: %s',str(r)[:140])
        # Funding for OKX is instrument-specific; poll focus only with a strict request budget.
        limited=[q for q in quotes if q.exchange=='okx' and q.market=='PERP' and q.asset in focus_assets]
        limited.sort(key=lambda q:(q.asset not in {'BTC','ETH'},-(q.volume_24h_quote or 0)))
        async def okx_funding(q):
            try:
                x=await self.http.get('okx','/api/v5/public/funding-rate',{'instId':q.symbol})
                row=next(iter(x.get('data',[])),{})
                q.funding_rate=number(row.get('fundingRate'))
                q.funding_kind='INDICATIVE_TICKER' if q.funding_rate is not None else None
                q.next_funding_ms=int(row['fundingTime']) if row.get('fundingTime') else None
                # Current interval must be explicit, not hardcoded 8h.
                if row.get('fundingTime') and row.get('nextFundingTime'):
                    interval=(int(row['nextFundingTime'])-int(row['fundingTime']))/3600000
                    if 0 < interval <= 24: q.funding_interval_hours=interval
            except Exception as exc:log.debug('okx funding %s: %s',q.symbol,exc)
        await asyncio.gather(*(okx_funding(q) for q in limited[:8]))
        return quotes

    async def sample_spot_tape(self,quotes: list[Quote],assets: set[str],budget=6):
        """Best-effort most-recent trades, not a complete trade tape or fixed 1m window."""
        selected=[q for q in quotes if q.market=='SPOT' and q.asset in assets]
        selected.sort(key=lambda q:(q.asset not in {'BTC','ETH'},q.exchange!='binance'))
        async def one(q):
            try:
                if q.exchange=='binance':
                    data=await self.http.get('binance_spot','/api/v3/aggTrades',{'symbol':q.symbol,'limit':200})
                    entries=[(int(x['T'])/1000,'SELL' if x['m'] else 'BUY',number(x.get('p')),number(x.get('q'))) for x in data]
                elif q.exchange=='okx':
                    resp=await self.http.get('okx','/api/v5/market/trades',{'instId':q.symbol,'limit':100})
                    entries=[(int(x['ts'])/1000,str(x.get('side','')).upper(),number(x.get('px')),number(x.get('sz'))) for x in resp.get('data',[])]
                else:
                    resp=await self.http.get('bybit','/v5/market/recent-trade',{'category':'spot','symbol':q.symbol,'limit':100})
                    entries=[(int(x['time'])/1000,str(x.get('side','')).upper(),number(x.get('price')),number(x.get('size'))) for x in resp.get('result',{}).get('list',[])]
                # Reject stale or malformed trades, retain actual sample span separately.
                eligible=[(t,side,px*size) for t,side,px,size in entries
                          if px is not None and size is not None and px>0 and size>0 and side in ('BUY','SELL')
                          and 0<=q.received_at-t<=180]
                if len(eligible)<8:return
                total=sum(v for _,_,v in eligible)
                if total<=0:return
                q.sampled_taker_buy_share=sum(v for _,side,v in eligible if side=='BUY')/total
                q.sampled_trade_count=len(eligible)
                q.sampled_quote_notional=total
                q.sampled_trade_span_seconds=max(t for t,_,_ in eligible)-min(t for t,_,_ in eligible)
            except Exception as exc:
                log.debug('spot tape degraded: %s %s: %s',q.exchange,q.symbol,str(exc)[:120])
        await asyncio.gather(*(one(q) for q in selected[:max(0,budget)]))
        return quotes

    async def close(self):
        await self.http.close()
